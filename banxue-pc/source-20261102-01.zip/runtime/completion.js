import {bootstrap} from './common.js';

const OP_KEY='banxue.pc.complete.operations.v1';
const DIAG_KEY='banxue.pc.complete.diagnosis.v1';
const STORE_KEY='banxue.pc.complete.attendance.v1';
const labels={homework:'作业批改',chinese:'语文作文',english:'英语作文'};
const phaseLabels={processing:'处理中',review:'待批改审核',push:'待推题审核',queued:'报告排队中',generating:'报告生成中',ready:'待下载',downloaded:'已完成',completed:'已完成',done:'已完成',pending:'待处理','composition-error':'批改异常','processing-failed':'处理失败','report-failed':'报告生成失败'};
const processing=new Set(['processing','queued','generating']);
const date=value=>new Date(value).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}).replace(/\//g,'.');
const day=value=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value));
const read=(key,fallback)=>{try{return JSON.parse(localStorage.getItem(key))||fallback;}catch{return fallback;}};
const esc=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

export function mountCompletion(env,kind){
  const {window,document,setTimeout,clearTimeout,setInterval}=env;
  const {D,C,Pager,Delivery,Files,PDF}=bootstrap(env);
  const $=id=>document.getElementById(id);
  const el=(tag,cls,text)=>{const n=document.createElement(tag);if(cls)n.className=cls;if(text!=null)n.textContent=text;return n;};
  const btn=(text,action,cls='btn btn-ghost',disabled=false)=>{const n=el('button',cls,text);n.type='button';n.disabled=disabled;n.addEventListener('click',action);return n;};
  let toastTimer,dialogURLs=[],opener=null;
  const toast=message=>{$('cpToast').textContent=message;$('cpToast').hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('cpToast').hidden=true,2800);};
  function close(){const d=$('cpDialog');d.close();dialogURLs.forEach(URL.revokeObjectURL);dialogURLs=[];if(opener?.isConnected)opener.focus({preventScroll:true});}
  function open(title,actions=[]){
    const d=$('cpDialog');if(d.open)close();opener=document.activeElement;
    $('cpDialogTitle').textContent=title;$('cpDialogBody').replaceChildren();$('cpDialogFoot').replaceChildren(...actions);
    d.showModal();return $('cpDialogBody');
  }
  $('cpClose').addEventListener('click',close);
  $('cpDialog').addEventListener('cancel',event=>{event.preventDefault();close();});
  $('cpDialog').addEventListener('click',event=>{if(event.target===$('cpDialog')){const r=$('cpDialog').getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)close();}});
  function field(root,label,value='',type='text'){
    const wrap=el('label','',label),input=el(type==='textarea'?'textarea':'input','cp-field');
    if(type!=='textarea')input.type=type;input.value=value;wrap.append(input);root.append(wrap);return input;
  }
  const help=(root,text)=>root.append(el('p','cp-help',text));
  function empty(text){const node=el('div','cp-empty');node.innerHTML='<img src="../demos/exam-analysis/assets/shared/empty-box.svg" alt="">';node.append(el('p','',text));return node;}
  function files(root,task){
    const list=el('div','cp-files');
    for(const file of task.attachments||[]){if(!file.blob)continue;const url=URL.createObjectURL(file.blob);dialogURLs.push(url);if(file.blob.type==='application/pdf'){const a=el('a','',file.name);a.href=url;a.target='_blank';a.rel='noopener';list.append(a);}else{const image=el('img');image.src=url;image.alt=file.name;list.append(image);}}
    if(!list.childElementCount)help(list,'当前任务为示例数据，无原始上传材料。');root.append(list);
  }
  async function busy(button,action){button.disabled=true;try{await action();}catch(error){toast(error.message||'操作未完成，请重试');}finally{if(button.isConnected)button.disabled=false;}}
  const roster=()=>D.roster('pc');
  const person=id=>D.student(id,'pc');
  let refreshPage=()=>{};
  window.PCPageLifecycle={beforeLeave:()=>{if($('cpDialog').open)close();return true;},activate:()=>refreshPage(),deactivate:()=>{if($('cpDialog').open)close();}};

  if(labels[kind]) taskList();else if(kind==='diagnosis') diagnosis();else attendance();

  function taskList(){
    const writing=kind!=='homework';let state={keyword:'',phase:'all',today:false,view:'cards',sort:'desc'},rows=[],request=0,lastSignature='';
    const store=read(OP_KEY,{schemaVersion:1,tasks:{}});
    for(const k of Object.keys(labels))for(let i=0;i<D.catalog.scenarios.names.length;i++){
      const task=D.operationSeed(k,i,Date.now());if(!store.tasks[task.id])store.tasks[task.id]={...task,kind:k,phase:task.phase==='push'?'review':task.phase,example:true};
    }
    localStorage.setItem(OP_KEY,JSON.stringify(store));
    const filter=$('cpStatus');
    const phases=writing?['processing','review','composition-error','queued','generating','ready','downloaded']:['processing','review','queued','generating','ready','downloaded'];
    filter.innerHTML='<option value="all">全部状态</option>'+phases.map(v=>`<option value="${v}">${phaseLabels[v]}</option>`).join('');
    $('cpSearch').placeholder='搜索学员姓名';
    const pager=Pager.create({root:$('cpPager'),pageSize:12,pageSizeOptions:[12,24,48],total:0,onChange:paint});
    $('cpSearch').addEventListener('input',()=>{state.keyword=$('cpSearch').value.trim();apply();});
    filter.addEventListener('change',()=>{state.phase=filter.value;apply();});
    $('cpToday').addEventListener('change',()=>{state.today=$('cpToday').checked;apply();});
    for(const [id,view] of [['cpCards','cards'],['cpTable','table']])$(id).addEventListener('click',()=>{state.view=view;paint();});
    $('cpSort').addEventListener('click',()=>{state.sort=state.sort==='desc'?'asc':'desc';$('cpSort').textContent=state.sort==='desc'?'时间 ↓':'时间 ↑';apply();});
    $('cpClear').addEventListener('click',()=>{state.keyword='';state.phase='all';state.today=false;$('cpSearch').value='';filter.value='all';$('cpToday').checked=false;apply();});
    function filtered(){return rows.filter(t=>(!state.keyword||t.student.name.includes(state.keyword))&&(state.phase==='all'||t.phase===state.phase)&&(!state.today||day(t.createdAt)===day(Date.now()))).sort((a,b)=>(Date.parse(b.createdAt)-Date.parse(a.createdAt))*(state.sort==='desc'?1:-1));}
    function apply(){pager.setTotal(filtered().length,{page:1,silent:true});paint();}
    async function load(){
      const current=++request,all=await allLocalTasks();if(current!==request)return;
      const operations=read(OP_KEY,{schemaVersion:1,tasks:{}});let changed=false;
      rows=Object.values(operations.tasks).filter(t=>t.kind===kind);
      for(const task of all.filter(t=>t.kind===kind)){
        let merged={...task,...operations.tasks[task.id],attachments:task.attachments,settings:task.settings};
        if(!operations.tasks[task.id]){merged.phase='processing';merged.phaseStartedAt=Date.now();merged.phaseReadyAt=Date.now()+5000;operations.tasks[task.id]={...merged,attachments:undefined};changed=true;}
        rows=rows.filter(t=>t.id!==task.id);rows.push(merged);
      }
      for(const task of rows){
        if(task.phaseReadyAt&&Date.now()>=task.phaseReadyAt){task.phase=task.phase==='processing'?'review':'ready';delete task.phaseReadyAt;delete task.phaseStartedAt;operations.tasks[task.id]={...task,attachments:undefined};changed=true;}
        task.student=person(task.studentId);if(!task.student)continue;
        task.name=task.student.name;task.subject=task.subject||D.catalog.courses.find(c=>c.id===task.courseId)?.name||'';
      }
      rows=rows.filter(t=>t.student);
      if(changed)localStorage.setItem(OP_KEY,JSON.stringify(operations));
      D.publishTasks(rows,'pc-complete:'+kind,{replace:true});
      const signature=JSON.stringify(rows.map(t=>[t.id,t.phase,t.score,t.wrong,t.student.name,t.student.avatar]));
      if(signature!==lastSignature){lastSignature=signature;pager.setTotal(filtered().length,{silent:true});paint();}
      else for(const task of rows.filter(t=>processing.has(t.phase))){const p=document.querySelector(`[data-task-id="${CSS.escape(task.id)}"] .cp-progress`);if(p){p.querySelector('i').style.width=progress(task)+'%';p.querySelector('span').textContent=phaseLabels[task.phase]+' '+progress(task).toFixed(1)+'%';}}
    }
    async function allLocalTasks(){
      // Use the same IndexedDB schema and transaction contract as StudentContext.
      return new Promise((resolve,reject)=>{const req=indexedDB.open('banxue-pc-student-workspace',2);req.onupgradeneeded=()=>{const db=req.result;const s=db.objectStoreNames.contains('tasks')?req.transaction.objectStore('tasks'):db.createObjectStore('tasks',{keyPath:'id'});if(!s.indexNames.contains('studentId'))s.createIndex('studentId','studentId');};req.onerror=()=>reject(req.error);req.onsuccess=()=>{const db=req.result,tx=db.transaction('tasks','readonly'),r=tx.objectStore('tasks').getAll();tx.oncomplete=()=>{db.close();resolve(r.result);};tx.onerror=()=>{db.close();reject(tx.error);};};});
    }
    async function save(task,patch){
      Object.assign(task,patch);const s=read(OP_KEY,{schemaVersion:1,tasks:{}});s.tasks[task.id]={...task,attachments:undefined};localStorage.setItem(OP_KEY,JSON.stringify(s));
      if(!task.example)await C.saveTask(task);D.publishTasks([task],'pc-complete:'+kind);await load();
    }
    function progress(task){return task.phaseReadyAt?Math.min(99.9,(Date.now()-task.phaseStartedAt)/(task.phaseReadyAt-task.phaseStartedAt)*100):Math.min(99.9,Number(task.progress)||38);}
    function badge(task){return `<span class="cp-badge ${task.phase==='review'?'warning':['ready'].includes(task.phase)?'primary':task.phase.includes('error')?'error':''}">${esc(phaseLabels[task.phase]||'待处理')}</span>`;}
    function action(task){return task.phase==='review'?'审核批改':['ready','downloaded','done','completed'].includes(task.phase)?'下载报告':task.phase==='composition-error'?'查看原因':'查看详情';}
    function paint(){
      const list=filtered(),range=pager.range(),pageRows=list.slice(range.start,range.end);$('cpCount').textContent=`共 ${list.length} 个任务`;
      $('cpCards').setAttribute('aria-pressed',String(state.view==='cards'));$('cpTable').setAttribute('aria-pressed',String(state.view==='table'));
      const root=$('cpResults');root.replaceChildren();
      if(!list.length){root.append(empty(state.keyword?'未找到匹配的学员任务':'当前筛选下暂无任务'));return;}
      if(state.view==='table'){
        const wrap=el('div','cp-table-wrap'),table=el('table','cp-table');table.setAttribute('aria-label',labels[kind]+'任务列表');
        table.innerHTML=`<thead><tr><th>学员</th><th>${writing?'作文题目':'学科'}</th><th>${writing?'得分':'错题数'}</th><th>创建时间</th><th>状态</th><th>操作</th></tr></thead>`;
        const body=el('tbody');for(const task of pageRows){const tr=el('tr');tr.innerHTML=`<td><img class="cp-avatar" src="${esc(task.student.avatar)}" alt="">${esc(task.student.name)}</td><td>${esc(writing?task.title:task.subject)}</td><td>${esc((task.phase==='processing'||task.phase==='composition-error')?'—':(writing?task.score:task.wrong)??'—')}</td><td>${esc(date(task.createdAt))}</td><td>${badge(task)}</td>`;const td=el('td');td.append(btn(action(task),()=>act(task),'btn bx-link',processing.has(task.phase)));tr.append(td);body.append(tr);}table.append(body);wrap.append(table);root.append(wrap);
      }else{
        const grid=el('div','cp-grid');for(const task of pageRows){
          const card=el('article','bx-list-surface cp-card'+(processing.has(task.phase)?' is-processing':''));card.dataset.taskId=task.id;
          card.innerHTML=`<div class="cp-body"><img class="cp-avatar" src="${esc(task.student.avatar)}" alt=""><div class="cp-info"><div class="cp-name">${esc(task.student.name)}</div><div class="cp-sub">${esc(task.student.grade)} · ${esc(task.subject)}</div><div class="cp-date">${esc(date(task.createdAt))}</div>${writing?`<div class="cp-topic" title="${esc(task.title)}">${esc(task.title)}</div>`:''}</div>${badge(task)}</div><div class="cp-metrics"><span>${writing?'得分':'错题数'}：${esc((task.phase==='processing'||task.phase==='composition-error')?'—':(writing?task.score:task.wrong)??'—')}</span></div>`;
          const foot=el('div','cp-foot');
          if(processing.has(task.phase)){const p=el('div','cp-progress');p.style.flex='1';p.innerHTML=`<i style="width:${progress(task)}%"></i><span>${esc(phaseLabels[task.phase])} ${progress(task).toFixed(1)}%</span>`;foot.append(p);}
          else foot.append(btn(action(task),()=>act(task),'btn bx-link'),btn('查看材料',()=>details(task),'btn btn-ghost'));
          card.append(foot);grid.append(card);
        }root.append(grid);
      }
    }
    async function act(task){
      if(processing.has(task.phase))return;
      if(task.phase==='review')return review(task);
      if(['ready','downloaded','done','completed'].includes(task.phase)){
        try{await Delivery.download(task);await save(task,{phase:'downloaded'});toast('报告已保存到下载中心');}catch(e){toast(e.message);}return;
      }
      details(task);
    }
    function details(task){
      const actions=[btn('关闭',close)];
      if(task.phase==='composition-error'){
        const code=D.catalog.scenarios.compositionErrors[kind]?.[Number(task.id.slice(-2))-1];
        if([203,205].includes(Number(code)))actions.push(btn('重新批改',async()=>{await save(task,{phase:'processing',phaseStartedAt:Date.now(),phaseReadyAt:Date.now()+5000});close();},'btn btn-primary'));
      }
      const body=open(task.title||labels[kind]+'详情',actions),dl=el('dl','cp-definition');
      for(const [label,value] of [['学员',task.student.name],['年级',task.student.grade],['状态',phaseLabels[task.phase]],['创建时间',date(task.createdAt)]]){dl.append(el('dt','',label),el('dd','',value));}
      body.append(dl);if(task.phase==='composition-error')help(body,'批改异常：请检查材料是否为清晰完整的作文图片。允许重试的识别异常可重新批改，其余情况请重新上传。');
      if(task.review?.comment){body.append(el('h3','cp-section-title','审核意见'),el('p','cp-help',task.review.comment));}
      files(body,task);
    }
    function review(task){
      const cancel=btn('取消',close),submit=btn('确认审核',()=>{},'btn btn-primary'),body=open(labels[kind]+' · 审核批改',[cancel,submit]);
      help(body,task.example?'当前为示例批改结果，可调整后确认审核。':'请根据原始材料审核并填写结果。当前演示未进行真实 AI 识别。');
      const form=el('form');const total=Number(task.settings?.total)||Number(task.totalScore)||100;
      const score=field(form,'得分',task.review?.score??(task.example?parseFloat(task.score)||0:''),'number');score.min=0;score.max=total;score.required=true;score.step='0.5';
      let wrong;if(!writing){wrong=field(form,'错题数',task.review?.wrong??(task.example?parseFloat(task.wrong)||0:''),'number');wrong.min=0;wrong.step=1;wrong.required=true;}
      const comment=field(form,'审核意见',task.review?.comment||'','textarea');comment.maxLength=1000;
      const error=el('p','cp-error');error.setAttribute('role','alert');form.append(error);body.append(form);files(body,task);
      submit.addEventListener('click',()=>{if(!form.reportValidity())return;void busy(submit,async()=>{const review={score:Number(score.value),wrong:wrong?Number(wrong.value):null,comment:comment.value.trim()};
        await save(task,{review,score:`${review.score}/${total}分`,...(wrong?{wrong:review.wrong}:{}),phase:'generating',phaseStartedAt:Date.now(),phaseReadyAt:Date.now()+4000});close();toast('审核已保存，正在生成报告');});});
    }
    refreshPage=()=>void load().catch(e=>toast(e.message));refreshPage();setInterval(refreshPage,1500);
  }

  function diagnosis(){
    let state={keyword:'',status:'all'},records=read(DIAG_KEY,{});
    $('cpTodayWrap').hidden=true;$('cpCards').hidden=true;$('cpTable').hidden=true;$('cpSort').hidden=true;
    $('cpStatus').innerHTML='<option value="all">全部状态</option><option value="untested">未测评</option><option value="testing">测评中</option><option value="done">已测评</option>';
    const list=roster();for(let i=0;i<list.length;i++)if(!records[list[i].id])records[list[i].id]={status:i===0?'done':i===1?'testing':'untested',example:true};
    function persist(){localStorage.setItem(DIAG_KEY,JSON.stringify(records));}
    persist();const pager=Pager.create({root:$('cpPager'),pageSize:12,pageSizeOptions:[12,24,48],total:0,onChange:paint});
    $('cpSearch').addEventListener('input',()=>{state.keyword=$('cpSearch').value.trim();apply();});$('cpStatus').addEventListener('change',()=>{state.status=$('cpStatus').value;apply();});
    $('cpClear').addEventListener('click',()=>{state={keyword:'',status:'all'};$('cpSearch').value='';$('cpStatus').value='all';apply();});
    function matching(){return roster().filter(s=>(!state.keyword||s.name.includes(state.keyword))&&(state.status==='all'||records[s.id]?.status===state.status));}
    function apply(){for(const s of roster())records[s.id]||={status:'untested'};pager.setTotal(matching().length,{page:1,silent:true});paint();}
    function paint(){const all=matching(),range=pager.range(),root=$('cpResults');root.replaceChildren();$('cpCount').textContent=`共 ${all.length} 位学员`;if(!all.length){root.append(empty('未找到匹配的学员'));return;}
      const grid=el('div','cp-grid');for(const s of all.slice(range.start,range.end)){const r=records[s.id],card=el('article','bx-list-surface cp-card');card.innerHTML=`<div class="cp-body"><img class="cp-avatar" src="${esc(s.avatar)}" alt=""><div class="cp-info"><div class="cp-name">${esc(s.name)}</div><div class="cp-sub">${esc(s.grade)}</div><div class="cp-date">${r.completedAt?'最近测评 '+esc(day(r.completedAt)):r.status==='testing'?'测评进行中':r.status==='done'?'示例测评已完成':'尚未测评'}</div></div><span class="cp-badge ${r.status==='done'?'success':r.status==='testing'?'warning':''}">${({done:'已测评',testing:'测评中',untested:'未测评'})[r.status]}</span></div>`;const foot=el('div','cp-foot');foot.append(btn(r.status==='done'?'学习力报告':'学习力测评',()=>r.status==='done'?report(s):confirmStart(s),'btn bx-link'));card.append(foot);grid.append(card);}root.append(grid);
    }
    function confirmStart(s){const body=open('发起学习力测评',[btn('取消',close),btn('进入演示测评',()=>{records[s.id]={...records[s.id],status:'testing',startedAt:Date.now()};persist();paint();assessment(s);},'btn btn-primary')]);help(body,`即将为 ${s.name} 进入学习力测评。`);body.append(el('div','cp-note','正式服务由好专业提供，完成报告按项目规则计费 100 元/次。当前为独立演示，无第三方鉴权与真实扣费，也不会同步家长端。'));}
    function assessment(s){const body=open('学习力测评 · '+s.name,[btn('暂存返回',close),btn('模拟：完成测评',()=>{records[s.id]={...records[s.id],status:'done',completedAt:Date.now()};persist();paint();report(s);},'btn btn-primary')]);body.append(el('div','cp-note','此区域承载好专业第三方测评。沿用既有原型的模拟完成入口，用于体验测评中、返回继续、报告及重测流程；不采集真实问卷，不产生真实学习力评估。'));}
    async function download(s,button){await busy(button,async()=>{const blob=await pdfText('学习力报告 · 演示',[s.name+' · '+s.grade,'测评状态：已测评','本文件为流程演示，不含真实测评结论。','正式报告由第三方测评服务生成。']);await downloadBlob(blob,s.name+'-学习力演示报告.pdf','learning','diagnosis:'+s.id);toast('演示报告已保存到下载中心');});}
    function report(s){const downloadButton=btn('下载 PDF',()=>void download(s,downloadButton),'btn btn-primary');const body=open('学习力报告 · '+s.name,[btn('重新测评',()=>confirmStart(s)),downloadButton]);body.append(el('div','cp-paper'));const paper=body.lastElementChild;paper.append(el('h3','','学习力报告'),el('p','',s.name+' · '+s.grade),el('div','cp-summary'));for(const label of ['学习潜力','学习动力','学习效力']){const stat=el('div','cp-stat');stat.append(el('span','',label),el('strong','','示例'));paper.lastElementChild.append(stat);}help(paper,'当前仅展示报告结构，不代表学员真实能力。正式测评完成后由好专业生成具体维度分析、优势与建议。');}
    refreshPage=apply;apply();
  }

  function attendance(){
    let state={keyword:'',where:'in',phase:'all'},records=read(STORE_KEY,{date:day(Date.now()),students:{}});
    if(records.date!==day(Date.now()))records={date:day(Date.now()),students:{}};
    const six=['no-data','pending','generating','ready','printing','printed'];
    const statusLabels={'no-data':'暂未产生学习数据',pending:'待生成日报',generating:'日报生成中',ready:'日报待打印',printing:'日报打印中',printed:'已打印日报'};
    if(!Object.keys(records.students).length)roster().slice(0,8).forEach((s,i)=>{records.students[s.id]={inStore:i<6,phase:six[i%6],signedInAt:Date.now()-3600000,phaseReadyAt:['generating','printing'].includes(six[i%6])?Date.now()+4000:null,example:true};});
    const persist=()=>localStorage.setItem(STORE_KEY,JSON.stringify(records));persist();
    $('cpTodayWrap').hidden=true;$('cpCards').hidden=true;$('cpTable').hidden=true;$('cpSort').hidden=true;
    $('cpStatus').innerHTML='<option value="all">全部日报状态</option>'+six.map(k=>`<option value="${k}">${statusLabels[k]}</option>`).join('');
    const tabs=el('div','cp-store-tabs');const inBtn=btn('在店',()=>{state.where='in';apply();}),outBtn=btn('离店',()=>{state.where='out';apply();}),allBtn=btn('全部',()=>{state.where='all';apply();});tabs.append(inBtn,outBtn,allBtn);$('cpToolbar').prepend(tabs);
    const checkin=btn('学员签到',checkinDialog,'btn btn-primary');document.querySelector('.nav-actions').append(checkin);
    const pager=Pager.create({root:$('cpPager'),pageSize:12,pageSizeOptions:[12,24,48],total:0,onChange:paint});
    $('cpSearch').addEventListener('input',()=>{state.keyword=$('cpSearch').value.trim();apply();});$('cpStatus').addEventListener('change',()=>{state.phase=$('cpStatus').value;apply();});
    $('cpClear').addEventListener('click',()=>{state.keyword='';state.phase='all';$('cpSearch').value='';$('cpStatus').value='all';apply();});
    function matching(){return roster().filter(s=>{const r=records.students[s.id];return r&&(!state.keyword||s.name.includes(state.keyword))&&(state.where==='all'||(state.where==='in'?r.inStore:!r.inStore))&&(state.phase==='all'||r.phase===state.phase);});}
    function apply(){pager.setTotal(matching().length,{page:1,silent:true});paint();}
    function paint(){const all=matching(),range=pager.range(),root=$('cpResults');root.replaceChildren();$('cpCount').textContent=`共 ${all.length} 位学员`;inBtn.setAttribute('aria-pressed',String(state.where==='in'));outBtn.setAttribute('aria-pressed',String(state.where==='out'));allBtn.setAttribute('aria-pressed',String(state.where==='all'));
      if(!all.length){root.append(empty('当前筛选下暂无学员'));return;}
      const grid=el('div','cp-grid');for(const s of all.slice(range.start,range.end)){const r=records.students[s.id],canGenerate=['pending','ready','printed'].includes(r.phase),canPrint=['ready','printed'].includes(r.phase),canLeave=['no-data','ready','printed'].includes(r.phase);const card=el('article','bx-list-surface cp-card');card.innerHTML=`<div class="cp-body"><img class="cp-avatar" src="${esc(s.avatar)}" alt=""><div class="cp-info"><div class="cp-name">${esc(s.name)}</div><div class="cp-sub">${esc(s.grade)} · ${r.inStore?'在店':'离店'}</div><div class="cp-date">签到 ${esc(date(r.signedInAt))}</div></div></div><div class="cp-metrics">${esc(statusLabels[r.phase])}</div>`;
        const foot=el('div','cp-foot');foot.append(btn('生成日报',()=>{r.phase='generating';r.phaseReadyAt=Date.now()+4000;persist();paint();},'btn bx-link',!canGenerate),btn('打印日报',()=>printDaily(s),'btn bx-link',!canPrint));if(r.inStore)foot.append(btn('签退',()=>{const body=open('确认签退',[btn('取消',close),btn('确认签退',()=>{r.inStore=false;r.signedOutAt=Date.now();persist();close();apply();toast('已签退；当前演示不发送家长消息');},'btn btn-primary')]);help(body,`确认将 ${s.name} 签退？${r.phase==='no-data'?'当前无学习数据，将直接签退。':'日报已生成，可携带日报离店。'}`);},'btn bx-link',!canLeave));card.append(foot);grid.append(card);}root.append(grid);
    }
    function checkinDialog(){let chosen='';const submit=btn('确认签到',()=>{if(!chosen)return;records.students[chosen]={inStore:true,phase:'no-data',signedInAt:Date.now()};persist();close();state.where='in';apply();toast('签到成功');},'btn btn-primary',true),body=open('学员签到',[btn('取消',close),submit]);
      const select=el('select','cp-field');select.setAttribute('aria-label','选择签到学员');select.innerHTML='<option value="">请选择学员</option>'+roster().filter(s=>!records.students[s.id]?.inStore).map(s=>`<option value="${esc(s.id)}">${esc(s.name)} · ${esc(s.grade)}</option>`).join('');select.addEventListener('change',()=>{chosen=select.value;submit.disabled=!chosen;});body.append(select);help(body,'已在店学员不会重复签到。');
    }
    function printDaily(s){const r=records.students[s.id],confirm=btn('打印日报',()=>void busy(confirm,async()=>{
      const blob=await pdfText(s.name+' · 学习日报',[s.grade,'日期：'+records.date,'日报已生成。','此文件为演示日报，不代表真实作业批改结果。']);
      const url=URL.createObjectURL(blob),a=el('a');a.href=url;a.target='_blank';a.rel='noopener';a.click();setTimeout(()=>URL.revokeObjectURL(url),60000);
      r.phase='printing';r.phaseReadyAt=Date.now()+4000;persist();close();paint();toast('已打开日报 PDF，可使用浏览器打印；演示将模拟打印完成');
    }),'btn btn-primary');const body=open('打印学习日报',[btn('取消',close),confirm]);help(body,`为 ${s.name} 打开日报 PDF。当前没有连接实体打印机，打印状态沿用原型模拟回调。`);}
    async function refresh(){let changed=false;for(const [id,r] of Object.entries(records.students)){
      if(r.phaseReadyAt&&Date.now()>=r.phaseReadyAt){r.phase=r.phase==='generating'?'ready':'printed';delete r.phaseReadyAt;changed=true;}
      const tasks=(await C.localTasks(id)).filter(t=>t.kind!=='wrong'&&t.review&&day(t.createdAt)===records.date);
      const signature=JSON.stringify(tasks.map(t=>[t.id,t.review]).sort((a,b)=>a[0].localeCompare(b[0])));
      if(tasks.length&&r.dataSignature!==signature){
        if(r.phase==='no-data')r.phase='pending';
        else {r.phase='generating';r.phaseReadyAt=Date.now()+4000;}
        r.dataSignature=signature;changed=true;
      }
    }if(changed){persist();pager.setTotal(matching().length,{silent:true});paint();}}
    refreshPage=()=>{apply();void refresh().catch(e=>toast(e.message));};refreshPage();setInterval(()=>void refresh().catch(e=>toast(e.message)),2000);
  }

  async function pdfText(title,lines){
    await document.fonts.ready;const canvas=el('canvas');canvas.width=1240;canvas.height=1754;const c=canvas.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,1240,1754);c.fillStyle='#0054fd';c.font='bold 36px system-ui';c.fillText(title,70,100,1100);c.fillStyle='#464b60';c.font='26px system-ui';let y=180;for(const text of lines){let line='';for(const char of text){if(c.measureText(line+char).width>1100){c.fillText(line,70,y);y+=48;line='';}line+=char;}c.fillText(line,70,y);y+=64;}const blob=PDF.imagePdf([PDF.jpegBytes(canvas)]);canvas.width=canvas.height=0;return blob;
  }
  async function downloadBlob(blob,name,fileKind,sourceId){
    const file=await Files.record({id:'complete:'+sourceId,kind:fileKind,name,blob,sourceTaskId:sourceId});const url=URL.createObjectURL(file.blob),a=el('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  }
}
