// Extracted from the reviewed CloudBase student-detail module, 20261030-1344.
export function bootstrap(env){
const {window,document,history,location,setTimeout,clearTimeout,setInterval,clearInterval,requestAnimationFrame,cancelAnimationFrame,ResizeObserver,MutationObserver}=env;
const globalThis=window;
window.BanxueDemoCatalog={"aliases":{"demo-mobile-001":"demo-mobile-001","demo-mobile-002":"demo-mobile-002","demo-mobile-003":"demo-mobile-003","demo-mobile-004":"demo-mobile-004","demo-mobile-005":"demo-mobile-005","demo-mobile-006":"demo-mobile-006","demo-mobile-007":"demo-mobile-007","demo-mobile-008":"demo-mobile-008","demo-mobile-009":"demo-mobile-009","demo-mobile-010":"demo-mobile-010","demo-mobile-011":"demo-mobile-011","demo-mobile-012":"demo-mobile-012","demo-mobile-013":"demo-mobile-013","demo-mobile-014":"demo-mobile-014","demo-mobile-015":"demo-mobile-015","demo-mobile-016":"demo-mobile-016","demo-mobile-017":"demo-mobile-017","demo-mobile-018":"demo-mobile-018","demo-mobile-019":"demo-mobile-019","demo-mobile-020":"demo-mobile-020","demo-mobile-021":"demo-mobile-021","demo-mobile-023":"demo-mobile-023","demo-mobile-024":"demo-mobile-024","demo-mobile-025":"demo-mobile-025","demo-mobile-026":"demo-mobile-026","demo-mobile-027":"demo-mobile-027","demo-mobile-028":"demo-mobile-028","demo-mobile-029":"demo-mobile-029","demo-mobile-030":"demo-mobile-030","demo-mobile-031":"demo-mobile-031","demo-mobile-032":"demo-mobile-032","demo-mobile-033":"demo-mobile-033","demo-mobile-034":"demo-mobile-034","demo-mobile-035":"demo-mobile-035","demo-mobile-036":"demo-mobile-036","demo-mobile-037":"demo-mobile-037","demo-mobile-038":"demo-mobile-038","demo-mobile-039":"demo-mobile-039","demo-mobile-040":"demo-mobile-040","demo-mobile-041":"demo-mobile-041","demo-mobile-042":"demo-mobile-042","demo-mobile-043":"demo-mobile-043","demo-mobile-044":"demo-mobile-044","demo-mobile-045":"demo-mobile-045","demo-mobile-046":"demo-mobile-046","demo-mobile-047":"demo-mobile-047","demo-mobile-048":"demo-mobile-048","demo-mobile-049":"demo-mobile-049","demo-mobile-050":"demo-mobile-050","demo-mobile-051":"demo-mobile-051","demo-mobile-052":"demo-mobile-052","demo-mobile-053":"demo-mobile-053","demo-mobile-054":"demo-mobile-054","demo-student-001":"demo-student-001","demo-student-002":"demo-student-002","demo-student-003":"demo-student-003","demo-student-004":"demo-student-004","demo-student-005":"demo-student-005","demo-student-006":"demo-student-006","demo-student-007":"demo-student-007","demo-student-008":"demo-student-008","demo-student-009":"demo-student-009","demo-student-010":"demo-student-010","demo-student-011":"demo-student-011","demo-student-012":"demo-student-012","demo-student-013":"demo-student-013","demo-student-014":"demo-student-014","demo-student-015":"demo-student-015","demo-student-016":"demo-student-016","demo-student-017":"demo-student-017","demo-student-018":"demo-student-018","demo-student-019":"demo-student-019","demo-student-020":"demo-student-020","demo-student-021":"demo-student-021","demo-student-022":"demo-student-022","demo-student-023":"demo-student-023","demo-student-024":"demo-student-024","demo-student-025":"demo-student-025","demo-student-026":"demo-student-026","demo-student-027":"demo-student-027","demo-student-028":"demo-student-028","demo-student-029":"demo-student-029","demo-student-030":"demo-student-030","demo-student-031":"demo-student-031","demo-student-032":"demo-student-032","demo-student-033":"demo-student-033","demo-student-034":"demo-student-034","demo-student-035":"demo-student-035","demo-student-036":"demo-student-036","demo-student-037":"demo-student-037","demo-student-038":"demo-student-038","demo-student-039":"demo-student-039","demo-student-040":"demo-student-040","demo-student-041":"demo-student-041","demo-student-042":"demo-student-042","demo-student-043":"demo-student-043","demo-student-044":"demo-student-044","demo-student-045":"demo-student-045","demo-student-046":"demo-student-046","demo-student-047":"demo-student-047","demo-student-048":"demo-student-048","demo-student-049":"demo-student-049","demo-student-050":"demo-student-050","demo-student-051":"demo-student-051","demo-student-052":"demo-student-052","demo-student-053":"demo-student-053","demo-student-054":"demo-student-054","demo-student-055":"demo-student-055","demo-student-056":"demo-student-056","demo-student-057":"demo-student-057","demo-student-058":"demo-student-058","demo-student-059":"demo-student-059","demo-student-060":"demo-student-060","demo-student-061":"demo-student-061","demo-student-062":"demo-student-062","demo-student-063":"demo-student-063","demo-student-064":"demo-student-064","demo-student-065":"demo-student-065","demo-student-何克金":"demo-task-student-017","demo-student-冯钰洁":"demo-task-student-016","demo-student-冯靖宇":"demo-task-student-006","demo-student-吴易奚":"demo-task-student-010","demo-student-吴汉明":"demo-task-student-003","demo-student-周铮":"demo-task-student-002","demo-student-孙芳":"demo-task-student-001","demo-student-张小明":"demo-task-student-018","demo-student-李建华":"demo-task-student-019","demo-student-李豫卓":"demo-task-student-007","demo-student-李鑫宇":"demo-task-student-008","demo-student-林小满":"demo-student-027","demo-student-王小明":"demo-task-student-014","demo-student-王江":"demo-task-student-011","demo-student-赵子峰":"demo-task-student-020","demo-student-赵立民":"demo-task-student-005","demo-student-郑美萍":"demo-task-student-015","demo-student-钱泊雯":"demo-task-student-004","demo-student-钱浩均":"demo-task-student-009","demo-student-陈悦":"demo-task-student-013","demo-task-student-001":"demo-task-student-001","demo-task-student-002":"demo-task-student-002","demo-task-student-003":"demo-task-student-003","demo-task-student-004":"demo-task-student-004","demo-task-student-005":"demo-task-student-005","demo-task-student-006":"demo-task-student-006","demo-task-student-007":"demo-task-student-007","demo-task-student-008":"demo-task-student-008","demo-task-student-009":"demo-task-student-009","demo-task-student-010":"demo-task-student-010","demo-task-student-011":"demo-task-student-011","demo-task-student-013":"demo-task-student-013","demo-task-student-014":"demo-task-student-014","demo-task-student-015":"demo-task-student-015","demo-task-student-016":"demo-task-student-016","demo-task-student-017":"demo-task-student-017","demo-task-student-018":"demo-task-student-018","demo-task-student-019":"demo-task-student-019","demo-task-student-020":"demo-task-student-020","s1":"s1","s2":"s2","s3":"s3","s4":"s4","s5":"s5","s6":"s6","s7":"s7","s8":"s8","s9":"s9","s10":"s10","s11":"s11","s12":"s12","s13":"s13","s14":"s14","s15":"s15","s16":"s16","s17":"s17","s18":"s18","s19":"s19","s20":"s20","s21":"s21","s22":"s22","s23":"s23","s24":"s24","丁一凡-2-ding yi fan":"demo-mobile-008","任子豪-5-ren zi hao":"demo-mobile-035","何嘉乐-3-he jia le":"demo-mobile-015","倪可欣-2-ni ke xin":"demo-mobile-028","冯宇航-6-feng yu hang":"demo-mobile-011","刘强-4-liu qiang":"demo-mobile-023","包晨-2-bao chen":"demo-mobile-003","叶子涵-2-ye zi han":"demo-mobile-049","吴子墨-6-wu zi mo":"demo-mobile-044","周杰-3-zhou jie":"demo-mobile-053","唐思源-5-tang si yuan":"demo-mobile-040","夏安然-2-xia an ran":"demo-mobile-045","姜浩宇-6-jiang hao yu":"demo-mobile-017","孔令琪-3-kong ling qi":"demo-mobile-020","孙一诺-2-sun yi nuo":"demo-mobile-039","孟浩然-3-meng hao ran":"demo-mobile-027","宋佳琪-6-song jia qi":"demo-mobile-038","崔浩然-3-cui hao ran":"demo-mobile-006","康欣然-5-kang xin ran":"demo-mobile-019","张伟-5-zhang wei":"demo-mobile-051","彭宇轩-6-peng yu xuan":"demo-mobile-032","徐浩宇-3-xu hao yu":"demo-mobile-047","方可欣-3-fang ke xin":"demo-mobile-010","曹雨欣-5-cao yu xin":"demo-mobile-004","朱欣然-4-zhu xin ran":"demo-mobile-054","李静-4-li jing":"demo-mobile-021","杨可欣-4-yang ke xin":"demo-mobile-048","林小满-2-lin xiao man":"demo-student-027","欧阳子涵-5-ou yang zi han":"demo-mobile-030","沈欣悦-3-shen xin yue":"demo-mobile-036","潘嘉怡-3-pan jia yi":"demo-mobile-031","牛晨曦-4-niu chen xi":"demo-mobile-029","王小红-3-wang xiao hong":"demo-mobile-042","田雨欣-3-tian yu xin":"demo-mobile-041","白若溪-4-bai ruo xi":"demo-mobile-002","石浩然-4-shi hao ran":"demo-mobile-037","秦若曦-2-qin ruo xi":"demo-mobile-034","罗子睿-6-luo zi rui":"demo-mobile-025","胡欣怡-4-hu xin yi":"demo-mobile-016","艾佳宁-3-ai jia ning":"demo-mobile-001","袁思琪-6-yuan si qi":"demo-mobile-050","谢雨桐-5-xie yu tong":"demo-mobile-046","赵丽华-5-zhao li hua":"demo-mobile-052","邓子墨-4-deng zi mo":"demo-mobile-007","郭雨桐-2-guo yu tong":"demo-mobile-013","鄂文博-5-e wen bo":"demo-mobile-009","金子轩-2-jin zi xuan":"demo-mobile-018","钱文博-4-qian wen bo":"demo-mobile-033","陆雪-4-lu xue":"demo-mobile-024","陈婷-6-chen ting":"demo-mobile-005","韩思远-5-han si yuan":"demo-mobile-014","马思琪-5-ma si qi":"demo-mobile-026","高子涵-4-gao zi han":"demo-mobile-012","魏晨曦-4-wei chen xi":"demo-mobile-043"},"avatarSources":{"avatar-blue.png":"03-小程序版/demos/workbench/assets/students/avatar-blue.png","avatar-green.png":"03-小程序版/demos/workbench/assets/students/avatar-green.png","avatar-li.png":"03-小程序版/demos/workbench/assets/students/avatar-li.png","avatar-liu.png":"03-小程序版/demos/workbench/assets/students/avatar-liu.png","avatar-lu.png":"03-小程序版/demos/workbench/assets/students/avatar-lu.png","learning-avatar-green.png":"02-pc版/demos/learning-analysis/assets/avatar-green.png","learning-avatar-navy.png":"02-pc版/demos/learning-analysis/assets/avatar-navy.png","learning-avatar-orange.png":"02-pc版/demos/learning-analysis/assets/avatar-orange.png","learning-avatar-purple.png":"02-pc版/demos/learning-analysis/assets/avatar-purple.png"},"grades":["一年级","二年级","三年级","四年级","五年级","六年级","初一","初二","初三","高一","高二","高三"],"learningFixtures":{"demo-mobile-001":"s1","demo-mobile-002":"s2","demo-mobile-003":"s3","demo-mobile-004":"s4","demo-mobile-005":"s5","demo-mobile-006":"s6","demo-mobile-007":"s7","demo-mobile-008":"s8","demo-mobile-009":"s9","demo-mobile-010":"s10","demo-mobile-011":"s11","demo-mobile-012":"s12","demo-mobile-013":"s13","demo-mobile-014":"s14","demo-mobile-015":"s15","demo-mobile-016":"s16","demo-mobile-017":"s17","demo-mobile-018":"s18","demo-mobile-019":"s19","demo-mobile-020":"s20","demo-mobile-021":"s21","demo-mobile-023":"s23","demo-mobile-024":"s24","demo-mobile-025":"s1","demo-mobile-026":"s2","demo-mobile-027":"s3","demo-mobile-028":"s4","demo-mobile-029":"s5","demo-mobile-030":"s6","demo-mobile-031":"s7","demo-mobile-032":"s8","demo-mobile-033":"s9","demo-mobile-034":"s10","demo-mobile-035":"s11","demo-mobile-036":"s12","demo-mobile-037":"s13","demo-mobile-038":"s14","demo-mobile-039":"s15","demo-mobile-040":"s16","demo-mobile-041":"s17","demo-mobile-042":"s18","demo-mobile-043":"s19","demo-mobile-044":"s20","demo-mobile-045":"s21","demo-mobile-046":"s22","demo-mobile-047":"s23","demo-mobile-048":"s24","demo-mobile-049":"s1","demo-mobile-050":"s2","demo-mobile-051":"s3","demo-mobile-052":"s4","demo-mobile-053":"s5","demo-mobile-054":"s6","demo-student-001":"s1","demo-student-002":"s2","demo-student-003":"s3","demo-student-004":"s5","demo-student-005":"s6","demo-student-006":"s7","demo-student-007":"s8","demo-student-008":"s9","demo-student-009":"s10","demo-student-010":"s11","demo-student-011":"s12","demo-student-012":"s13","demo-student-013":"s14","demo-student-014":"s15","demo-student-015":"s16","demo-student-016":"s17","demo-student-017":"s18","demo-student-018":"s19","demo-student-019":"s20","demo-student-020":"s21","demo-student-021":"s22","demo-student-022":"s23","demo-student-023":"s24","demo-student-024":"s1","demo-student-025":"s2","demo-student-026":"s3","demo-student-027":"s22","demo-student-028":"s6","demo-student-029":"s7","demo-student-030":"s8","demo-student-031":"s9","demo-student-032":"s10","demo-student-033":"s11","demo-student-034":"s12","demo-student-035":"s13","demo-student-036":"s14","demo-student-037":"s15","demo-student-038":"s16","demo-student-039":"s17","demo-student-040":"s18","demo-student-041":"s19","demo-student-042":"s20","demo-student-043":"s21","demo-student-044":"s22","demo-student-045":"s23","demo-student-046":"s24","demo-student-047":"s1","demo-student-048":"s2","demo-student-049":"s3","demo-student-050":"s5","demo-student-051":"s6","demo-student-052":"s7","demo-student-053":"s8","demo-student-054":"s9","demo-student-055":"s10","demo-student-056":"s11","demo-student-057":"s12","demo-student-058":"s13","demo-student-059":"s14","demo-student-060":"s15","demo-student-061":"s16","demo-student-062":"s17","demo-student-063":"s18","demo-student-064":"s19","demo-student-065":"s20","demo-task-student-001":"s1","demo-task-student-002":"s2","demo-task-student-003":"s3","demo-task-student-004":"s5","demo-task-student-005":"s6","demo-task-student-006":"s7","demo-task-student-007":"s8","demo-task-student-008":"s9","demo-task-student-009":"s10","demo-task-student-010":"s11","demo-task-student-011":"s12","demo-task-student-013":"s14","demo-task-student-014":"s15","demo-task-student-015":"s16","demo-task-student-016":"s17","demo-task-student-017":"s18","demo-task-student-018":"s19","demo-task-student-019":"s20","demo-task-student-020":"s21","s1":"s1","s2":"s2","s3":"s3","s4":"s4","s5":"s5","s6":"s6","s7":"s7","s8":"s8","s9":"s9","s10":"s10","s11":"s11","s12":"s12","s13":"s13","s14":"s14","s15":"s15","s16":"s16","s17":"s17","s18":"s18","s19":"s19","s20":"s20","s21":"s21","s22":"s22","s23":"s23","s24":"s24"},"legacyTaskNames":{"何克金":"demo-task-student-017","冯钰洁":"demo-task-student-016","冯靖宇":"demo-task-student-006","吴易奚":"demo-task-student-010","吴汉明":"demo-task-student-003","周铮":"demo-task-student-002","孙芳":"demo-task-student-001","张小明":"demo-task-student-018","李建华":"demo-task-student-019","李豫卓":"demo-task-student-007","李鑫宇":"demo-task-student-008","林小满":"demo-student-027","王小明":"demo-task-student-014","王江":"demo-task-student-011","赵子峰":"demo-task-student-020","赵立民":"demo-task-student-005","郑美萍":"demo-task-student-015","钱泊雯":"demo-task-student-004","钱浩均":"demo-task-student-009","陈悦":"demo-task-student-013"},"provenance":{"emptyFixtures":["s4"],"fictional":true,"merges":[{"alias":"林小满-2-lin xiao man","canonicalId":"demo-student-027","reason":"原 PC 与手机固定名册中的同名同年级样例；显式登记，不在运行时按姓名猜测"}],"sources":["PC student-list fixture 20261019-1350","Mobile studentData 20261019-0956","PC learning data 20261019-1501","Mobile task-engine seed names"]},"schemaVersion":1,"students":[{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-001","monthlyActivityRank":1,"name":"安可","note":"","parentPhone":"","pinyin":"an ke"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-002","monthlyActivityRank":2,"name":"白晨","note":"","parentPhone":"","pinyin":"bai chen"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":12,"id":"demo-student-003","monthlyActivityRank":3,"name":"蔡子轩","note":"","parentPhone":"","pinyin":"cai zi xuan"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-004","monthlyActivityRank":4,"name":"陈安","note":"","parentPhone":"","pinyin":"chen an"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-005","monthlyActivityRank":5,"name":"陈沐阳","note":"","parentPhone":"","pinyin":"chen mu yang"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-student-006","monthlyActivityRank":6,"name":"陈思涵","note":"","parentPhone":"","pinyin":"chen si han"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":8,"id":"demo-student-007","monthlyActivityRank":7,"name":"陈一诺","note":"","parentPhone":"","pinyin":"chen yi nuo"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":1,"id":"demo-student-008","monthlyActivityRank":8,"name":"邓语桐","note":"","parentPhone":"","pinyin":"deng yu tong"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-student-009","monthlyActivityRank":9,"name":"丁浩然","note":"","parentPhone":"","pinyin":"ding hao ran"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":11,"id":"demo-student-010","monthlyActivityRank":10,"name":"杜若凡","note":"","parentPhone":"","pinyin":"du ruo fan"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-student-011","monthlyActivityRank":11,"name":"方知夏","note":"","parentPhone":"","pinyin":"fang zhi xia"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":9,"id":"demo-student-012","monthlyActivityRank":12,"name":"冯乐宁","note":"","parentPhone":"","pinyin":"feng le ning"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-013","monthlyActivityRank":13,"name":"高子墨","note":"","parentPhone":"","pinyin":"gao zi mo"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-014","monthlyActivityRank":14,"name":"顾星河","note":"","parentPhone":"","pinyin":"gu xing he"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":12,"id":"demo-student-015","monthlyActivityRank":15,"name":"郭可欣","note":"","parentPhone":"","pinyin":"guo ke xin"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-016","monthlyActivityRank":16,"name":"韩宇航","note":"","parentPhone":"","pinyin":"han yu hang"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-017","monthlyActivityRank":17,"name":"何雨晴","note":"","parentPhone":"","pinyin":"he yu qing"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-student-018","monthlyActivityRank":18,"name":"胡佳宁","note":"","parentPhone":"","pinyin":"hu jia ning"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":8,"id":"demo-student-019","monthlyActivityRank":19,"name":"黄梓涵","note":"","parentPhone":"","pinyin":"huang zi han"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":1,"id":"demo-student-020","monthlyActivityRank":20,"name":"江予安","note":"","parentPhone":"","pinyin":"jiang yu an"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-student-021","monthlyActivityRank":21,"name":"蒋思远","note":"","parentPhone":"","pinyin":"jiang si yuan"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":11,"id":"demo-student-022","monthlyActivityRank":22,"name":"孔令仪","note":"","parentPhone":"","pinyin":"kong ling yi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-student-023","monthlyActivityRank":23,"name":"李沐宸","note":"","parentPhone":"","pinyin":"li mu chen"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":9,"id":"demo-student-024","monthlyActivityRank":24,"name":"李思齐","note":"","parentPhone":"","pinyin":"li si qi"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-025","monthlyActivityRank":25,"name":"李一禾","note":"","parentPhone":"","pinyin":"li yi he"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-026","monthlyActivityRank":26,"name":"梁初晴","note":"","parentPhone":"","pinyin":"liang chu qing"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-027","monthlyActivityRank":27,"name":"林小满","note":"","parentPhone":"","pinyin":"lin xiao man"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-028","monthlyActivityRank":28,"name":"林知远","note":"","parentPhone":"","pinyin":"lin zhi yuan"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-029","monthlyActivityRank":29,"name":"刘可心","note":"","parentPhone":"","pinyin":"liu ke xin"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-student-030","monthlyActivityRank":30,"name":"刘星辰","note":"","parentPhone":"","pinyin":"liu xing chen"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":8,"id":"demo-student-031","monthlyActivityRank":31,"name":"陆景行","note":"","parentPhone":"","pinyin":"lu jing xing"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":1,"id":"demo-student-032","monthlyActivityRank":32,"name":"罗以宁","note":"","parentPhone":"","pinyin":"luo yi ning"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-student-033","monthlyActivityRank":33,"name":"马晨曦","note":"","parentPhone":"","pinyin":"ma chen xi"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":11,"id":"demo-student-034","monthlyActivityRank":34,"name":"毛子谦","note":"","parentPhone":"","pinyin":"mao zi qian"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-student-035","monthlyActivityRank":35,"name":"孟欣然","note":"","parentPhone":"","pinyin":"meng xin ran"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":9,"id":"demo-student-036","monthlyActivityRank":36,"name":"潘书瑶","note":"","parentPhone":"","pinyin":"pan shu yao"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-037","monthlyActivityRank":37,"name":"彭予希","note":"","parentPhone":"","pinyin":"peng yu xi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-038","monthlyActivityRank":38,"name":"秦乐言","note":"","parentPhone":"","pinyin":"qin le yan"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":12,"id":"demo-student-039","monthlyActivityRank":39,"name":"邱泽宇","note":"","parentPhone":"","pinyin":"qiu ze yu"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-040","monthlyActivityRank":40,"name":"任知微","note":"","parentPhone":"","pinyin":"ren zhi wei"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-041","monthlyActivityRank":41,"name":"沈一诺","note":"","parentPhone":"","pinyin":"shen yi nuo"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-student-042","monthlyActivityRank":42,"name":"石锦程","note":"","parentPhone":"","pinyin":"shi jin cheng"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":8,"id":"demo-student-043","monthlyActivityRank":43,"name":"宋初宁","note":"","parentPhone":"","pinyin":"song chu ning"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":1,"id":"demo-student-044","monthlyActivityRank":44,"name":"苏语禾","note":"","parentPhone":"","pinyin":"su yu he"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-student-045","monthlyActivityRank":45,"name":"孙浩宇","note":"","parentPhone":"","pinyin":"sun hao yu"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":11,"id":"demo-student-046","monthlyActivityRank":46,"name":"唐若溪","note":"","parentPhone":"","pinyin":"tang ruo xi"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-student-047","monthlyActivityRank":47,"name":"陶嘉树","note":"","parentPhone":"","pinyin":"tao jia shu"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":9,"id":"demo-student-048","monthlyActivityRank":48,"name":"汪晨阳","note":"","parentPhone":"","pinyin":"wang chen yang"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-049","monthlyActivityRank":49,"name":"王乐安","note":"","parentPhone":"","pinyin":"wang le an"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-050","monthlyActivityRank":50,"name":"王沐晴","note":"","parentPhone":"","pinyin":"wang mu qing"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":12,"id":"demo-student-051","monthlyActivityRank":51,"name":"韦子涵","note":"","parentPhone":"","pinyin":"wei zi han"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-052","monthlyActivityRank":52,"name":"吴嘉禾","note":"","parentPhone":"","pinyin":"wu jia he"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-053","monthlyActivityRank":53,"name":"夏星野","note":"","parentPhone":"","pinyin":"xia xing ye"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-student-054","monthlyActivityRank":54,"name":"肖予宁","note":"","parentPhone":"","pinyin":"xiao yu ning"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":8,"id":"demo-student-055","monthlyActivityRank":55,"name":"谢清和","note":"","parentPhone":"","pinyin":"xie qing he"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":1,"id":"demo-student-056","monthlyActivityRank":56,"name":"徐以安","note":"","parentPhone":"","pinyin":"xu yi an"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-student-057","monthlyActivityRank":57,"name":"许一鸣","note":"","parentPhone":"","pinyin":"xu yi ming"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":11,"id":"demo-student-058","monthlyActivityRank":58,"name":"杨乐川","note":"","parentPhone":"","pinyin":"yang le chuan"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-student-059","monthlyActivityRank":59,"name":"姚可盈","note":"","parentPhone":"","pinyin":"yao ke ying"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":9,"id":"demo-student-060","monthlyActivityRank":60,"name":"叶知秋","note":"","parentPhone":"","pinyin":"ye zhi qiu"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-student-061","monthlyActivityRank":61,"name":"尹思源","note":"","parentPhone":"","pinyin":"yin si yuan"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-student-062","monthlyActivityRank":62,"name":"张嘉宁","note":"","parentPhone":"","pinyin":"zhang jia ning"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":12,"id":"demo-student-063","monthlyActivityRank":63,"name":"赵沐然","note":"","parentPhone":"","pinyin":"zhao mu ran"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-student-064","monthlyActivityRank":64,"name":"周可乐","note":"","parentPhone":"","pinyin":"zhou ke le"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":10,"id":"demo-student-065","monthlyActivityRank":65,"name":"朱语桐","note":"","parentPhone":"","pinyin":"zhu yu tong"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-001","monthlyActivityRank":66,"name":"艾佳宁","note":"","parentPhone":"","pinyin":"ai jia ning"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-002","monthlyActivityRank":67,"name":"白若溪","note":"","parentPhone":"","pinyin":"bai ruo xi"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-003","monthlyActivityRank":68,"name":"包晨","note":"","parentPhone":"","pinyin":"bao chen"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-004","monthlyActivityRank":69,"name":"曹雨欣","note":"","parentPhone":"","pinyin":"cao yu xin"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-005","monthlyActivityRank":70,"name":"陈婷","note":"","parentPhone":"","pinyin":"chen ting"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-006","monthlyActivityRank":71,"name":"崔浩然","note":"","parentPhone":"","pinyin":"cui hao ran"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-007","monthlyActivityRank":72,"name":"邓子墨","note":"","parentPhone":"","pinyin":"deng zi mo"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-008","monthlyActivityRank":73,"name":"丁一凡","note":"","parentPhone":"","pinyin":"ding yi fan"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-009","monthlyActivityRank":74,"name":"鄂文博","note":"","parentPhone":"","pinyin":"e wen bo"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-010","monthlyActivityRank":75,"name":"方可欣","note":"","parentPhone":"","pinyin":"fang ke xin"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-011","monthlyActivityRank":76,"name":"冯宇航","note":"","parentPhone":"","pinyin":"feng yu hang"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-012","monthlyActivityRank":77,"name":"高子涵","note":"","parentPhone":"","pinyin":"gao zi han"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-013","monthlyActivityRank":78,"name":"郭雨桐","note":"","parentPhone":"","pinyin":"guo yu tong"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-014","monthlyActivityRank":79,"name":"韩思远","note":"","parentPhone":"","pinyin":"han si yuan"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-015","monthlyActivityRank":80,"name":"何嘉乐","note":"","parentPhone":"","pinyin":"he jia le"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-016","monthlyActivityRank":81,"name":"胡欣怡","note":"","parentPhone":"","pinyin":"hu xin yi"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-017","monthlyActivityRank":82,"name":"姜浩宇","note":"","parentPhone":"","pinyin":"jiang hao yu"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-018","monthlyActivityRank":83,"name":"金子轩","note":"","parentPhone":"","pinyin":"jin zi xuan"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-019","monthlyActivityRank":84,"name":"康欣然","note":"","parentPhone":"","pinyin":"kang xin ran"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-020","monthlyActivityRank":85,"name":"孔令琪","note":"","parentPhone":"","pinyin":"kong ling qi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-021","monthlyActivityRank":86,"name":"李静","note":"","parentPhone":"","pinyin":"li jing"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-023","monthlyActivityRank":87,"name":"刘强","note":"","parentPhone":"","pinyin":"liu qiang"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-024","monthlyActivityRank":88,"name":"陆雪","note":"","parentPhone":"","pinyin":"lu xue"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-025","monthlyActivityRank":89,"name":"罗子睿","note":"","parentPhone":"","pinyin":"luo zi rui"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-026","monthlyActivityRank":90,"name":"马思琪","note":"","parentPhone":"","pinyin":"ma si qi"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-027","monthlyActivityRank":91,"name":"孟浩然","note":"","parentPhone":"","pinyin":"meng hao ran"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-028","monthlyActivityRank":92,"name":"倪可欣","note":"","parentPhone":"","pinyin":"ni ke xin"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-029","monthlyActivityRank":93,"name":"牛晨曦","note":"","parentPhone":"","pinyin":"niu chen xi"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-030","monthlyActivityRank":94,"name":"欧阳子涵","note":"","parentPhone":"","pinyin":"ou yang zi han"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-031","monthlyActivityRank":95,"name":"潘嘉怡","note":"","parentPhone":"","pinyin":"pan jia yi"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-032","monthlyActivityRank":96,"name":"彭宇轩","note":"","parentPhone":"","pinyin":"peng yu xuan"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-033","monthlyActivityRank":97,"name":"钱文博","note":"","parentPhone":"","pinyin":"qian wen bo"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-034","monthlyActivityRank":98,"name":"秦若曦","note":"","parentPhone":"","pinyin":"qin ruo xi"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-035","monthlyActivityRank":99,"name":"任子豪","note":"","parentPhone":"","pinyin":"ren zi hao"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-036","monthlyActivityRank":100,"name":"沈欣悦","note":"","parentPhone":"","pinyin":"shen xin yue"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-037","monthlyActivityRank":101,"name":"石浩然","note":"","parentPhone":"","pinyin":"shi hao ran"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-038","monthlyActivityRank":102,"name":"宋佳琪","note":"","parentPhone":"","pinyin":"song jia qi"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-039","monthlyActivityRank":103,"name":"孙一诺","note":"","parentPhone":"","pinyin":"sun yi nuo"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-040","monthlyActivityRank":104,"name":"唐思源","note":"","parentPhone":"","pinyin":"tang si yuan"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-041","monthlyActivityRank":105,"name":"田雨欣","note":"","parentPhone":"","pinyin":"tian yu xin"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-042","monthlyActivityRank":106,"name":"王小红","note":"","parentPhone":"","pinyin":"wang xiao hong"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-043","monthlyActivityRank":107,"name":"魏晨曦","note":"","parentPhone":"","pinyin":"wei chen xi"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-044","monthlyActivityRank":108,"name":"吴子墨","note":"","parentPhone":"","pinyin":"wu zi mo"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-045","monthlyActivityRank":109,"name":"夏安然","note":"","parentPhone":"","pinyin":"xia an ran"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-046","monthlyActivityRank":110,"name":"谢雨桐","note":"","parentPhone":"","pinyin":"xie yu tong"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-047","monthlyActivityRank":111,"name":"徐浩宇","note":"","parentPhone":"","pinyin":"xu hao yu"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-048","monthlyActivityRank":112,"name":"杨可欣","note":"","parentPhone":"","pinyin":"yang ke xin"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":2,"id":"demo-mobile-049","monthlyActivityRank":113,"name":"叶子涵","note":"","parentPhone":"","pinyin":"ye zi han"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":6,"id":"demo-mobile-050","monthlyActivityRank":114,"name":"袁思琪","note":"","parentPhone":"","pinyin":"yuan si qi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-051","monthlyActivityRank":115,"name":"张伟","note":"","parentPhone":"","pinyin":"zhang wei"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"demo-mobile-052","monthlyActivityRank":116,"name":"赵丽华","note":"","parentPhone":"","pinyin":"zhao li hua"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":3,"id":"demo-mobile-053","monthlyActivityRank":117,"name":"周杰","note":"","parentPhone":"","pinyin":"zhou jie"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":4,"id":"demo-mobile-054","monthlyActivityRank":118,"name":"朱欣然","note":"","parentPhone":"","pinyin":"zhu xin ran"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s1","monthlyActivityRank":119,"name":"李小明","note":"","parentPhone":"","pinyin":"li xiao ming"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s2","monthlyActivityRank":120,"name":"陈雨桐","note":"","parentPhone":"","pinyin":"chen yu tong"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s3","monthlyActivityRank":121,"name":"周予安","note":"","parentPhone":"","pinyin":"zhou yu an"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s4","monthlyActivityRank":122,"name":"林知夏","note":"","parentPhone":"","pinyin":"lin zhi xia"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s5","monthlyActivityRank":123,"name":"王梓涵","note":"","parentPhone":"","pinyin":"wang zi han"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s6","monthlyActivityRank":124,"name":"张嘉禾","note":"","parentPhone":"","pinyin":"zhang jia he"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s7","monthlyActivityRank":125,"name":"刘奕辰","note":"","parentPhone":"","pinyin":"liu yi chen"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s8","monthlyActivityRank":126,"name":"赵芷晴","note":"","parentPhone":"","pinyin":"zhao zhi qing"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s9","monthlyActivityRank":127,"name":"黄子墨","note":"","parentPhone":"","pinyin":"huang zi mo"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s10","monthlyActivityRank":128,"name":"吴思齐","note":"","parentPhone":"","pinyin":"wu si qi"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s11","monthlyActivityRank":129,"name":"徐沐阳","note":"","parentPhone":"","pinyin":"xu mu yang"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s12","monthlyActivityRank":130,"name":"孙若溪","note":"","parentPhone":"","pinyin":"sun ruo xi"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s13","monthlyActivityRank":131,"name":"朱书言","note":"","parentPhone":"","pinyin":"zhu shu yan"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s14","monthlyActivityRank":132,"name":"胡星野","note":"","parentPhone":"","pinyin":"hu xing ye"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s15","monthlyActivityRank":133,"name":"郭欣然","note":"","parentPhone":"","pinyin":"guo xin ran"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s16","monthlyActivityRank":134,"name":"何景行","note":"","parentPhone":"","pinyin":"he jing xing"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s17","monthlyActivityRank":135,"name":"高语宁","note":"","parentPhone":"","pinyin":"gao yu ning"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s18","monthlyActivityRank":136,"name":"罗一诺","note":"","parentPhone":"","pinyin":"luo yi nuo"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s19","monthlyActivityRank":137,"name":"郑安然","note":"","parentPhone":"","pinyin":"zheng an ran"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s20","monthlyActivityRank":138,"name":"梁浩宇","note":"","parentPhone":"","pinyin":"liang hao yu"},{"avatar":"learning-avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s21","monthlyActivityRank":139,"name":"谢允希","note":"","parentPhone":"","pinyin":"xie yun xi"},{"avatar":"learning-avatar-purple.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s22","monthlyActivityRank":140,"name":"宋明轩","note":"","parentPhone":"","pinyin":"song ming xuan"},{"avatar":"learning-avatar-navy.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s23","monthlyActivityRank":141,"name":"唐悦宁","note":"","parentPhone":"","pinyin":"tang yue ning"},{"avatar":"learning-avatar-orange.png","coach":"","enrolledAt":"","gender":"未设置","grade":5,"id":"s24","monthlyActivityRank":142,"name":"许晨曦","note":"","parentPhone":"","pinyin":"xu chen xi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-001","monthlyActivityRank":143,"name":"孙芳","note":"","parentPhone":"","pinyin":"sun fang"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-002","monthlyActivityRank":144,"name":"周铮","note":"","parentPhone":"","pinyin":"zhou zheng"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-003","monthlyActivityRank":145,"name":"吴汉明","note":"","parentPhone":"","pinyin":"wu han ming"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-004","monthlyActivityRank":146,"name":"钱泊雯","note":"","parentPhone":"","pinyin":"qian po wen"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-005","monthlyActivityRank":147,"name":"赵立民","note":"","parentPhone":"","pinyin":"zhao li min"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-006","monthlyActivityRank":148,"name":"冯靖宇","note":"","parentPhone":"","pinyin":"feng jing yu"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-007","monthlyActivityRank":149,"name":"李豫卓","note":"","parentPhone":"","pinyin":"li yu zhuo"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-008","monthlyActivityRank":150,"name":"李鑫宇","note":"","parentPhone":"","pinyin":"li xin yu"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-009","monthlyActivityRank":151,"name":"钱浩均","note":"","parentPhone":"","pinyin":"qian hao jun"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-010","monthlyActivityRank":152,"name":"吴易奚","note":"","parentPhone":"","pinyin":"wu yi xi"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-011","monthlyActivityRank":153,"name":"王江","note":"","parentPhone":"","pinyin":"wang jiang"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-013","monthlyActivityRank":154,"name":"陈悦","note":"","parentPhone":"","pinyin":"chen yue"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-014","monthlyActivityRank":155,"name":"王小明","note":"","parentPhone":"","pinyin":"wang xiao ming"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-015","monthlyActivityRank":156,"name":"郑美萍","note":"","parentPhone":"","pinyin":"zheng mei ping"},{"avatar":"avatar-liu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-016","monthlyActivityRank":157,"name":"冯钰洁","note":"","parentPhone":"","pinyin":"feng yu jie"},{"avatar":"avatar-lu.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-017","monthlyActivityRank":158,"name":"何克金","note":"","parentPhone":"","pinyin":"he ke jin"},{"avatar":"avatar-blue.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-018","monthlyActivityRank":159,"name":"张小明","note":"","parentPhone":"","pinyin":"zhang xiao ming"},{"avatar":"avatar-green.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-019","monthlyActivityRank":160,"name":"李建华","note":"","parentPhone":"","pinyin":"li jian hua"},{"avatar":"avatar-li.png","coach":"","enrolledAt":"","gender":"未设置","grade":7,"id":"demo-task-student-020","monthlyActivityRank":161,"name":"赵子峰","note":"","parentPhone":"","pinyin":"zhao zi feng"}],"version":"20261019-1530","meta":{"anchorDate":"2026-10-14","seed":20261014,"fictionalStudentPerformance":true,"taskCount":889,"realCropCount":45,"cropInstances":18102,"schemaVersion":1,"fixtureOnly":true},"courses":[{"id":"math","name":"小学数学"},{"id":"chinese","name":"小学语文"},{"id":"english","name":"小学英语"}],"knowledge":[{"id":"k01","courseId":"math","name":"小数加减法","path":["数与代数","小数运算","小数加减法"]},{"id":"k02","courseId":"math","name":"小数乘法","path":["数与代数","小数运算","小数乘法"]},{"id":"k03","courseId":"math","name":"小数除法","path":["数与代数","小数运算","小数除法"]},{"id":"k04","courseId":"math","name":"小数四则混合运算","path":["数与代数","小数运算","小数四则混合运算"]},{"id":"k05","courseId":"math","name":"因数与倍数","path":["数与代数","因数与倍数","因数与倍数"]},{"id":"k06","courseId":"math","name":"2、5的倍数特征","path":["数与代数","因数与倍数","2、5的倍数特征"]},{"id":"k07","courseId":"math","name":"质数与合数","path":["数与代数","因数与倍数","质数与合数"]},{"id":"k08","courseId":"math","name":"最大公因数","path":["数与代数","因数与倍数","最大公因数"]},{"id":"k09","courseId":"math","name":"分数的意义","path":["数与代数","分数运算","分数的意义"]},{"id":"k10","courseId":"math","name":"分数的基本性质","path":["数与代数","分数运算","分数的基本性质"]},{"id":"k11","courseId":"math","name":"约分","path":["数与代数","分数运算","约分"]},{"id":"k12","courseId":"math","name":"通分","path":["数与代数","分数运算","通分"]},{"id":"k13","courseId":"math","name":"同分母分数加减","path":["数与代数","分数运算","同分母分数加减"]},{"id":"k14","courseId":"math","name":"异分母分数加减","path":["数与代数","分数运算","异分母分数加减"]},{"id":"k15","courseId":"math","name":"用字母表示数","path":["数与代数","简易方程","用字母表示数"]},{"id":"k16","courseId":"math","name":"解简易方程","path":["数与代数","简易方程","解简易方程"]},{"id":"k17","courseId":"math","name":"列方程解决问题","path":["数与代数","简易方程","列方程解决问题"]},{"id":"k18","courseId":"math","name":"平行四边形面积","path":["图形与几何","多边形面积","平行四边形面积"]},{"id":"k19","courseId":"math","name":"三角形面积","path":["图形与几何","多边形面积","三角形面积"]},{"id":"k20","courseId":"math","name":"梯形面积","path":["图形与几何","多边形面积","梯形面积"]},{"id":"k21","courseId":"math","name":"组合图形面积","path":["图形与几何","多边形面积","组合图形面积"]},{"id":"k22","courseId":"math","name":"长方体体积","path":["图形与几何","立体图形","长方体体积"]},{"id":"k23","courseId":"math","name":"正方体体积","path":["图形与几何","立体图形","正方体体积"]},{"id":"k24","courseId":"math","name":"容积与单位换算","path":["图形与几何","立体图形","容积与单位换算"]},{"id":"k25","courseId":"math","name":"平均数","path":["统计与概率","数据与可能性","平均数"]},{"id":"k26","courseId":"math","name":"折线统计图","path":["统计与概率","数据与可能性","折线统计图"]},{"id":"k27","courseId":"math","name":"可能性","path":["统计与概率","数据与可能性","可能性"]},{"id":"k28","courseId":"math","name":"植树问题","path":["数与代数","综合应用","植树问题"]},{"id":"k29","courseId":"chinese","name":"字音辨析","path":["语言积累","字词基础","字音辨析"]},{"id":"k30","courseId":"chinese","name":"字形辨析","path":["语言积累","字词基础","字形辨析"]},{"id":"k31","courseId":"chinese","name":"词语理解","path":["语言积累","字词基础","词语理解"]},{"id":"k32","courseId":"chinese","name":"成语运用","path":["语言积累","字词基础","成语运用"]},{"id":"k33","courseId":"chinese","name":"修辞手法","path":["阅读理解","句段理解","修辞手法"]},{"id":"k34","courseId":"chinese","name":"关联词运用","path":["阅读理解","句段理解","关联词运用"]},{"id":"k35","courseId":"chinese","name":"句意理解","path":["阅读理解","句段理解","句意理解"]},{"id":"k36","courseId":"chinese","name":"标点运用","path":["阅读理解","句段理解","标点运用"]},{"id":"k37","courseId":"english","name":"名词复数","path":["语言知识","词汇与句法","名词复数"]},{"id":"k38","courseId":"english","name":"人称代词","path":["语言知识","词汇与句法","人称代词"]},{"id":"k39","courseId":"english","name":"一般现在时","path":["语言知识","词汇与句法","一般现在时"]},{"id":"k40","courseId":"english","name":"现在进行时","path":["语言知识","词汇与句法","现在进行时"]},{"id":"k41","courseId":"english","name":"方位介词","path":["阅读理解","情境表达","方位介词"]},{"id":"k42","courseId":"english","name":"疑问词","path":["阅读理解","情境表达","疑问词"]},{"id":"k43","courseId":"english","name":"日常交际","path":["阅读理解","情境表达","日常交际"]},{"id":"k44","courseId":"english","name":"阅读信息提取","path":["阅读理解","情境表达","阅读信息提取"]}],"questionImages":{"fractions":{"path":"question-crops/fractions.jpg","width":709,"height":363,"alt":"分数混合运算原题切图"},"equations":{"path":"question-crops/equations.jpg","width":1477,"height":305,"alt":"解简易方程原题切图"},"common-multiples":{"path":"question-crops/common-multiples.jpg","width":2068,"height":642,"alt":"循环排列原题切图"},"cuboid-volume":{"path":"question-crops/cuboid-volume.jpg","width":937,"height":185,"alt":"长方体体积原题切图"},"fraction-lengths":{"path":"question-crops/fraction-lengths.jpg","width":756,"height":88,"alt":"异分母分数加减原题切图"},"percent-equations":{"path":"question-crops/percent-equations.jpg","width":1064,"height":105,"alt":"含百分数简易方程原题切图"},"classical-reading":{"path":"question-crops/classical-reading.jpg","width":689,"height":687,"alt":"文言文句意理解原题切图"},"decimal-sums":{"path":"question-crops/decimal-sums.png","width":589,"height":120,"alt":"小数加减口算原题切图"},"decimal-products":{"path":"question-crops/decimal-products.png","width":1386,"height":413,"alt":"小数乘法竖式原题切图"},"decimal-quotients":{"path":"question-crops/decimal-quotients.png","width":1446,"height":549,"alt":"小数除法竖式原题切图"},"decimal-mixed":{"path":"question-crops/decimal-mixed.png","width":1399,"height":252,"alt":"小数四则混合运算原题切图"},"divisibility":{"path":"question-crops/divisibility.png","width":1400,"height":339,"alt":"2和5的倍数特征原题切图"},"prime-composite":{"path":"question-crops/prime-composite.png","width":1399,"height":192,"alt":"质数与合数判断原题切图"},"greatest-common-factor":{"path":"question-crops/greatest-common-factor.png","width":1399,"height":159,"alt":"最大公因数原题切图"},"fraction-meaning":{"path":"question-crops/fraction-meaning.png","width":1400,"height":356,"alt":"分数的意义原题切图"},"fraction-property":{"path":"question-crops/fraction-property.png","width":1399,"height":464,"alt":"分数的基本性质原题切图"},"fraction-reduction":{"path":"question-crops/fraction-reduction.png","width":1399,"height":160,"alt":"约分原题切图"},"same-denominator":{"path":"question-crops/same-denominator.png","width":723,"height":412,"alt":"同分母分数加减判断原题切图"},"algebra-expression":{"path":"question-crops/algebra-expression.png","width":1399,"height":368,"alt":"用字母表示数原题切图"},"equation-word-problem":{"path":"question-crops/equation-word-problem.png","width":1375,"height":146,"alt":"列方程解决问题原题切图"},"parallelogram-area":{"path":"question-crops/parallelogram-area.png","width":1343,"height":204,"alt":"平行四边形面积原题切图"},"triangle-area":{"path":"question-crops/triangle-area.png","width":1343,"height":292,"alt":"三角形面积原题切图"},"trapezoid-area":{"path":"question-crops/trapezoid-area.png","width":1399,"height":588,"alt":"梯形面积原题切图"},"composite-area":{"path":"question-crops/composite-area.png","width":1399,"height":286,"alt":"组合图形面积原题切图"},"cube-volume":{"path":"question-crops/cube-volume.png","width":2494,"height":446,"alt":"正方体体积原题切图"},"capacity-conversion":{"path":"question-crops/capacity-conversion.png","width":2649,"height":559,"alt":"容积与单位换算原题切图"},"average":{"path":"question-crops/average.png","width":1391,"height":388,"alt":"平均数原题切图"},"line-chart":{"path":"question-crops/line-chart.png","width":725,"height":1913,"alt":"折线统计图原题切图"},"line-chart-continuation":{"path":"question-crops/line-chart-continuation.png","width":725,"height":170,"alt":"折线统计图续问原题切图"},"probability":{"path":"question-crops/probability.png","width":1400,"height":264,"alt":"可能性原题切图"},"tree-spacing":{"path":"question-crops/tree-spacing.png","width":1399,"height":233,"alt":"植树问题原题切图"},"chinese-pronunciation":{"path":"question-crops/chinese-pronunciation.png","width":837,"height":145,"alt":"字音辨析原题切图"},"chinese-proofreading":{"path":"question-crops/chinese-proofreading.png","width":756,"height":238,"alt":"字形与标点辨析原题切图"},"chinese-word-meaning":{"path":"question-crops/chinese-word-meaning.png","width":1020,"height":182,"alt":"词语理解原题切图"},"chinese-idioms":{"path":"question-crops/chinese-idioms.png","width":1399,"height":390,"alt":"成语运用原题切图"},"chinese-rhetoric":{"path":"question-crops/chinese-rhetoric.png","width":1399,"height":487,"alt":"修辞手法原题切图"},"chinese-conjunction":{"path":"question-crops/chinese-conjunction.png","width":445,"height":125,"alt":"关联词运用原题切图"},"english-plurals":{"path":"question-crops/english-plurals.png","width":535,"height":61,"alt":"名词复数原题切图"},"english-pronouns":{"path":"question-crops/english-pronouns.png","width":377,"height":29,"alt":"人称代词原题切图"},"english-simple-present":{"path":"question-crops/english-simple-present.png","width":649,"height":32,"alt":"一般现在时原题切图"},"english-continuous":{"path":"question-crops/english-continuous.png","width":1345,"height":397,"alt":"现在进行时原题切图"},"english-place":{"path":"question-crops/english-place.png","width":1388,"height":1658,"alt":"方位介词原题切图"},"english-question-words":{"path":"question-crops/english-question-words.png","width":693,"height":188,"alt":"疑问词原题切图"},"english-greetings":{"path":"question-crops/english-greetings.png","width":1028,"height":65,"alt":"日常交际原题切图"},"english-reading":{"path":"question-crops/english-reading.png","width":619,"height":695,"alt":"阅读信息提取原题切图"}},"scenarios":{"names":["孙芳","周铮","吴汉明","钱泊雯","赵立民","冯靖宇","李豫卓","李鑫宇","钱浩均","吴易奚","王江","林小满","陈悦","王小明","郑美萍","冯钰洁","何克金","张小明","李建华","赵子峰"],"chineseTitles":["原来我也可以","把平凡写成诗","我和父亲的一次谈话","谢谢你，陌生人","失败之后，我更坚定","那束光照进了我心里","班级里的一件小事","被误解的那天","一次让我改变看法的经历","秋日胜春朝"],"englishTitles":["A Healthy Lifestyle Plan","My Favorite Season","A Memorable Journey","Changes in My Hometown","A Letter to My Future Self","The Power of Kindness","My Dream School","A Day at the Bookshop","Learning from Mistakes","Protecting Our Planet"],"phases":["processing","review","generating","queued","ready","ready","downloaded","ready","ready","review","processing","queued","ready","downloaded","review","ready","ready","downloaded","ready","downloaded"],"schemaVersion":1,"compositionErrors":{"chinese":{"4":205,"7":208,"11":203,"15":509},"english":{"4":205,"7":208,"11":203,"15":509}}},"viewTemplates":{"exam":[{"name":"孙芳","avatar":"green","state":"push","when":"59分钟前","pages":"2页","subject":"数学","score":"72/120分","wrong":"4/12道","day":0},{"name":"周铮","avatar":"green","state":"mark","when":"59分钟前","pages":"2页","subject":"物理","score":"60/120分","wrong":"1/10道","day":0},{"name":"吴汉明","avatar":"grey","state":"processing","when":"59分钟前","pages":"2页","subject":"物理","score":"--","wrong":"--","day":0,"progress":58},{"name":"钱泊雯","avatar":"green","state":"mark","when":"59分钟前","pages":"3页","subject":"数学","score":"86/120分","wrong":"3/12道","day":0},{"name":"赵立民","avatar":"navy","state":"download","when":"2小时前","pages":"4页","subject":"化学","score":"92/100分","wrong":"2/15道","day":0},{"name":"冯靖宇","avatar":"purple","state":"download","when":"昨天 18:02","pages":"2页","subject":"英语","score":"108/120分","wrong":"2/10道","day":1},{"name":"李豫卓","avatar":"navy","state":"download","when":"昨天 14:35","pages":"1页","subject":"语文","score":"82/100分","wrong":"4/12道","day":1},{"name":"李鑫宇","avatar":"orange","state":"done","when":"昨天 09:12","pages":"2页","subject":"物理","score":"60/120分","wrong":"1/10道","day":1},{"name":"钱浩均","avatar":"orange","state":"done","when":"08-31 16:41","pages":"3页","subject":"生物","score":"91/100分","wrong":"2/15道","day":2},{"name":"吴易奚","avatar":"orange","state":"done","when":"08-30 10:20","pages":"2页","subject":"数学","score":"102/120分","wrong":"3/12道","day":2},{"name":"王江","avatar":"orange","state":"done","when":"08-29 09:08","pages":"2页","subject":"物理","score":"60/120分","wrong":"1/10道","day":2}],"homework":[{"name":"周泽南","avatar":"processing","state":"processing","when":"59分钟前","pages":"2页","subject":"物理","wrong":"--","day":0,"progress":58},{"name":"孙芳","avatar":"review","state":"review","when":"59分钟前","pages":"2页","subject":"物理","wrong":"1/10道","day":0},{"name":"周铮","avatar":"review","state":"review","when":"59分钟前","pages":"3页","subject":"数学","wrong":"2/12道","day":0},{"name":"冯靖宇","avatar":"done","state":"done","when":"2小时前","pages":"2页","subject":"英语","wrong":"1/10道","day":0},{"name":"钱泊雯","avatar":"review","state":"review","when":"今天 09:32","pages":"4页","subject":"语文","wrong":"3/15道","day":0},{"name":"赵立民","avatar":"done","state":"done","when":"昨天 18:02","pages":"2页","subject":"化学","wrong":"2/10道","day":1},{"name":"李豫卓","avatar":"review","state":"review","when":"昨天 14:35","pages":"1页","subject":"生物","wrong":"4/12道","day":1},{"name":"李鑫宇","avatar":"done","state":"done","when":"昨天 09:12","pages":"2页","subject":"物理","wrong":"1/10道","day":1},{"name":"钱浩均","avatar":"done","state":"done","when":"08-31 16:41","pages":"3页","subject":"生物","wrong":"2/15道","day":2},{"name":"吴易奚","avatar":"done","state":"done","when":"08-30 10:20","pages":"2页","subject":"数学","wrong":"3/12道","day":2},{"name":"王江","avatar":"done","state":"done","when":"08-29 09:08","pages":"2页","subject":"物理","wrong":"1/10道","day":2}],"chinese":[{"title":"原来我也可以","name":"钱品颜","avatar":"qian-pinyan","state":"processing","when":"59分钟前","score":"30/100分","pages":"2页","day":0,"progress":58,"progressFill":41.63},{"title":"把平凡写成诗","name":"吴彦翰","avatar":"wu-yanhan","state":"review","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"我和父亲或母亲的一次谈话","name":"王世杰","avatar":"wang-shijie","state":"review","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"谢谢你，陌生人","name":"何克金","avatar":"he-kejin","state":"done","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"失败之后，我更坚定","name":"张小明","avatar":"zhang-xiaoming","state":"done","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"那束光照进了我心里","name":"孙光洪","avatar":"sun-guanghong","state":"done","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"班级里的一件小事","name":"李素","avatar":"li-su","state":"done","when":"59分钟前","score":"30/100分","pages":"2页","day":0},{"title":"被误解的那天","name":"李世敏","avatar":"li-shimin","state":"failed","errorCode":208,"when":"59分钟前","score":"--分","pages":"--页","day":0},{"title":"那束光照进了我心里","name":"张小明","avatar":"zhang-xiaoming","state":"failed","errorCode":203,"when":"59分钟前","score":"--分","pages":"--页","day":0},{"title":"一次让我改变看法的经历","name":"李建华","avatar":"li-jianhua","state":"failed","errorCode":205,"when":"59分钟前","score":"--分","pages":"--页","day":0},{"title":"失败之后，我更坚定","name":"赵子峰","avatar":"zhao-zifeng","state":"failed","errorCode":509,"when":"59分钟前","score":"--分","pages":"--页","day":0}],"english":[{"title":"第一单元 A Healthy Lifestyle Plan","name":"八年级化学","avatar":"qian-pinyan","state":"review","when":"9月1日","score":"50/100分","pages":"1页","day":3},{"title":"书店风波","name":"William Jafferson","avatar":"wu-yanhan","state":"review","when":"8月27日","score":"50/100分","pages":"1页","day":8},{"title":"书店风波","name":"八年级地理","avatar":"wang-shijie","state":"review","when":"8月27日","score":"50/100分","pages":"1页","day":8},{"title":"书店风波","name":"八年级政治","avatar":"he-kejin","state":"review","when":"8月27日","score":"50/100分","pages":"1页","day":8},{"title":"第一单元 Changes in______","name":"八年级生物","avatar":"zhang-xiaoming","state":"review","when":"8月27日","score":"51/100分","pages":"2页","day":8},{"title":"第一单元 A Healthy Lifestyle Plan","name":"William Jafferson","avatar":"sun-guanghong","state":"done","when":"8月22日","score":"48/100分","pages":"2页","day":13},{"title":"题目自拟","name":"William Jafferson","avatar":"li-su","state":"done","when":"8月22日","score":"75/100分","pages":"2页","day":13},{"title":"题目自拟","name":"William Jafferson","avatar":"li-shimin","state":"done","when":"8月21日","score":"45/100分","pages":"2页","day":14},{"title":"书店风波","name":"王小明","avatar":"li-jianhua","state":"done","when":"8月21日","score":"0/100分","pages":"1页","day":14},{"title":"自由命题","name":"包 大 宝","avatar":"zhao-zifeng","state":"done","when":"8月18日","score":"50/100分","pages":"1页","day":17},{"title":"自由名字","name":"八年级地理","avatar":"wang-shijie","state":"done","when":"8月18日","score":"55/100分","pages":"1页","day":17}],"assessment":[{"name":"冯钰洁","grade":3,"avatar":"avatar-red.png","state":"untested"},{"name":"郑美萍","grade":3,"avatar":"avatar-purple.png","state":"untested"},{"name":"周泽南","grade":3,"avatar":"avatar-orange.png","state":"testing"},{"name":"周泽南","grade":3,"avatar":"avatar-green.png","state":"testing"},{"name":"周泽南","grade":3,"avatar":"avatar-navy.png","state":"testing"},{"name":"周泽南","grade":3,"avatar":"avatar-grey.png","state":"done"},{"name":"周泽南","grade":3,"avatar":"avatar-pink.png","state":"done"},{"name":"周泽南","grade":3,"avatar":"avatar-lime.png","state":"done"},{"name":"周泽南","grade":3,"avatar":"avatar-red.png","state":"done"},{"name":"周泽南","grade":3,"avatar":"avatar-red.png","state":"done"},{"name":"周泽南","grade":3,"avatar":"avatar-green.png","state":"done"}]},"rules":"<p><strong>统计范围</strong>所有指标均随学员、课程、时间及来源筛选联动。作业包含作业批改与错题整理，考试对应试卷分析。</p><p><strong>正确率</strong>答对题数 ÷ 作答题数。趋势按自然日合并，按题量加权。没有作答时显示“—”，不视为 0%。</p><p><strong>知识点层级</strong>总结按三级知识点统计；表格可切换层级。“标注层级”按每道题记录的实际标注层级分组。</p><p><strong>掌握状态</strong>优先判定已掌握：正确率 ≥ 80%，或最近两次任务均答对。未满足且采集超过两次时标记反复出错，其余为待观测。</p><p><strong>历史变化</strong>比较最近三次任务；最高与最低正确率相差不超过 10 个百分点记为平稳，否则判断连续上升、连续下降或波动；不足三次记为数据不足。</p>","fixtures":{"demo-mobile-001":"s1","demo-mobile-002":"s2","demo-mobile-003":"s3","demo-mobile-004":"s4","demo-mobile-005":"s5","demo-mobile-006":"s6","demo-mobile-007":"s7","demo-mobile-008":"s8","demo-mobile-009":"s9","demo-mobile-010":"s10","demo-mobile-011":"s11","demo-mobile-012":"s12","demo-mobile-013":"s13","demo-mobile-014":"s14","demo-mobile-015":"s15","demo-mobile-016":"s16","demo-mobile-017":"s17","demo-mobile-018":"s18","demo-mobile-019":"s19","demo-mobile-020":"s20","demo-mobile-021":"s21","demo-mobile-023":"s23","demo-mobile-024":"s24","demo-mobile-025":"s1","demo-mobile-026":"s2","demo-mobile-027":"s3","demo-mobile-028":"s4","demo-mobile-029":"s5","demo-mobile-030":"s6","demo-mobile-031":"s7","demo-mobile-032":"s8","demo-mobile-033":"s9","demo-mobile-034":"s10","demo-mobile-035":"s11","demo-mobile-036":"s12","demo-mobile-037":"s13","demo-mobile-038":"s14","demo-mobile-039":"s15","demo-mobile-040":"s16","demo-mobile-041":"s17","demo-mobile-042":"s18","demo-mobile-043":"s19","demo-mobile-044":"s20","demo-mobile-045":"s21","demo-mobile-046":"s22","demo-mobile-047":"s23","demo-mobile-048":"s24","demo-mobile-049":"s1","demo-mobile-050":"s2","demo-mobile-051":"s3","demo-mobile-052":"s4","demo-mobile-053":"s5","demo-mobile-054":"s6","demo-student-001":"s1","demo-student-002":"s2","demo-student-003":"s3","demo-student-004":"s5","demo-student-005":"s6","demo-student-006":"s7","demo-student-007":"s8","demo-student-008":"s9","demo-student-009":"s10","demo-student-010":"s11","demo-student-011":"s12","demo-student-012":"s13","demo-student-013":"s14","demo-student-014":"s15","demo-student-015":"s16","demo-student-016":"s17","demo-student-017":"s18","demo-student-018":"s19","demo-student-019":"s20","demo-student-020":"s21","demo-student-021":"s22","demo-student-022":"s23","demo-student-023":"s24","demo-student-024":"s1","demo-student-025":"s2","demo-student-026":"s3","demo-student-027":"s22","demo-student-028":"s6","demo-student-029":"s7","demo-student-030":"s8","demo-student-031":"s9","demo-student-032":"s10","demo-student-033":"s11","demo-student-034":"s12","demo-student-035":"s13","demo-student-036":"s14","demo-student-037":"s15","demo-student-038":"s16","demo-student-039":"s17","demo-student-040":"s18","demo-student-041":"s19","demo-student-042":"s20","demo-student-043":"s21","demo-student-044":"s22","demo-student-045":"s23","demo-student-046":"s24","demo-student-047":"s1","demo-student-048":"s2","demo-student-049":"s3","demo-student-050":"s5","demo-student-051":"s6","demo-student-052":"s7","demo-student-053":"s8","demo-student-054":"s9","demo-student-055":"s10","demo-student-056":"s11","demo-student-057":"s12","demo-student-058":"s13","demo-student-059":"s14","demo-student-060":"s15","demo-student-061":"s16","demo-student-062":"s17","demo-student-063":"s18","demo-student-064":"s19","demo-student-065":"s20","demo-student-何克金":"s18","demo-student-冯钰洁":"s17","demo-student-冯靖宇":"s7","demo-student-吴易奚":"s11","demo-student-吴汉明":"s3","demo-student-周铮":"s2","demo-student-孙芳":"s1","demo-student-张小明":"s19","demo-student-李建华":"s20","demo-student-李豫卓":"s8","demo-student-李鑫宇":"s9","demo-student-林小满":"s22","demo-student-王小明":"s15","demo-student-王江":"s12","demo-student-赵子峰":"s21","demo-student-赵立民":"s6","demo-student-郑美萍":"s16","demo-student-钱泊雯":"s5","demo-student-钱浩均":"s10","demo-student-陈悦":"s14","demo-task-student-001":"s1","demo-task-student-002":"s2","demo-task-student-003":"s3","demo-task-student-004":"s5","demo-task-student-005":"s6","demo-task-student-006":"s7","demo-task-student-007":"s8","demo-task-student-008":"s9","demo-task-student-009":"s10","demo-task-student-010":"s11","demo-task-student-011":"s12","demo-task-student-013":"s14","demo-task-student-014":"s15","demo-task-student-015":"s16","demo-task-student-016":"s17","demo-task-student-017":"s18","demo-task-student-018":"s19","demo-task-student-019":"s20","demo-task-student-020":"s21","s1":"s1","s2":"s2","s3":"s3","s4":"s4","s5":"s5","s6":"s6","s7":"s7","s8":"s8","s9":"s9","s10":"s10","s11":"s11","s12":"s12","s13":"s13","s14":"s14","s15":"s15","s16":"s16","s17":"s17","s18":"s18","s19":"s19","s20":"s20","s21":"s21","s22":"s22","s23":"s23","s24":"s24","丁一凡-2-ding yi fan":"s8","任子豪-5-ren zi hao":"s11","何嘉乐-3-he jia le":"s15","倪可欣-2-ni ke xin":"s4","冯宇航-6-feng yu hang":"s11","刘强-4-liu qiang":"s23","包晨-2-bao chen":"s3","叶子涵-2-ye zi han":"s1","吴子墨-6-wu zi mo":"s20","周杰-3-zhou jie":"s5","唐思源-5-tang si yuan":"s16","夏安然-2-xia an ran":"s21","姜浩宇-6-jiang hao yu":"s17","孔令琪-3-kong ling qi":"s20","孙一诺-2-sun yi nuo":"s15","孟浩然-3-meng hao ran":"s3","宋佳琪-6-song jia qi":"s14","崔浩然-3-cui hao ran":"s6","康欣然-5-kang xin ran":"s19","张伟-5-zhang wei":"s3","彭宇轩-6-peng yu xuan":"s8","徐浩宇-3-xu hao yu":"s23","方可欣-3-fang ke xin":"s10","曹雨欣-5-cao yu xin":"s4","朱欣然-4-zhu xin ran":"s6","李静-4-li jing":"s21","杨可欣-4-yang ke xin":"s24","林小满-2-lin xiao man":"s22","欧阳子涵-5-ou yang zi han":"s6","沈欣悦-3-shen xin yue":"s12","潘嘉怡-3-pan jia yi":"s7","牛晨曦-4-niu chen xi":"s5","王小红-3-wang xiao hong":"s18","田雨欣-3-tian yu xin":"s17","白若溪-4-bai ruo xi":"s2","石浩然-4-shi hao ran":"s13","秦若曦-2-qin ruo xi":"s10","罗子睿-6-luo zi rui":"s1","胡欣怡-4-hu xin yi":"s16","艾佳宁-3-ai jia ning":"s1","袁思琪-6-yuan si qi":"s2","谢雨桐-5-xie yu tong":"s22","赵丽华-5-zhao li hua":"s4","邓子墨-4-deng zi mo":"s7","郭雨桐-2-guo yu tong":"s13","鄂文博-5-e wen bo":"s9","金子轩-2-jin zi xuan":"s18","钱文博-4-qian wen bo":"s9","陆雪-4-lu xue":"s24","陈婷-6-chen ting":"s5","韩思远-5-han si yuan":"s14","马思琪-5-ma si qi":"s2","高子涵-4-gao zi han":"s12","魏晨曦-4-wei chen xi":"s19"}};

;
/* One contract for fictional students, learning snapshots and local task indexes. */
(function (global) {
  'use strict';
  function create(catalog, baseURL, embedded = {}) {
    const base = new URL(baseURL, location.href), cache = new Map();
    const PROFILE_KEY = 'banxue.demo.profiles.v1', TASK_KEY = 'banxue.demo.tasks.v1';
    const copy = value => JSON.parse(JSON.stringify(value));
    const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch { return fallback; } };
    const resolveId = id => catalog.aliases[id] || id;
    const aliases = id => { const canonical = resolveId(id); return [...new Set([canonical,...Object.keys(catalog.aliases).filter(key=>catalog.aliases[key]===canonical)])]; };
    const gradeNumber = value => typeof value === 'number' ? value : catalog.grades.indexOf(String(value).replace('小学','')) + 1;
    function canonicalProfile(value) {
      return {id:resolveId(value.id),name:value.name,grade:gradeNumber(typeof value.grade==='number'?value.grade:(value.gradeLabel || value.grade)),avatar:String(value.avatar || 'avatar-blue.png').split('/').pop(),
        parentPhone:value.parentPhone ?? value.parentMobile ?? value.parentContact ?? '',gender:value.gender || '未设置',coach:value.coach ?? value.assignedCoach ?? '',note:value.note || '',enrolledAt:value.enrolledAt ?? value.enrollment ?? '',
        ...(value.pinyin ? {pinyin:value.pinyin} : {}),...(value.originalName ? {originalName:value.originalName} : {})};
    }
    function profileStore() {
      const current = read(PROFILE_KEY,{schemaVersion:1,profiles:{}});
      if(current.schemaVersion!==1 || !current.profiles || typeof current.profiles!=='object' || Array.isArray(current.profiles)) throw new Error('资料版本无法识别，原数据已保留');
      const profiles={};
      const legacyMobile=read('banxue-demo-student-profiles-v1',[]);
      for(const old of Array.isArray(legacyMobile)?legacyMobile:[]) if(old?.id&&old.name) profiles[resolveId(old.id)]=canonicalProfile(old);
      for(const [id,old] of Object.entries(read('banxue.pc.student-profiles.v1',{}))) {
        const original=catalog.students.find(s=>s.id===resolveId(id));
        if(original)profiles[original.id]={...profiles[original.id],...canonicalProfile({...original,...old,id})};
      }
      return {...current,profiles:{...profiles,...current.profiles}};
    }
    function project(student, platform) {
      const label=catalog.grades[student.grade-1] || '年级未设置',avatar=embedded.avatars?.[student.avatar] || new URL('avatars/'+student.avatar,base).href;
      if(platform==='pc')return {...student,grade:label,enrollment:student.enrolledAt,avatar};
      const pinyin=student.pinyin || student.name,first=pinyin.charAt(0).toUpperCase();
      return {...student,gradeLabel:label,avatar,parentMobile:student.parentPhone,parentContact:student.parentPhone,assignedCoach:student.coach,pinyin,initials:pinyin.split(' ').map(s=>s[0]).join(''),letter:/^[A-Z]$/.test(first)?first:'新'};
    }
    function roster(platform='pc') {
      let profiles={};try{profiles=profileStore().profiles;}catch{}
      const all=new Map(catalog.students.map(s=>[s.id,{...s,...profiles[s.id]}]));
      for(const [id,value] of Object.entries(profiles))if(!all.has(id))all.set(id,value);
      return [...all.values()].map(s=>project(s,platform));
    }
    function student(id,platform='pc') { return roster(platform).find(s=>s.id===resolveId(id)); }
    function saveProfile(id,patch) {
      const store=profileStore(),original=student(id,'mini');
      const value=canonicalProfile({...original,...patch,id:resolveId(id)});
      // Callers own form validation; the shared store enforces identity and grade integrity.
      if(!value.id || !value.name || !Number.isInteger(value.grade) || value.grade<1 || value.grade>12)throw new Error('学员资料不完整');
      if(original&&value.name!==original.name)value.pinyin=value.name;
      store.profiles[value.id]={...value,updatedAt:new Date().toISOString()};
      localStorage.setItem(PROFILE_KEY,JSON.stringify(store));
      return value;
    }
    function createProfiles(records) {
      if (!Array.isArray(records) || !records.length || records.length > 500) throw new Error('每批请新增 1–500 名学员');
      const store = profileStore(), occupied = new Set(roster().map(value => value.id));
      const values = records.map(record => {
        const value = canonicalProfile(record);
        if (!value.id || occupied.has(value.id)) throw new Error('学员身份重复，请重新预览后再试');
        if (!value.name?.trim() || !Number.isInteger(value.grade) || value.grade < 1 || value.grade > 12) throw new Error('学员资料不完整');
        occupied.add(value.id);
        return {...value, updatedAt:new Date().toISOString()};
      });
      // Validate the full batch before one storage write; a failed write saves no rows.
      for (const value of values) store.profiles[value.id] = value;
      localStorage.setItem(PROFILE_KEY, JSON.stringify(store));
      return values;
    }
    async function json(file) {
      if(embedded.samples?.[file])return embedded.samples[file];
      if(!cache.has(file))cache.set(file,fetch(new URL(file,base)).then(r=>{if(!r.ok)throw new Error('演示数据读取失败，请重试');return r.json();}).catch(e=>{cache.delete(file);throw e;}));
      return cache.get(file);
    }
    function projectLearning(tasks,id) {
      return tasks.map(task=>{const key=id===task.studentId?task.id:id+'::'+task.id;return {...task,id:key,studentId:id,fixtureTaskId:task.id,fixtureStudentId:task.studentId,answers:task.answers.map(a=>({...a,id:id===task.studentId?a.id:id+'::'+a.id}))};});
    }
    async function learning(id) {
      id=resolveId(id);const person=student(id);if(!person)throw new Error('找不到这位学员');
      const fixture=catalog.learningFixtures[id],tasks=fixture?projectLearning(await json(fixture+'.json'),id):[];
      return {...catalog,students:[person],tasks,questionImages:Object.fromEntries(Object.entries(catalog.questionImages).map(([key,img])=>[key,{...img,path:embedded.images?.[key] || new URL(img.path,base).href}]))};
    }
    const kindOf = task => task.kind || task.module || (task.source==='organize'?'wrong':task.source);
    function taskRecord(task, origin) {
      const kind=kindOf(task),id=task.id,studentId=resolveId(task.studentId || task.student?.id || catalog.legacyTaskNames[task.name]);
      if(!id || !studentId || !student(studentId) || !['homework','exam','chinese','english','wrong','assessment','daily'].includes(kind))throw new Error('任务缺少稳定身份');
      const raw=task.createdAt ?? task.date,createdAt=new Date(raw).toISOString();
      const courseId=task.courseId || ({数学:'math',语文:'chinese',英语:'english'})[task.subject] || task.subject;
      return {schemaVersion:1,id,studentId,kind,courseId,title:task.title || task.name || '',createdAt,status:task.phase || task.status || (kind==='wrong'?'organized':'pending'),origin,
        settings:copy(task.settings||{}),score:task.score ?? null,wrong:task.wrong ?? null,native:{store:origin,id},...(task.answers?{answerCount:task.answers.length}:{}),...(task.attachments?{attachmentCount:task.attachments.length}:{})};
    }
    function taskStore() {
      const store=read(TASK_KEY,{schemaVersion:1,tasks:{},snapshots:{}});
      if(store.schemaVersion!==1 || !store.tasks || typeof store.tasks!=='object' || Array.isArray(store.tasks))throw new Error('任务索引版本无法识别，原数据已保留');
      return store;
    }
    function publishTasks(tasks,origin,{replace=false}={}) {
      const store=taskStore();
      if(replace)for(const [id,task] of Object.entries(store.tasks))if(task.origin===origin)delete store.tasks[id];
      for(const task of tasks){try{const value=taskRecord(task,origin);store.tasks[value.id]=value;}catch{ /* Unresolved legacy identities remain in their original store. */ }}
      if(replace)store.snapshots={...store.snapshots,[origin]:true};
      localStorage.setItem(TASK_KEY,JSON.stringify(store));
    }
    function localTaskIndex(id) { try{return Object.values(taskStore().tasks).filter(t=>t.studentId===resolveId(id));}catch{return [];} }
    function bindTask(task) {
      const supplied=task.studentId || task.student?.id,id=supplied?resolveId(supplied):catalog.legacyTaskNames[task.name];
      if(!id)return task;const person=student(id,'mini');if(!person)return task;
      return Object.assign(task,{studentId:id,name:person.name,grade:person.grade,student:{...person},...(task.avatarSrc?{avatarSrc:person.avatar}:{})});
    }
    function operationSeed(kind,index,now=Date.parse(catalog.meta.anchorDate+'T09:00:00+08:00')) {
      const moduleIndex=['exam','homework','chinese','english','assessment'].indexOf(kind),scenario=catalog.scenarios;
      const name=scenario.names[(index+moduleIndex*3)%scenario.names.length],person=student(catalog.legacyTaskNames[name],'mini');
      let phase=scenario.phases[index];if(phase==='generating'&&moduleIndex>1)phase='queued';
      if(kind==='exam'&&[0,10].includes(index))phase='push';if(kind==='exam'&&index===11)phase='processing';
      if(kind==='assessment'){if([0,9,14,15].includes(index))phase='untested';else if([1,10].includes(index))phase='testing';}
      if(scenario.compositionErrors[kind]?.[index])phase='composition-error';
      const active=['processing','queued','generating','testing','push','review'].includes(phase),createdAt=active?now-(5+index*3+moduleIndex)*60000:now-Math.max(1,index-3)*5*3600000-moduleIndex*60000;
      const subject=kind==='chinese'?'语文':kind==='english'?'英语':['数学','物理','语文','英语','化学','生物'][index%6];
      return {id:'demo-'+kind+'-'+String(index+1).padStart(2,'0'),studentId:person.id,student:person,module:kind,managed:true,name:person.name,createdAt,updatedAt:createdAt,pages:(1+index%4)+'页',grade:person.grade,
        totalScore:kind==='english'?25:100,score:(kind==='english'?16+index%10:65+index%31)+'/'+(kind==='english'?25:100)+'分',wrong:(index%5+1)+'/'+(10+index%4*2)+'道',subject,reportStatus:'',phase,progress:0,progressFill:0,attempts:0,
        ...(kind==='chinese'?{title:scenario.chineseTitles[index%scenario.chineseTitles.length]}:kind==='english'?{title:scenario.englishTitles[index%scenario.englishTitles.length]}:{}),
        history:[{at:createdAt,label:kind==='assessment'?'同步学习力测评任务':'材料上传完成'}]};
    }
    function seedOperations(id) {
      const out=[];id=resolveId(id);
      try{if(taskStore().snapshots?.['mini-task-engine'])return out;}catch{}
      ['exam','homework','chinese','english'].forEach((kind,moduleIndex)=>catalog.scenarios.names.forEach((_,index)=>{
        if(catalog.legacyTaskNames[catalog.scenarios.names[(index+moduleIndex*3)%catalog.scenarios.names.length]]===id)out.push(taskRecord(operationSeed(kind,index),'fixture-operation'));
      }));return out;
    }
    function learningHistory(data) {
      const person=student(data.students[0].id,'mini');
      return data.tasks.map(task=>{const wrong=task.answers.filter(a=>!a.correct).length,total=task.answers.reduce((n,a)=>n+a.maxScore,0),score=task.answers.reduce((n,a)=>n+a.score,0);return {id:task.id,studentId:person.id,student:person,name:person.name,grade:person.grade,avatar:'green',avatarSrc:person.avatar,module:task.source==='organize'?'wrong':task.source,fixture:true,source:task.source,courseId:task.courseId,title:task.name,createdAt:Date.parse(task.date+'T09:00:00+08:00'),updatedAt:Date.parse(task.date+'T09:00:00+08:00'),state:'done',phase:'fixture',when:task.date,pages:task.answers.length+'题',subject:data.courses.find(c=>c.id===task.courseId).name.replace('小学',''),score:score+'/'+total+'分',wrong:wrong+'/'+task.answers.length+'道',answerCount:task.answers.length,answers:task.answers};});
    }
    // Notebook annotations never rewrite scored learning history. Both views use this projection.
    function notebookEdits(id) {
      const store=read('banxue.demo.notebook.v1',{schemaVersion:1,students:{}});
      if(store.schemaVersion!==1 || !store.students || typeof store.students!=='object' || Array.isArray(store.students))throw new Error('错题本版本无法识别，原数据已保留');
      return {store,items:store.students[resolveId(id)] || {}};
    }
    function notebookAnswer(id,answer,items=notebookEdits(id).items) {
      const edit=items[answer.id] || {};
      return {...answer,...edit,knowledgeIds:edit.knowledgeIds || [answer.knowledgeId]};
    }
    function notebookAnswers(id,answers) {const {items}=notebookEdits(id);return answers.map(answer=>notebookAnswer(id,answer,items));}
    function saveNotebookAnswer(id,answerId,patch) {
      if(!student(id) || !answerId)throw new Error('错题身份不完整');
      const {store,items}=notebookEdits(id),next={...items[answerId]};
      if(Array.isArray(patch.knowledgeIds)) {
        const valid=new Set(catalog.knowledge.map(k=>k.id));
        if(patch.knowledgeIds.some(key=>!valid.has(key)))throw new Error('知识点不存在');
        next.knowledgeIds=[...new Set(patch.knowledgeIds)];
      }
      if(typeof patch.notebookRemoved==='boolean')next.notebookRemoved=patch.notebookRemoved;
      store.students[resolveId(id)]={...items,[answerId]:next};
      localStorage.setItem('banxue.demo.notebook.v1',JSON.stringify(store));
    }
    function notebook(data) {
      const person=student(data.students[0].id,'mini'),{items}=notebookEdits(data.students[0].id);
      return data.tasks.map(task=>{const pages=[],questions=task.answers.filter(a=>!a.correct).map(a=>notebookAnswer(person.id,a,items)).filter(a=>!a.notebookRemoved).map(answer=>({knowledgeIds:answer.knowledgeIds,id:answer.id,wrong:true,pieces:answer.imageRefs.map(ref=>{const image=data.questionImages[ref],page=pages.length;pages.push({id:task.id+'-p'+page,index:page,src:image.path,width:image.width,height:image.height,name:ref});return {id:answer.id+'-'+page,page,rect:[0,0,1,1]};})}));return {id:task.id,studentId:person.id,student:person,fixture:true,source:task.source,courseId:task.courseId,createdAt:task.date+'T09:00:00+08:00',grade:person.gradeLabel,subject:data.courses.find(c=>c.id===task.courseId).name.replace('小学',''),pages,questions,wrongCount:questions.length,pageCount:pages.length};});
    }
    return {schemaVersion:1,version:catalog.version,catalog,resolveId,aliases,student,roster,saveProfile,createProfiles,learning,projectLearning,taskRecord,publishTasks,localTaskIndex,bindTask,gradeNumber,operationSeed,seedOperations,learningHistory,notebook,notebookAnswer,notebookAnswers,saveNotebookAnswer};
  }
  global.BanxueDemoDataFactory={create};
})(window);

window.BanxueDemoData=window.BanxueDemoDataFactory.create(window.BanxueDemoCatalog,"../demos/student-detail/assets/student-data/",window.BanxueDemoEmbedded);

;
/* PC single select. Visual contract: exam / learning ex-field + ex-menu.
 * Keep the native select as the form value and validation source.
 * Call sync() after programmatic value / options / disabled changes.
 */
(function (global) {
  'use strict';
  const instances = new WeakMap();
  let opened = null;

  function element(tag, className) {
    const node = document.createElement(tag);
    node.className = className;
    return node;
  }

  function create({select, width} = {}) {
    if (typeof select === 'string') select = document.querySelector(select);
    if (!select || select.tagName !== 'SELECT' || select.multiple) {
      throw new TypeError('BanxueSelect requires a single native select');
    }
    if (instances.has(select)) return instances.get(select).sync();

    const id = 'bx-select-' + global.crypto.randomUUID();
    // Explicit labels on a detached form may not resolve through select.labels yet.
    const parentLabel = select.closest('label');
    const labels = Array.from(new Set([...(select.labels || []), ...(parentLabel ? [parentLabel] : [])]));
    const labelText = labels.map(label => {
      const copy = label.cloneNode(true);
      copy.querySelectorAll('select,input,textarea,button').forEach(node => node.remove());
      return copy.textContent.trim();
    }).join(' ');
    const original = {tabindex:select.getAttribute('tabindex'), ariaHidden:select.getAttribute('aria-hidden')};
    const labelTargets = labels.map(label => [label, label.getAttribute('for')]);
    const root = element('span', 'bx-select');
    if (width) root.style.setProperty('--bx-select-width', width);
    const trigger = element('button', 'bx-select-trigger');
    trigger.id = id;
    trigger.type = 'button';
    trigger.setAttribute('role', 'combobox');
    trigger.setAttribute('aria-haspopup', 'listbox');
    trigger.setAttribute('aria-controls', id + '-list');
    trigger.setAttribute('aria-expanded', 'false');
    const name = select.getAttribute('aria-label') || labelText || select.name || '请选择';
    trigger.setAttribute('aria-label', name);
    const caption = element('span', 'bx-select-caption');
    const arrow = element('span', 'bx-select-arrow');
    arrow.setAttribute('aria-hidden', 'true');
    trigger.append(caption, arrow);
    const feedback = element('span', 'bx-select-error');
    feedback.id = id + '-error';
    feedback.hidden = true;
    feedback.setAttribute('role', 'alert');
    const menu = element('ul', 'bx-select-menu');
    menu.id = id + '-list';
    menu.hidden = true;
    menu.setAttribute('role', 'listbox');
    menu.setAttribute('aria-label', name);
    if ('showPopover' in menu) menu.setAttribute('popover', 'manual');
    select.before(root);
    root.append(select, trigger, feedback);
    select.classList.add('bx-select-native');
    select.tabIndex = -1;
    select.setAttribute('aria-hidden', 'true');
    labelTargets.forEach(([label]) => { label.htmlFor = id; });
    let activeIndex = -1;
    let destroyed = false;

    function disabled(option) {
      return !option || option.disabled || option.hidden || option.parentElement?.disabled;
    }

    function renderOptions() {
      menu.replaceChildren(...Array.from(select.options, (option, index) => {
        const item = element('li', 'bx-select-option');
        item.id = id + '-option-' + index;
        item.dataset.index = index;
        item.textContent = option.label;
        item.title = option.label;
        item.hidden = option.hidden;
        item.setAttribute('role', 'option');
        item.setAttribute('aria-selected', String(index === select.selectedIndex));
        item.setAttribute('aria-disabled', String(!!disabled(option)));
        return item;
      }));
    }

    function highlight(index) {
      activeIndex = index;
      for (const item of menu.children) item.classList.toggle('is-active', Number(item.dataset.index) === index);
      const item = menu.children[index];
      if (!item) { trigger.removeAttribute('aria-activedescendant'); return; }
      trigger.setAttribute('aria-activedescendant', item.id);
      // Scroll only the menu; scrollIntoView can also move the enclosing form.
      const top = item.offsetTop, bottom = top + item.offsetHeight;
      if (top < menu.scrollTop) menu.scrollTop = top;
      else if (bottom > menu.scrollTop + menu.clientHeight) menu.scrollTop = bottom - menu.clientHeight;
    }

    function position() {
      if (opened !== api) return;
      const rect = trigger.getBoundingClientRect();
      if (!trigger.isConnected || !rect.width || !rect.height) { close(); return; }
      const gap = 6, edge = 8;
      const below = global.innerHeight - rect.bottom - gap - edge;
      const above = rect.top - gap - edge;
      const upwards = below < 180 && above > below;
      menu.style.width = Math.min(Math.max(160, rect.width), global.innerWidth - edge * 2) + 'px';
      menu.style.maxHeight = Math.max(40, Math.min(280, upwards ? above : below)) + 'px';
      // Fixed-position fallback also works in transformed PC panels / dialogs.
      menu.style.left = '0px';
      menu.style.top = '0px';
      const origin = menu.getBoundingClientRect();
      const left = Math.max(edge, Math.min(rect.left, global.innerWidth - menu.offsetWidth - edge));
      const top = upwards ? Math.max(edge, rect.top - gap - menu.offsetHeight) : rect.bottom + gap;
      menu.style.left = Math.round(left - origin.left) + 'px';
      menu.style.top = Math.round(top - origin.top) + 'px';
    }

    function close(focus = false) {
      if (opened === api) opened = null;
      if (menu.hidePopover && menu.matches(':popover-open')) menu.hidePopover();
      menu.hidden = true;
      trigger.setAttribute('aria-expanded', 'false');
      trigger.removeAttribute('aria-activedescendant');
      if (focus && trigger.isConnected) trigger.focus({preventScroll:true});
    }

    function sync() {
      if (destroyed) return api;
      caption.textContent = select.selectedOptions[0]?.label || '请选择';
      trigger.title = caption.textContent;
      trigger.disabled = select.matches(':disabled') || !select.options.length;
      trigger.setAttribute('aria-required', String(select.required));
      if (select.validity.valid) {
        feedback.hidden = true;
        trigger.removeAttribute('aria-invalid');
      }
      const description = [select.getAttribute('aria-describedby'), !feedback.hidden && feedback.id].filter(Boolean).join(' ');
      if (description) trigger.setAttribute('aria-describedby', description);
      else trigger.removeAttribute('aria-describedby');
      if (trigger.disabled) close();
      if (opened === api) { renderOptions(); position(); highlight(select.selectedIndex); }
      return api;
    }

    function open() {
      sync();
      if (trigger.disabled || destroyed) return;
      opened?.close();
      const host = select.closest('dialog') || document.body;
      host.append(menu);
      renderOptions();
      menu.hidden = false;
      if (menu.showPopover) menu.showPopover();
      opened = api;
      trigger.setAttribute('aria-expanded', 'true');
      position();
      const first = Array.from(select.options).findIndex(option => !disabled(option));
      highlight(disabled(select.options[select.selectedIndex]) ? first : select.selectedIndex);
    }

    function choose(index) {
      const option = select.options[index];
      if (disabled(option)) return;
      const changed = select.selectedIndex !== index;
      select.selectedIndex = index;
      close(true);
      sync();
      if (changed) {
        select.dispatchEvent(new Event('input', {bubbles:true}));
        select.dispatchEvent(new Event('change', {bubbles:true}));
        sync();
      }
    }

    function onKey(event) {
      const keys = ['ArrowDown','ArrowUp','Home','End','Enter',' ','Escape'];
      if (event.key === 'Tab') { close(); return; }
      if (!keys.includes(event.key)) return;
      if (event.key === 'Escape') {
        if (opened !== api) return;
        event.preventDefault(); event.stopPropagation(); close(true); return;
      }
      event.preventDefault();
      if (event.key === 'Enter' || event.key === ' ') {
        if (opened === api) choose(activeIndex); else open();
        return;
      }
      if (opened !== api) { open(); if (event.key.startsWith('Arrow')) return; }
      const indices = Array.from(select.options, (option,index) => disabled(option) ? -1 : index).filter(index => index >= 0);
      if (!indices.length) return;
      const current = indices.indexOf(activeIndex);
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? indices.length - 1 : Math.max(0,Math.min(indices.length - 1,current + (event.key === 'ArrowDown' ? 1 : -1)));
      highlight(indices[next]);
    }

    function onInvalid(event) {
      event.preventDefault();
      feedback.textContent = select.validationMessage;
      feedback.hidden = false;
      trigger.setAttribute('aria-invalid', 'true');
      sync();
      if (!select.form || select.form.querySelector(':invalid') === select) {
        // reportValidity may focus another native invalid input after this event.
        global.queueMicrotask(() => {
          if (trigger.isConnected && !select.validity.valid) trigger.focus();
        });
      }
    }

    function onClick() { if (opened === api) close(); else open(); }
    function onOption(event) {
      const item = event.target.closest('.bx-select-option');
      if (item) choose(Number(item.dataset.index));
    }
    function onBlur(event) {
      if (!root.contains(event.relatedTarget) && !menu.contains(event.relatedTarget)) close();
    }
    trigger.addEventListener('click', onClick);
    trigger.addEventListener('keydown', onKey);
    trigger.addEventListener('blur', onBlur);
    menu.addEventListener('pointerdown', event => {
      if (event.target.closest('.bx-select-option')) event.preventDefault();
    });
    menu.addEventListener('click', onOption);
    select.addEventListener('change', sync);
    select.addEventListener('invalid', onInvalid);
    const api = {
      select, root, trigger, menu, open, close, sync, position,
      destroy() {
        close(); destroyed = true;
        trigger.removeEventListener('click', onClick);
        trigger.removeEventListener('keydown', onKey);
        trigger.removeEventListener('blur', onBlur);
        select.removeEventListener('change', sync);
        select.removeEventListener('invalid', onInvalid);
        root.before(select); root.remove(); menu.remove();
        select.classList.remove('bx-select-native');
        for (const [key,value] of [['tabindex',original.tabindex],['aria-hidden',original.ariaHidden]]) {
          if (value === null) select.removeAttribute(key); else select.setAttribute(key,value);
        }
        labelTargets.forEach(([label,value]) => { if (value === null) label.removeAttribute('for'); else label.setAttribute('for',value); });
        instances.delete(select);
      },
    };
    instances.set(select, api);
    return sync();
  }

  // One listener set per mounted page, independent of the number of selects.
  document.addEventListener('pointerdown', event => {
    if (opened && !opened.root.contains(event.target) && !opened.menu.contains(event.target)) opened.close();
  });
  document.addEventListener('scroll', event => {
    if (opened && !opened.menu.contains(event.target)) opened.position();
  }, true);
  document.addEventListener('close', () => opened?.close(), true);
  document.addEventListener('reset', event => {
    global.setTimeout(() => event.target.querySelectorAll('select').forEach(select => instances.get(select)?.sync()), 0);
  });
  global.addEventListener('resize', () => opened?.position());
  global.addEventListener('popstate', () => opened?.close());
  global.BanxueSelect = {
    version:'20261019-1118', create,
    get:select => instances.get(select),
    syncAll:root => root.querySelectorAll('select').forEach(select => instances.get(select)?.sync()),
    destroyAll:root => root.querySelectorAll('select').forEach(select => instances.get(select)?.destroy()),
  };
})(window);

;
/* Form primitives shared by PC business pages. No business fields or storage. */
(function (global) {
  'use strict';
  function node(tag, className, text) {
    const el = document.createElement(tag);
    if (className) el.className = className;
    if (text !== undefined) el.textContent = text;
    return el;
  }

  function formLabel(text, {required=false, tag='span'} = {}) {
    const value = String(text);
    const label = node(tag, 'bx-form-label', value.replace(/^\s*[*＊]\s*|\s*[*＊]\s*$/g, ''));
    if (required || /^\s*[*＊]|[*＊]\s*$/.test(value)) {
      const mark = node('span', 'bx-form-required', '*');
      mark.setAttribute('aria-hidden', 'true'); label.prepend(mark);
    }
    return label;
  }
  function toggle({label, checked=false, disabled=false, onChange} = {}) {
    const root = node('label', 'bx-switch'), control = node('span', 'bx-switch-control');
    const input = node('input'), track = node('span', 'bx-switch-track');
    input.type = 'checkbox'; input.setAttribute('role', 'switch');
    input.defaultChecked = input.checked = checked; input.disabled = disabled;
    track.setAttribute('aria-hidden', 'true');
    control.append(input, track); root.append(node('span', '', label), control);
    if (typeof onChange === 'function') input.addEventListener('change', () => onChange(input.checked));
    return {root, input};
  }
  function phoneDigits(value) {
    let digits = String(value ?? '').replace(/[０-９]/g, char => String.fromCharCode(char.charCodeAt(0) - 65248)).replace(/\D/g, '');
    if (digits.length > 11 && digits.startsWith('0086')) digits = digits.slice(4);
    else if (digits.length > 11 && digits.startsWith('86')) digits = digits.slice(2);
    return digits.slice(0, 11);
  }
  function formatPhone(value) {
    const digits = phoneDigits(value);
    return [digits.slice(0, 3), digits.slice(3, 7), digits.slice(7)].filter(Boolean).join(' ');
  }
  function bindPhone(control) {
    control.inputMode = 'numeric'; control.maxLength = 13;
    control.pattern = '[0-9]{3} [0-9]{4} [0-9]{4}';
    function correct(event) {
      if (event?.isComposing) return;
      const value = control.value, caret = control.selectionStart ?? value.length;
      const leftDigits = value.slice(0, caret).replace(/[^0-9０-９]/g, '').length;
      const formatted = formatPhone(value);
      control.value = formatted;
      if (control.validity.valid) control.removeAttribute('aria-invalid');
      let position = 0, seen = 0;
      while (position < formatted.length && seen < leftDigits) { if (/\d/.test(formatted[position])) seen++; position++; }
      if (document.activeElement === control) control.setSelectionRange(position, position);
    }
    control.addEventListener('input', correct);
    control.addEventListener('compositionend', correct);
    control.addEventListener('change', correct);
    control.addEventListener('paste', event => {
      const text = event.clipboardData?.getData('text');
      if (!text) return;
      event.preventDefault();
      control.setRangeText(text, control.selectionStart ?? 0, control.selectionEnd ?? control.value.length, 'end');
      control.dispatchEvent(new Event('input', {bubbles:true}));
    });
    control.addEventListener('beforeinput', event => {
      const start = control.selectionStart, end = control.selectionEnd, value = control.value;
      if (start == null || start !== end) return;
      if (event.inputType === 'deleteContentBackward' && value[start - 1] === ' ') {
        event.preventDefault(); control.value = value.slice(0, start - 2) + value.slice(start - 1);
        control.setSelectionRange(start - 2, start - 2);
      } else if (event.inputType === 'deleteContentForward' && value[start] === ' ') {
        event.preventDefault(); control.value = value.slice(0, start) + value.slice(start + 2);
        control.setSelectionRange(start, start);
      } else return;
      control.dispatchEvent(new Event('input', {bubbles:true}));
    });
  }

  function field({label, name, id, value='', values, rows, type='text', radio=false, phone=false, prefix='', ...attributes}) {
    const root = node(radio ? 'div' : 'label', 'bx-form-field');
    root.append(formLabel(label, {required:attributes.required}));
    const control = node(values ? 'select' : rows ? 'textarea' : 'input');
    control.id = id || 'bx-field-' + global.crypto.randomUUID();
    control.name = name;
    root.htmlFor = control.id;
    if (values) {
      for (const item of values) {
        const [optionValue, text] = Array.isArray(item) ? item : [item, item];
        const option = node('option', '', text);
        option.value = optionValue;
        control.append(option);
      }
      control.setAttribute('aria-label', String(label).replace(/^\s*[*＊]\s*|\s*[*＊]\s*$/g, ''));
      root.append(control);
    } else {
      if (rows) control.rows = rows; else control.type = type;
      control.className = 'bx-input' + (rows ? ' bx-textarea' : '');
      if (prefix) {
        const affix = node('span', 'bx-input bx-input-affix'), code = node('span', 'bx-input-prefix', prefix);
        code.setAttribute('aria-hidden', 'true'); control.className = 'bx-input-control';
        affix.append(code, control); root.append(affix);
      } else root.append(control);
      control.addEventListener('invalid', () => control.setAttribute('aria-invalid', 'true'));
      control.addEventListener('input', () => {
        if (control.validity.valid) control.removeAttribute('aria-invalid');
      });
    }
    for (const key of ['required','maxLength','min','max','step','disabled','readOnly','placeholder','autocomplete']) {
      if (attributes[key] !== undefined) control[key] = attributes[key];
    }
    if (values) {
      for (const option of control.options) option.defaultSelected = option.value === String(value);
    } else control.defaultValue = phone ? formatPhone(value) : value;
    control.value = phone ? formatPhone(value) : value;
    if (phone && !values && !rows) bindPhone(control);
    if (values && radio) radioSelect(control);
    else if (values) global.BanxueSelect.create({select:control,width:'100%'});
    return {root, control};
  }

  function choice({name, value, label, checked=false}) {
    const root = node('label', 'choice-item bx-form-choice');
    const input = node('input', 'bx-visually-hidden');
    input.type = 'radio'; input.name = name; input.value = value; input.defaultChecked = checked; input.checked = checked;
    root.append(input, node('span', '', label));
    const sync = () => {
      for (const radio of root.parentElement?.querySelectorAll('input[type=radio]') || [input]) {
        radio.closest('.choice-item')?.classList.toggle('selected', radio.checked);
      }
    };
    input.addEventListener('change', sync);
    sync();
    return {root, input};
  }

  function radio({name, value, label, checked=false}) {
    const root = node('label', 'bx-radio');
    const input = node('input');
    input.type = 'radio'; input.name = name; input.value = value;
    input.defaultChecked = checked; input.checked = checked;
    const dot = node('i'); dot.setAttribute('aria-hidden', 'true');
    root.append(input, dot, node('span', '', label));
    return {root, input};
  }

  // A native select remains the single form value. Radio controls mirror its options.
  const radioSelects = new WeakMap();
  function radioSelect(select) {
    select.hidden = true;
    const group = node('div', 'bx-radio-group');
    group.setAttribute('role', 'radiogroup');
    group.setAttribute('aria-label', select.getAttribute('aria-label') || select.name);
    select.after(group);
    const sync = () => {
      const inputs=Array.from(group.querySelectorAll('input'));
      if(inputs.length===select.options.length&&inputs.every((input,i)=>input.value===select.options[i].value&&input.parentElement.textContent===select.options[i].textContent)){
        inputs.forEach((input,i)=>{input.checked=select.options[i].selected;input.disabled=select.disabled||select.options[i].disabled;});return;
      }
      group.replaceChildren(...Array.from(select.options, option => {
        const item = radio({name:select.name+'-choice',value:option.value,label:option.textContent,checked:option.selected});
        item.input.disabled = select.disabled || option.disabled;
        item.input.addEventListener('change', () => {
          select.value = item.input.value;
          select.dispatchEvent(new Event('change', {bubbles:true}));
        });
        return item.root;
      }));
    };
    radioSelects.set(select, {sync});
    select.addEventListener('change', () => {
      group.querySelectorAll('input').forEach(input => {input.checked=input.value===select.value;});
    });
    sync();
  }
  function syncRadios(root=document) {
    root.querySelectorAll('select').forEach(select => radioSelects.get(select)?.sync());
  }

  function checkbox(input) {
    const root = node('span', 'bx-form-check');
    const visual = node('span', 'cbox');
    visual.setAttribute('aria-hidden', 'true');
    visual.innerHTML = '<svg class="icon" viewBox="0 0 11 9"><path d="M1 4.5 4 7 10 1" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    input.classList.add('bx-visually-hidden');
    root.append(input, visual);
    input.addEventListener('change', () => syncCheckbox(input));
    syncCheckbox(input);
    return root;
  }

  function syncCheckbox(input) {
    input.nextElementSibling?.classList.toggle('on', input.checked);
  }

  let pasteTarget = null;
  function fileInput({accept, label, dropPaste=false, interactionRoot, dragOverlay=false, pasteLabel='文件', hint='拖拽或单击后粘贴文件', onFiles, onText, onEmptyPaste}) {
    const root = node(dropPaste ? 'div' : 'span', 'bx-file-field' + (dropPaste ? ' bx-file-drop' : ''));
    const zone = interactionRoot || root;
    const originalZoneAttributes = interactionRoot ? ['role','aria-label','aria-disabled','tabindex'].map(name => [name, zone.getAttribute(name)]) : [];
    const input = node('input');
    input.type = 'file'; input.accept = accept; input.hidden = true;
    input.setAttribute('aria-label', label);
    const trigger = node('button', dropPaste ? 'bx-file-choose' : 'btn btn-ghost', label);
    trigger.type = 'button';
    trigger.addEventListener('click', () => { disarmPaste(); input.click(); });
    root.append(input, trigger);
    let paste, overlay, dragCopy, dragDepth = 0, disabled = false, pasteHovered = false;
    function renderPaste() {
      if (!paste) return;
      const armed = pasteTarget?.root === root;
      const shortcut = /Mac|iPhone|iPad/i.test(global.navigator.platform || '') ? '⌘+V' : 'Ctrl+V';
      const copy = armed ? shortcut + ' 粘贴' : pasteHovered && !disabled ? '点击进入粘贴状态' : hint;
      if (paste.textContent !== copy) paste.textContent = copy;
      paste.setAttribute('aria-pressed', String(armed));
    }
    function onPasteEnter() { pasteHovered = true; renderPaste(); }
    function onPasteLeave() { pasteHovered = false; renderPaste(); }
    function disarmPaste() {
      if (pasteTarget?.root === root) pasteTarget = null;
      root.classList.remove('is-paste-ready');
      if (interactionRoot) zone.classList.remove('is-paste-ready');
      renderPaste();
    }
    function armPaste() {
      if (!available()) return;
      pasteTarget?.disarmPaste(); pasteTarget = {root, disarmPaste};
      root.classList.add('is-paste-ready');
      if (interactionRoot) zone.classList.add('is-paste-ready');
      renderPaste();
    }
    function available() { return !disabled && root.isConnected && !root.closest('[hidden],[inert]') && root.getClientRects().length > 0; }
    function receive(files, source) { disarmPaste(); if (available()) onFiles?.(Array.from(files), source); }
    function hasFiles(event) { return Array.from(event.dataTransfer?.types || []).includes('Files'); }
    function onPaste(event) {
      if (pasteTarget?.root !== root || !available()) return;
      const data = event.clipboardData;
      const files = Array.from(data?.files || []);
      if (!files.length) files.push(...Array.from(data?.items || []).filter(item => item.kind === 'file').map(item => item.getAsFile()).filter(Boolean));
      if (files.length) { event.preventDefault(); receive(files, '粘贴'); return; }
      const text = data?.getData('text/plain') || '';
      event.preventDefault();
      if (text.trim() && onText) { disarmPaste(); onText(text); }
      else onEmptyPaste?.();
    }
    function onOutside(event) { if (dragOverlay) clearDrag(); if (pasteTarget?.root === root && !zone.contains(event.target)) disarmPaste(); }
    function onKeydown(event) {
      if (event.key !== 'Escape') return;
      if (dragOverlay) clearDrag();
      if (pasteTarget?.root === root) disarmPaste();
    }
    function setDragOver(value) {
      root.classList.toggle('is-file-over', value);
      if (interactionRoot) zone.classList.toggle('is-file-over', value);
      const copy = value ? '松手上传' : '拖拽到此处';
      if (dragCopy && dragCopy.textContent !== copy) dragCopy.textContent = copy;
    }
    function clearDrag() { dragDepth = 0; zone.classList.remove('is-file-dragging'); setDragOver(false); }
    function onDocumentDrag(event) {
      if (!hasFiles(event) || !available()) return;
      dragDepth = event.type === 'dragenter' ? dragDepth + 1 : Math.max(1, dragDepth);
      zone.classList.add('is-file-dragging');
      const inside = zone.contains(event.target);
      setDragOver(inside);
      if (event.type === 'dragover') { event.preventDefault(); event.dataTransfer.dropEffect = inside ? 'copy' : 'none'; }
    }
    function onDocumentDragLeave(event) {
      if (!zone.classList.contains('is-file-dragging')) return;
      dragDepth = Math.max(0, dragDepth - 1);
      const leftWindow = !event.relatedTarget && (event.clientX <= 0 || event.clientY <= 0 || event.clientX >= global.innerWidth || event.clientY >= global.innerHeight);
      if (!dragDepth || leftWindow) clearDrag();
    }
    function onDocumentDrop(event) { if (hasFiles(event) && available()) event.preventDefault(); clearDrag(); }
    function onVisibilityChange() { if (document.hidden) clearDrag(); }
    function onDragEnter(event) { if (hasFiles(event) && available()) setDragOver(true); }
    function onDragOver(event) {
      if (!hasFiles(event)) return;
      event.preventDefault(); event.dataTransfer.dropEffect = available() ? 'copy' : 'none';
    }
    function onDragLeave(event) { if (!zone.contains(event.relatedTarget)) setDragOver(false); }
    function onDrop(event) {
      clearDrag();
      if (hasFiles(event)) { event.preventDefault(); receive(event.dataTransfer.files || [], '拖入'); }
    }
    function onZoneClick(event) {
      if (event.target.closest('button,input,textarea,select,a,[contenteditable]')) return;
      if (!available()) return;
      zone.focus({preventScroll:true}); armPaste();
    }
    function onZoneFocus() { armPaste(); }
    function onZoneKeydown(event) {
      if (event.target === zone && (event.key === 'Enter' || event.key === ' ')) { event.preventDefault(); armPaste(); }
    }
    function setDisabled(value) {
      disabled = Boolean(value); input.disabled = disabled; trigger.disabled = disabled;
      if (paste) paste.disabled = disabled;
      root.setAttribute('aria-disabled', String(disabled));
      if (interactionRoot) { zone.setAttribute('aria-disabled', String(disabled)); zone.tabIndex = disabled ? -1 : 0; }
      if (disabled) { disarmPaste(); clearDrag(); }
      else renderPaste();
    }
    if (onFiles) input.addEventListener('change', () => {
      const files = Array.from(input.files || []); input.value = '';
      if (files.length) receive(files, '选择');
    });
    if (dropPaste) {
      zone.setAttribute('role', 'group');
      zone.setAttribute('aria-label', '选择、拖入或粘贴' + pasteLabel);
      paste = node('button', 'bx-file-paste', hint);
      paste.type = 'button'; paste.setAttribute('aria-label', '粘贴' + pasteLabel); paste.setAttribute('aria-pressed', 'false');
      paste.addEventListener('click', armPaste);
      paste.addEventListener('pointerenter', onPasteEnter);
      paste.addEventListener('pointerleave', onPasteLeave);
      root.append(paste);
      zone.addEventListener('dragenter', onDragEnter);
      zone.addEventListener('dragover', onDragOver);
      zone.addEventListener('dragleave', onDragLeave);
      zone.addEventListener('drop', onDrop);
      if (interactionRoot) {
        zone.classList.add('bx-file-zone'); zone.tabIndex = 0;
        zone.addEventListener('click', onZoneClick);
        zone.addEventListener('focus', onZoneFocus);
        zone.addEventListener('keydown', onZoneKeydown);
      }
      if (dragOverlay) {
        zone.classList.add('bx-file-overlay-zone');
        overlay = node('div', 'bx-file-drag-overlay');
        overlay.setAttribute('role', 'status');
        overlay.setAttribute('aria-live', 'polite');
        const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        icon.setAttribute('viewBox', '0 0 32 32'); icon.setAttribute('fill', 'none'); icon.setAttribute('aria-hidden', 'true');
        const path = document.createElementNS(icon.namespaceURI, 'path');
        path.setAttribute('d', 'M16 6v20M6 16h20'); icon.append(path);
        dragCopy = node('span', '', '拖拽到此处');
        overlay.append(icon, dragCopy); zone.append(overlay);
        document.addEventListener('dragenter', onDocumentDrag);
        document.addEventListener('dragover', onDocumentDrag);
        document.addEventListener('dragleave', onDocumentDragLeave);
        document.addEventListener('drop', onDocumentDrop);
        document.addEventListener('visibilitychange', onVisibilityChange);
        global.addEventListener('dragend', clearDrag);
        global.addEventListener('blur', clearDrag);
      }
      document.addEventListener('paste', onPaste);
      document.addEventListener('pointerdown', onOutside);
      document.addEventListener('focusin', onOutside);
      document.addEventListener('keydown', onKeydown);
    }
    return {root, input, disarmPaste, setDisabled,
      destroy() {
        setDisabled(true);
        document.removeEventListener('paste', onPaste);
        document.removeEventListener('pointerdown', onOutside);
        document.removeEventListener('focusin', onOutside);
        document.removeEventListener('keydown', onKeydown);
        paste?.removeEventListener('pointerenter', onPasteEnter);
        paste?.removeEventListener('pointerleave', onPasteLeave);
        if (dragOverlay) {
          document.removeEventListener('dragenter', onDocumentDrag);
          document.removeEventListener('dragover', onDocumentDrag);
          document.removeEventListener('dragleave', onDocumentDragLeave);
          document.removeEventListener('drop', onDocumentDrop);
          document.removeEventListener('visibilitychange', onVisibilityChange);
          global.removeEventListener('dragend', clearDrag);
          global.removeEventListener('blur', clearDrag);
          overlay?.remove(); zone.classList.remove('bx-file-overlay-zone');
        }
        zone.removeEventListener('dragenter', onDragEnter);
        zone.removeEventListener('dragover', onDragOver);
        zone.removeEventListener('dragleave', onDragLeave);
        zone.removeEventListener('drop', onDrop);
        if (interactionRoot) {
          zone.removeEventListener('click', onZoneClick);
          zone.removeEventListener('focus', onZoneFocus);
          zone.removeEventListener('keydown', onZoneKeydown);
          zone.classList.remove('bx-file-zone');
          for (const [name, value] of originalZoneAttributes) {
            if (value === null) zone.removeAttribute(name); else zone.setAttribute(name, value);
          }
        }
      },
    };
  }

  function empty(message, compact=false) {
    const root = node('div', 'empty-state sm' + (compact ? ' bx-empty-inline' : ''));
    root.setAttribute('role', 'status');
    root.append(node('p', 'empty-ttl', message));
    return root;
  }

  function toast(root, {duration=1600, anchored=false, size='default'} = {}) {
    let timer;
    root.classList.add('tip');
    if (anchored) root.classList.add('bx-anchor-tip');
    if (anchored && size === 'large') root.classList.add('bx-tip-lg');
    root.setAttribute('role', 'status');
    root.setAttribute('aria-live', 'polite');
    return {
      show(message) {
        global.clearTimeout(timer);
        root.textContent = message;
        root.hidden = false;
        root.classList.add('show');
        timer = global.setTimeout(() => {root.classList.remove('show');root.hidden=true;}, duration);
      },
      destroy() { global.clearTimeout(timer);root.classList.remove('show');root.hidden=true; },
    };
  }

  document.addEventListener('reset', event => global.setTimeout(() => {
    event.target.querySelectorAll('.bx-form-choice input').forEach(input => input.closest('.choice-item').classList.toggle('selected',input.checked));
    event.target.querySelectorAll('.bx-form-check input').forEach(syncCheckbox);
    syncRadios(event.target);
    event.target.querySelectorAll('.bx-input,.bx-input-control').forEach(input => input.removeAttribute('aria-invalid'));
  }, 0));
  global.BanxueForm = {version:'20261020-1955',field,label:formLabel,toggle,phoneDigits,formatPhone,choice,radio,syncRadios,checkbox,syncCheckbox,fileInput,empty,toast};
})(window);

;
/* PC 通用表格与视图切换。样式：banxue-ui.css / 接入合同：DATA_TABLE.md */
(function(global){
  'use strict';
  function el(tag, cls, text){
    var node=document.createElement(tag); if(cls) node.className=cls;
    if(text != null) node.textContent=String(text); return node;
  }
  function rootOf(value){return typeof value==='string'?document.querySelector(value):value;}
  function append(node,value){
    if(value && value.nodeType) node.appendChild(value);
    else node.textContent=value == null?'--':String(value);
  }
  function progressValue(value){var n=Number(value);return Number.isFinite(n)?Math.min(100,Math.max(0,n)):0;}
  function processing(row){return row.status && row.status.progress != null;}
  function paintProgress(node,value,label){
    var pct=progressValue(value);node.setAttribute('aria-valuenow',Math.floor(pct));
    node.setAttribute('aria-label',label||'处理中');
    node.querySelector('.bx-table-progress-fill').style.width=pct+'%';
    node.querySelector('.bx-table-progress-text').textContent=(label||'处理中')+' '+Math.floor(pct)+'%';
  }
  function statusNode(status){
    status=status||{};
    if(status.progress != null){
      var bar=el('div','bx-table-progress');bar.setAttribute('role','progressbar');
      bar.setAttribute('aria-valuemin','0');bar.setAttribute('aria-valuemax','100');
      bar.appendChild(el('span','bx-table-progress-fill'));bar.appendChild(el('span','bx-table-progress-text'));
      paintProgress(bar,status.progress,status.label);return bar;
    }
    var badge=el('span','bx-table-status',status.label||'--');
    badge.dataset.tone=['warning','primary','neutral'].indexOf(status.tone)>=0?status.tone:'neutral';
    return badge;
  }
  function identity(name,avatar){
    var item=el('div','bx-table-identity');
    if(avatar){var img=el('img','bx-table-avatar');img.src=avatar;img.alt='';img.loading='lazy';item.appendChild(img);}
    item.appendChild(el('span','bx-table-name',name));return item;
  }
  function Table(options){
    this.options=options||{};this.root=rootOf(this.options.root);
    if(!this.root)throw new Error('BanxueDataTable: root 不存在');
    this.columns=(this.options.columns||[]).slice();this.entries=new Map();
    if(!this.columns.length)throw new Error('BanxueDataTable: columns 不能为空');
    if(this.options.showIndex!==false&&!this.columns.some(function(c){return c.type==='index';}))this.columns.unshift({type:'index',label:'序号',width:'64px',fixed:'left'});
    this.root.classList.add('bx-table-wrap','bx-list-surface');
    this.root.setAttribute('role','region');this.root.setAttribute('aria-label',(this.options.label||'数据表格')+'，可横向滚动');
    this.root.style.setProperty('--bx-table-min-width',this.options.minWidth||'920px');
    this.root.style.setProperty('--bx-table-sticky-offset',this.options.stickyOffset||'0px');
    this.root.style.setProperty('--bx-table-sticky-gap',this.options.stickyGap||'0px');
    this.table=el('table','bx-data-table');this.table.setAttribute('aria-label',this.options.label||'数据列表');
    var head=el('thead'),tr=el('tr');
    this.columns.forEach(function(c){
      var th=el('th','',c.label);th.scope='col';decorate(th,c);
      if(c.sortable===true&&c.key){
        var button=el('button','bx-table-sort'),arrows=el('span','bx-table-sort-icon');
        button.type='button';button.dataset.sortKey=c.key;
        arrows.setAttribute('aria-hidden','true');arrows.appendChild(el('i','bx-table-sort-up'));arrows.appendChild(el('i','bx-table-sort-down'));
        button.appendChild(el('span','',c.label));button.appendChild(arrows);th.replaceChildren(button);
      }
      tr.appendChild(th);
    });
    head.appendChild(tr);this.body=el('tbody');this.table.appendChild(head);this.table.appendChild(this.body);this.scroller=el('div','bx-table-scroll');this.scroller.tabIndex=0;
    this.scroller.setAttribute('aria-label','横向滚动表格');this.scroller.appendChild(this.table);this.root.replaceChildren(this.scroller);
    this.sourceHead=head;
    var self=this;
    this.click=function(event){
      var sorter=event.target.closest('button[data-sort-key]');
      if(sorter&&self.root.contains(sorter)){
        var key=sorter.dataset.sortKey,current=self.sort&&self.sort.key===key?self.sort.direction:null;
        self.setSort(current==='descending'?null:{key:key,direction:current==='ascending'?'descending':'ascending'});
        if(typeof self.options.onSortChange==='function')self.options.onSortChange(self.sort?Object.assign({},self.sort):null);
        return;
      }
      var button=event.target.closest('[data-table-action]');
      if(!button || !self.root.contains(button))return;
      var tr=button.closest('tr[data-row-key]'),entry=tr&&self.entries.get(tr.dataset.rowKey);
      if(entry && typeof self.options.onAction==='function')self.options.onAction({action:button.dataset.tableAction,row:entry.data,key:tr.dataset.rowKey,event:event});
    };
    this.root.addEventListener('click',this.click);
    this.setupLayout();this.setSort(this.options.sort||null);this.setRows(this.options.rows||[]);
  }
  // 组件维护单列排序状态；业务必须先对完整筛选结果排序，再分页传入 setRows。
  Table.prototype.setSort=function(sort){
    if(sort&&(!this.columns.some(function(c){return c.sortable===true&&c.key===sort.key;})||['ascending','descending'].indexOf(sort.direction)<0))return;
    this.sort=sort?{key:sort.key,direction:sort.direction}:null;
    var self=this;
    this.root.querySelectorAll('button[data-sort-key]').forEach(function(button){
      var active=self.sort&&self.sort.key===button.dataset.sortKey,direction=active?self.sort.direction:'none',th=button.closest('th');
      button.dataset.sortDirection=direction;
      if(active)th.setAttribute('aria-sort',direction);else th.removeAttribute('aria-sort');
      var label=button.firstElementChild.textContent,next=direction==='none'?'升序排列':direction==='ascending'?'降序排列':'取消排序';
      button.title='点击'+next;button.setAttribute('aria-label',label+'，'+(direction==='none'?'未排序':direction==='ascending'?'升序':'降序')+'；'+next);
    });
  };
  function decorate(cell,column){
    if(column.align==='right')cell.classList.add('bx-table-numeric');
    if(column.muted)cell.classList.add('bx-table-muted');
    if(column.fixed==='left'||column.fixed==='right')cell.dataset.fixed=column.fixed;
    if(column.type==='actions')cell.classList.add('bx-table-actions-cell');
    if(column.type==='status')cell.classList.add('bx-table-status-cell');
    if(column.type==='index')cell.classList.add('bx-table-index');
    if(column.width){cell.style.width=column.width;cell.style.minWidth=column.width;}
  }
  Table.prototype.actions=function(row){
    var group=el('div','bx-table-actions');
    if(processing(row)||!row.actions||!row.actions.length){group.appendChild(el('span','bx-table-placeholder','--'));return group;}
    row.actions.forEach(function(action){
      var button=el('button',action.more?'bx-table-more':'bx-table-action');button.type='button';button.dataset.tableAction=action.id;
      if(action.muted)button.classList.add('is-muted');
      button.disabled=action.disabled===true;
      button.setAttribute('aria-label',action.label);button.title=action.label;
      if(action.icon)button.appendChild(action.icon.cloneNode(true));
      else if(action.more)button.textContent='⋮';
      if(!action.more)button.appendChild(el('span','',action.label));
      group.appendChild(button);
    });return group;
  };
  Table.prototype.paintCell=function(cell,column,row){
    cell.replaceChildren();
    if(column.type==='index')cell.textContent='';
    else if(column.type==='status')cell.appendChild(statusNode(row.status));
    else if(column.type==='actions')cell.appendChild(this.actions(row));
    else append(cell,column.render?column.render(row):row[column.key]);
  };
  Table.prototype.setRows=function(rows){
    var self=this,keys=new Set();
    rows.forEach(function(row){var key=String(self.options.getKey?self.options.getKey(row):row.id);if(key==='undefined'||keys.has(key))throw new Error('BanxueDataTable: 每行必须有唯一 id');keys.add(key);});
    this.entries.clear();this.body.replaceChildren();
    rows.forEach(function(row,index){
      var key=String(self.options.getKey?self.options.getKey(row):row.id),tr=el('tr');tr.dataset.rowKey=key;tr.classList.toggle('is-processing',!!processing(row));
      self.columns.forEach(function(c){var td=el('td');decorate(td,c);self.paintCell(td,c,row);if(c.type==='index')td.textContent=String(index+1);tr.appendChild(td);});
      self.body.appendChild(tr);self.entries.set(key,{node:tr,data:row});
    });
    this.empty=el('tr','bx-table-empty');var td=el('td','',this.options.emptyText||'暂无数据');td.colSpan=this.columns.length;this.empty.appendChild(td);this.body.appendChild(this.empty);this.empty.hidden=rows.length>0;this.syncRowDividers();this.scheduleLayout();
  };
  Table.prototype.showRows=function(keys,options){
    var visible=new Set(keys.map(String)),count=0,offset=Math.max(0,Number(options&&options.offset)||0);
    this.entries.forEach(function(entry,key){
      entry.node.hidden=!visible.has(key);
      if(!entry.node.hidden){count++;entry.node.querySelectorAll('.bx-table-index').forEach(function(cell){cell.textContent=String(offset+count);});}
    });
    this.empty.hidden=count>0;this.syncRowDividers();this.scheduleLayout();
  };
  // 分页与筛选通过 hidden 保留记录节点，末行必须按当前可见记录判断。
  Table.prototype.syncRowDividers=function(){
    var last=null;
    this.entries.forEach(function(entry){
      entry.node.classList.remove('is-last-visible-row');
      if(!entry.node.hidden)last=entry.node;
    });
    if(last)last.classList.add('is-last-visible-row');
  };
  Table.prototype.updateStatus=function(key,status){
    var entry=this.entries.get(String(key));if(!entry)return;
    entry.data.status=Object.assign({},status);entry.node.classList.toggle('is-processing',!!processing(entry.data));
    var self=this;this.columns.forEach(function(c,i){if(c.type==='status'||c.type==='actions')self.paintCell(entry.node.children[i],c,entry.data);});this.scheduleLayout();
  };
  Table.prototype.setProgress=function(key,value){
    var entry=this.entries.get(String(key));if(!entry||!processing(entry.data))return;
    entry.data.status.progress=progressValue(value);
    entry.node.querySelectorAll('.bx-table-progress').forEach(function(bar){paintProgress(bar,value,entry.data.status.label);});
  };
  // 纵向吸附层位于横向滚动容器之外，避免 overflow:auto 让 sticky 失效。
  // 镜像表头仅作视觉层；原表头保留原生语义，辅助技术不会读到两套表头。
  Table.prototype.setupLayout=function(){
    var self=this;
    if(this.options.stickyHeader!==false){
      this.header=el('div','bx-table-sticky-head');this.header.setAttribute('aria-hidden','true');
      this.headerClip=el('div','bx-table-head-clip bx-glass-surface');this.headerTable=el('table','bx-data-table bx-table-header-table');
      this.headerTable.appendChild(this.sourceHead.cloneNode(true));this.headerClip.appendChild(this.headerTable);this.header.appendChild(this.headerClip);
      // 镜像不进入键盘/辅助技术导航。语义表头接收键盘焦点，镜像同步焦点外观。
      if(this.sourceHead.querySelector('button[data-sort-key]')){
        this.header.querySelectorAll('button[data-sort-key]').forEach(function(button){button.tabIndex=-1;});
        this.headerPointerDown=function(event){if(event.target.closest('button[data-sort-key]'))event.preventDefault();};
        this.header.addEventListener('mousedown',this.headerPointerDown);
        this.sortFocus=function(event){
          var button=event.target.closest('button[data-sort-key]');if(!button)return;
          self.header.querySelectorAll('button[data-sort-key]').forEach(function(mirror){mirror.classList.toggle('is-keyboard-focused',event.type==='focusin'&&mirror.dataset.sortKey===button.dataset.sortKey);});
        };
        this.sourceHead.addEventListener('focusin',this.sortFocus);this.sourceHead.addEventListener('focusout',this.sortFocus);
      }
      this.root.prepend(this.header);this.root.classList.add('has-sticky-head');
    }
    this.syncScroll=function(){if(self.headerClip)self.headerClip.scrollLeft=self.scroller.scrollLeft;};
    this.scroller.addEventListener('scroll',this.syncScroll,{passive:true});
    this.headerWheel=function(event){if(event.deltaX){self.scroller.scrollLeft+=event.deltaX;event.preventDefault();}};
    if(this.headerClip)this.headerClip.addEventListener('wheel',this.headerWheel,{passive:false});
    this.onStickyScroll=function(){
      if(self.stickyFrame)return;
      self.stickyFrame=requestAnimationFrame(function(){self.stickyFrame=0;self.syncSticky();});
    };
    document.addEventListener('scroll',this.onStickyScroll,true);
    this.resizeObserver=new ResizeObserver(function(){self.scheduleLayout();});
    this.resizeObserver.observe(this.root);this.resizeObserver.observe(this.table);
  };
  Table.prototype.scheduleLayout=function(){
    if(this.layoutFrame)return;var self=this;
    this.layoutFrame=requestAnimationFrame(function(){self.layoutFrame=0;self.syncLayout();});
  };
  Table.prototype.syncLayout=function(){
    if(!this.root.getClientRects().length)return;
    // sticky 的滚动基线包含滚动祖先 padding-top，扣除它才能按导航底边留距。
    var parent=this.root.parentElement,scrollPadding=0;
    while(parent&&parent!==document.body){
      var style=getComputedStyle(parent);
      if(/auto|scroll|hidden/.test(style.overflowY)){scrollPadding=parseFloat(style.paddingTop)||0;break;}
      parent=parent.parentElement;
    }
    this.scrollParent=parent&&parent!==document.body?parent:null;
    this.root.style.setProperty('--bx-table-scroll-padding-top',scrollPadding+'px');
    var cells=Array.from(this.sourceHead.rows[0].cells),widths=cells.map(function(c){return c.getBoundingClientRect().width;});
    if(!widths.some(function(w){return w>0;}))return;
    var mirror=this.headerTable&&Array.from(this.headerTable.rows[0].cells),left=0,right=0,self=this;
    if(mirror){
      this.headerTable.style.width=this.table.getBoundingClientRect().width+'px';
      this.headerTable.style.minWidth='0';
      mirror.forEach(function(cell,i){cell.style.width=widths[i]+'px';cell.style.minWidth=widths[i]+'px';cell.style.maxWidth=widths[i]+'px';});
    }
    function offset(i,side,value){
      cells[i].style[side]=value+'px';if(mirror)mirror[i].style[side]=value+'px';
      self.entries.forEach(function(entry){entry.node.cells[i].style[side]=value+'px';});
    }
    this.columns.forEach(function(c,i){if(c.fixed==='left'){offset(i,'left',left);left+=widths[i];}});
    for(var i=this.columns.length-1;i>=0;i--){if(this.columns[i].fixed==='right'){offset(i,'right',right);right+=widths[i];}}
    this.syncScroll();this.syncSticky();
  };
  Table.prototype.syncSticky=function(){
    if(!this.header||!this.root.getClientRects().length)return;
    var header=this.header.getBoundingClientRect(),root=this.root.getBoundingClientRect();
    var top=parseFloat(getComputedStyle(this.header).top)||0;
    if(this.scrollParent){
      top+=this.scrollParent.getBoundingClientRect().top+this.scrollParent.clientTop+(parseFloat(getComputedStyle(this.scrollParent).paddingTop)||0);
    }
    // 原位表头到达吸顶线时才切换材质；回到原位或被表格底边推出后恢复。
    var stuck=root.top<=top+.1&&header.top>=top-.5;
    this.header.classList.toggle('is-stuck',stuck);
    this.headerClip.classList.toggle('bx-glass-active',stuck);
  };
  Table.prototype.destroy=function(){
    this.root.removeEventListener('click',this.click);this.scroller.removeEventListener('scroll',this.syncScroll);
    if(this.headerPointerDown)this.header.removeEventListener('mousedown',this.headerPointerDown);
    if(this.sortFocus){this.sourceHead.removeEventListener('focusin',this.sortFocus);this.sourceHead.removeEventListener('focusout',this.sortFocus);}
    if(this.headerClip)this.headerClip.removeEventListener('wheel',this.headerWheel);
    document.removeEventListener('scroll',this.onStickyScroll,true);
    this.resizeObserver.disconnect();cancelAnimationFrame(this.layoutFrame);cancelAnimationFrame(this.stickyFrame);
    this.root.replaceChildren();this.root.classList.remove('has-sticky-head');this.entries.clear();
  };
  function viewSwitch(options){
    var root=rootOf(options.root);if(!root)throw new Error('BanxueDataTable: 视图切换 root 不存在');
    var custom=Array.isArray(options.items)&&options.items.length>0;
    var items=custom?options.items.map(function(item){return {value:String(item.value),label:String(item.label)};}):[{value:'cards',label:'卡片'},{value:'table',label:'表格'}];
    if(new Set(items.map(function(item){return item.value;})).size!==items.length)throw new Error('分段选项值必须唯一');
    var value=items.some(function(item){return item.value===String(options.value);})?String(options.value):items[0].value;
    root.classList.add('bx-view-switch');root.classList.toggle('bx-view-text',custom);root.classList.toggle('bx-view-small',options.size==='small');root.classList.toggle('bx-view-large',options.size==='large');
    root.setAttribute('role','group');root.setAttribute('aria-label',options.label||'列表展示形式');root.replaceChildren();
    var indicator=el('span','bx-view-indicator');indicator.setAttribute('aria-hidden','true');root.appendChild(indicator);
    var icons={cards:'<rect x="3" y="3" width="5" height="5" rx="1"/><rect x="12" y="3" width="5" height="5" rx="1"/><rect x="3" y="12" width="5" height="5" rx="1"/><rect x="12" y="12" width="5" height="5" rx="1"/>',table:'<rect x="2.5" y="3" width="15" height="14" rx="1.5"/><path d="M3 8h14M3 12.5h14M8 8v9"/>'};
    items.forEach(function(item){var button=el('button','bx-view-button');button.type='button';button.dataset.view=item.value;button.title=item.label+(custom?'':'视图');button.setAttribute('aria-label',button.title);if(!custom)button.innerHTML='<svg viewBox="0 0 20 20" aria-hidden="true">'+icons[item.value]+'</svg>';button.appendChild(el('span','',item.label));root.appendChild(button);});
    var frame=0,destroyed=false;
    function measure(instant){if(destroyed)return;var button=Array.from(root.querySelectorAll('button')).find(function(b){return b.dataset.view===value;});if(!button||!button.offsetWidth)return;if(instant)indicator.style.transition='none';indicator.style.width=button.offsetWidth+'px';indicator.style.height=button.offsetHeight+'px';indicator.style.transform='translateX('+(button.offsetLeft-3)+'px)';indicator.style.opacity='1';if(instant){void indicator.offsetWidth;indicator.style.transition='';}}
    function setValue(next,silent){next=String(next);if(!items.some(function(item){return item.value===next;}))return;var changed=next!==value;value=next;root.querySelectorAll('button').forEach(function(b){var selected=b.dataset.view===value;b.setAttribute('aria-pressed',String(selected));b.tabIndex=selected?0:-1;});measure(false);if(changed&&!silent&&options.onChange)options.onChange(value);}
    function click(event){var button=event.target.closest('button[data-view]');if(button&&root.contains(button))setValue(button.dataset.view);}
    function keydown(event){if(!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;var buttons=Array.from(root.querySelectorAll('button')),i=buttons.indexOf(event.target);if(i<0)return;event.preventDefault();var next=event.key==='Home'?0:event.key==='End'?buttons.length-1:(i+(event.key==='ArrowRight'?1:buttons.length-1))%buttons.length;buttons[next].focus();setValue(buttons[next].dataset.view);}
    var observer=new ResizeObserver(function(){measure(true);});observer.observe(root);
    root.addEventListener('click',click);root.addEventListener('keydown',keydown);setValue(value,true);frame=requestAnimationFrame(function(){measure(true);});if(document.fonts)document.fonts.ready.then(function(){measure(true);});
    return {get value(){return value;},setValue:setValue,destroy:function(){destroyed=true;observer.disconnect();cancelAnimationFrame(frame);root.removeEventListener('click',click);root.removeEventListener('keydown',keydown);root.replaceChildren();root.classList.remove('bx-view-switch','bx-view-text','bx-view-small','bx-view-large');}};
  }
  global.BanxueDataTable={version:'20261020-1505',create:function(options){return new Table(options);},createViewSwitch:viewSwitch,identity:identity};
})(window);

;
/* ============================================================
   banxue-pagination.js · PC 通用分页器（单一交互源）
   ------------------------------------------------------------
   维护位置：02-pc版/ui-kit/components/
   样式位置：同目录 banxue-ui.css 的「16. 分页器 Pagination」

   用法：
     var pager = BanxuePagination.create({
       root: "#pager",
       total: 50,
       pageSize: 50,
       pageSizeOptions: [20, 30, 40, 50],
       sticky: true,
       onChange: function(page){ renderPage(page); }
     });

   更新数据：pager.setTotal(23, { page: 1, silent: true });
   ============================================================ */
(function(global){
  "use strict";

  function clamp(value, min, max){
    return Math.max(min, Math.min(max, value));
  }

  function toPositiveInt(value, fallback){
    var n = parseInt(value, 10);
    return Number.isFinite(n) && n > 0 ? n : fallback;
  }

  function resolveRoot(root){
    return typeof root === "string" ? document.querySelector(root) : root;
  }

  function scrollParent(element){
    var node = element.parentElement;
    while(node && node !== document.body){
      var overflowY = getComputedStyle(node).overflowY;
      if(overflowY === "auto" || overflowY === "scroll") return node;
      node = node.parentElement;
    }
    return document.scrollingElement || document.documentElement;
  }

  function pageTokens(current, count){
    if(count <= 7){
      return Array.from({length:count}, function(_, i){ return i + 1; });
    }
    var keep = {1:true, 2:true, [count - 1]:true, [count]:true};
    for(var p=current - 1;p<=current + 1;p++){
      if(p > 0 && p <= count) keep[p] = true;
    }
    var pages = Object.keys(keep).map(Number).sort(function(a,b){ return a - b; });
    var out = [];
    pages.forEach(function(page, index){
      if(index && page - pages[index - 1] > 1) out.push("ellipsis-" + page);
      out.push(page);
    });
    return out;
  }

  function Pagination(options){
    options = options || {};
    this.root = resolveRoot(options.root);
    if(!this.root) throw new Error("BanxuePagination: 找不到 root 容器");
    this.total = Math.max(0, parseInt(options.total, 10) || 0);
    this.pageSizeOptions = (options.pageSizeOptions || [20, 30, 40, 50])
      .map(function(x){ return toPositiveInt(x, 0); })
      .filter(function(x, i, arr){ return x > 0 && arr.indexOf(x) === i; })
      .sort(function(a,b){ return a - b; });
    this.pageSize = toPositiveInt(options.pageSize, 50);
    if(this.pageSizeOptions.indexOf(this.pageSize) < 0) this.pageSizeOptions.push(this.pageSize);
    this.pageSizeOptions.sort(function(a,b){ return a - b; });
    this.sticky = options.sticky === true;
    this.contentMaxWidth = options.contentMaxWidth || "1200px";
    this.page = toPositiveInt(options.page, 1);
    this.onChange = typeof options.onChange === "function" ? options.onChange : function(){};
    this._sizeMenuOpen = false;
    this._stickyFrame = 0;
    this._sentinel = null;
    this._scrollParent = null;
    this._onClick = this._handleClick.bind(this);
    this._onKeydown = this._handleKeydown.bind(this);
    this._onInput = this._handleInput.bind(this);
    this._onFocusIn = this._handleFocusIn.bind(this);
    this._onDocumentClick = this._handleDocumentClick.bind(this);
    this._onStickyChange = this._scheduleStickySync.bind(this);
    this.root.addEventListener("click", this._onClick);
    this.root.addEventListener("keydown", this._onKeydown);
    this.root.addEventListener("input", this._onInput);
    this.root.addEventListener("focusin", this._onFocusIn);
    document.addEventListener("click", this._onDocumentClick);
    if(this.contentMaxWidth) this.root.style.setProperty("--bx-pagination-content-max-width", this.contentMaxWidth);
    if(this.sticky) this._setupSticky();
    this.render();
  }

  Pagination.prototype._setupSticky = function(){
    this._sentinel = document.createElement("span");
    this._sentinel.className = "bx-pagination-sentinel";
    this._sentinel.setAttribute("aria-hidden", "true");
    this.root.parentNode.insertBefore(this._sentinel, this.root);
    this._scrollParent = scrollParent(this.root);
    this._scrollParent.addEventListener("scroll", this._onStickyChange, {passive:true});
    window.addEventListener("resize", this._onStickyChange, {passive:true});
  };

  Pagination.prototype._scheduleStickySync = function(){
    if(!this.sticky || this._stickyFrame) return;
    var self = this;
    this._stickyFrame = requestAnimationFrame(function(){
      self._stickyFrame = 0;
      self._syncStickyState();
    });
  };

  Pagination.prototype._syncStickyState = function(){
    if(!this._sentinel || this.root.hidden || this.root.offsetParent === null){
      this.root.classList.remove("is-stuck");
      this.root.classList.remove("bx-glass-active");
      return;
    }
    var sentinelTop = this._sentinel.getBoundingClientRect().top;
    var pagerTop = this.root.getBoundingClientRect().top;
    // 哨兵仍在分页器自然位置之下，说明 sticky 正把分页器托在视口底部。
    var stuck = sentinelTop > pagerTop + 1;
    this.root.classList.toggle("is-stuck", stuck);
    this.root.classList.toggle("bx-glass-active", stuck);
  };

  Pagination.prototype.pageCount = function(){
    return Math.max(1, Math.ceil(this.total / this.pageSize));
  };

  Pagination.prototype.setPage = function(page, options){
    options = options || {};
    var next = clamp(toPositiveInt(page, 1), 1, this.pageCount());
    var changed = next !== this.page;
    this.page = next;
    this.render();
    if(changed && !options.silent) this.onChange(this.page, this);
    return this.page;
  };

  Pagination.prototype.setTotal = function(total, options){
    options = options || {};
    this.total = Math.max(0, parseInt(total, 10) || 0);
    var requestedPage = options.page == null ? this.page : options.page;
    this.page = clamp(toPositiveInt(requestedPage, 1), 1, this.pageCount());
    this.render();
    if(!options.silent) this.onChange(this.page, this);
    return this.page;
  };

  Pagination.prototype.setPageSize = function(pageSize, options){
    options = options || {};
    var next = toPositiveInt(pageSize, this.pageSize);
    var changed = next !== this.pageSize;
    this.pageSize = next;
    this.page = clamp(toPositiveInt(options.page, 1), 1, this.pageCount());
    this.render();
    if(changed && !options.silent) this.onChange(this.page, this);
    return this.pageSize;
  };

  Pagination.prototype.range = function(){
    if(this.total === 0) return { start:0, end:0 };
    var start = (this.page - 1) * this.pageSize;
    return { start:start, end:Math.min(start + this.pageSize, this.total) };
  };

  Pagination.prototype._jump = function(){
    var input = this.root.querySelector(".bx-pagination-jump-input");
    if(!input) return;
    this.setPage(input.value);
    input.value = "";
  };

  Pagination.prototype._setSizeMenu = function(open, focusSelected){
    var trigger = this.root.querySelector(".bx-pagination-size-trigger");
    var menu = this.root.querySelector(".bx-pagination-size-menu");
    if(!trigger || !menu) return;
    this._sizeMenuOpen = !!open;
    trigger.setAttribute("aria-expanded", String(this._sizeMenuOpen));
    menu.hidden = !this._sizeMenuOpen;
    this.root.classList.toggle("is-size-open", this._sizeMenuOpen);
    if(this._sizeMenuOpen && focusSelected){
      var selected = menu.querySelector('[aria-selected="true"]');
      if(selected) selected.focus();
    }
  };

  Pagination.prototype._handleClick = function(event){
    if(event.target.classList.contains("bx-pagination-jump-input")){
      event.target.select();
      return;
    }
    var sizeTrigger = event.target.closest(".bx-pagination-size-trigger");
    if(sizeTrigger && this.root.contains(sizeTrigger)){
      event.preventDefault();
      this._setSizeMenu(!this._sizeMenuOpen, false);
      return;
    }
    var sizeOption = event.target.closest(".bx-pagination-size-option[data-page-size]");
    if(sizeOption && this.root.contains(sizeOption)){
      this._setSizeMenu(false, false);
      this.setPageSize(sizeOption.dataset.pageSize, {page:1});
      return;
    }
    var target = event.target.closest("[data-page-action], [data-page]");
    if(!target || !this.root.contains(target) || target.disabled) return;
    if(target.dataset.page){
      this.setPage(target.dataset.page);
      return;
    }
    var action = target.dataset.pageAction;
    if(action === "prev") this.setPage(this.page - 1);
    if(action === "next") this.setPage(this.page + 1);
    if(action === "jump") this._jump();
  };

  Pagination.prototype._handleKeydown = function(event){
    if(event.key === "Escape" && this._sizeMenuOpen){
      event.preventDefault();
      this._setSizeMenu(false, false);
      var trigger = this.root.querySelector(".bx-pagination-size-trigger");
      if(trigger) trigger.focus();
      return;
    }
    if(event.target.classList.contains("bx-pagination-size-trigger") &&
       (event.key === "Enter" || event.key === " " || event.key === "ArrowDown")){
      event.preventDefault();
      this._setSizeMenu(true, true);
      return;
    }
    var sizeOption = event.target.closest(".bx-pagination-size-option[data-page-size]");
    if(sizeOption){
      var options = Array.from(this.root.querySelectorAll("[data-page-size]"));
      var index = options.indexOf(sizeOption);
      if(event.key === "ArrowDown" || event.key === "ArrowUp"){
        event.preventDefault();
        var step = event.key === "ArrowDown" ? 1 : -1;
        options[(index + step + options.length) % options.length].focus();
        return;
      }
      if(event.key === "Home" || event.key === "End"){
        event.preventDefault();
        options[event.key === "Home" ? 0 : options.length - 1].focus();
        return;
      }
      if(event.key === "Enter" || event.key === " "){
        event.preventDefault();
        sizeOption.click();
        return;
      }
    }
    if(event.key === "Enter" && event.target.classList.contains("bx-pagination-jump-input")){
      event.preventDefault();
      this._jump();
    }
  };

  Pagination.prototype._handleDocumentClick = function(event){
    if(this._sizeMenuOpen && !this.root.contains(event.target)) this._setSizeMenu(false, false);
  };

  Pagination.prototype._handleInput = function(event){
    if(event.target.classList.contains("bx-pagination-jump-input")){
      event.target.value = event.target.value.replace(/\D/g, "");
    }
  };

  Pagination.prototype._handleFocusIn = function(event){
    if(event.target.classList.contains("bx-pagination-jump-input")) event.target.select();
  };

  Pagination.prototype.render = function(){
    var count = this.pageCount();
    this.page = clamp(this.page, 1, count);
    var buttons = pageTokens(this.page, count).map(function(token){
      if(typeof token === "string"){
        return '<span class="bx-pagination-ellipsis" aria-hidden="true">…</span>';
      }
      var current = token === this.page;
      return '<button class="bx-pagination-page' + (current ? ' is-current' : '')
        + '" type="button" data-page="' + token + '" aria-label="第 ' + token + ' 页"'
        + (current ? ' aria-current="page"' : '') + '>' + token + '</button>';
    }, this).join("");

    var sizeOptions = this.pageSizeOptions.map(function(size){
      var selected = size === this.pageSize;
      return '<button class="bx-pagination-size-option' + (selected ? ' is-selected' : '')
        + '" type="button" role="option" data-page-size="' + size + '" aria-selected="'
        + selected + '">' + size + ' 条/页</button>';
    }, this).join("");

    this.root.classList.add("bx-pagination");
    this.root.classList.add("bx-glass-surface");
    this.root.classList.toggle("is-sticky", this.sticky);
    this.root.setAttribute("role", "navigation");
    this.root.setAttribute("aria-label", "分页");
    this.root.dataset.page = String(this.page);
    this.root.dataset.pageCount = String(count);
    this.root.dataset.total = String(this.total);
    this.root.dataset.pageSize = String(this.pageSize);
    this.root.innerHTML = ''
      + '<div class="bx-pagination-inner">'
      +   '<span class="bx-pagination-total">共 <strong>' + this.total + '</strong> 条数据</span>'
      +   '<div class="bx-pagination-size"><span class="bx-pagination-size-label">每页条数</span>'
      +     '<button class="bx-pagination-size-trigger" type="button" aria-label="每页条数"'
      +       ' aria-haspopup="listbox" aria-expanded="false"><span>' + this.pageSize + ' 条/页</span>'
      +       '<span class="bx-pagination-size-arrow" aria-hidden="true"></span></button>'
      +     '<div class="bx-pagination-size-menu" role="listbox" aria-label="每页条数" hidden>'
      +       sizeOptions + '</div>'
      +   '</div>'
      +   '<div class="bx-pagination-pages">'
      +     '<button class="bx-pagination-nav" type="button" data-page-action="prev"'
      +       (this.page <= 1 ? ' disabled' : '') + '>上一页</button>'
      +     buttons
      +     '<button class="bx-pagination-nav" type="button" data-page-action="next"'
      +       (this.page >= count ? ' disabled' : '') + '>下一页</button>'
      +   '</div>'
      +   '<label class="bx-pagination-jump">跳至'
      +     '<input class="bx-pagination-jump-input" type="text" pattern="[0-9]*" maxlength="6"'
      +       ' inputmode="numeric" aria-label="跳转页码" placeholder="页码">页'
      +     '<button class="bx-pagination-go" type="button" data-page-action="jump">确定</button>'
      +   '</label>'
      + '</div>';
    this._sizeMenuOpen = false;
    this._scheduleStickySync();
  };

  Pagination.prototype.destroy = function(){
    this.root.removeEventListener("click", this._onClick);
    this.root.removeEventListener("keydown", this._onKeydown);
    this.root.removeEventListener("input", this._onInput);
    this.root.removeEventListener("focusin", this._onFocusIn);
    document.removeEventListener("click", this._onDocumentClick);
    if(this._scrollParent) this._scrollParent.removeEventListener("scroll", this._onStickyChange);
    window.removeEventListener("resize", this._onStickyChange);
    if(this._stickyFrame) cancelAnimationFrame(this._stickyFrame);
    if(this._sentinel) this._sentinel.remove();
    this.root.innerHTML = "";
    this.root.classList.remove("bx-pagination");
    this.root.classList.remove("is-sticky");
    this.root.classList.remove("is-stuck");
    this.root.classList.remove("bx-glass-surface");
    this.root.classList.remove("bx-glass-active");
    this.root.classList.remove("is-size-open");
    this.root.style.removeProperty("--bx-pagination-content-max-width");
  };

  global.BanxuePagination = {
    create:function(options){ return new Pagination(options); }
  };
})(window);

;
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.LearningModel = api;
})(typeof globalThis === 'undefined' ? this : globalThis, function () {
  'use strict';
  const sourceNames = {homework:'作业批改', exam:'试卷分析', organize:'错题整理'};
  const rate = (correct, total) => total ? correct / total * 100 : null;
  const iso = d => d.toISOString().slice(0,10);
  function periodStart(period, anchor) {
    const d = new Date(anchor + 'T12:00:00Z');
    if (period === 'all') return '0000-01-01';
    if (period === 'week') d.setUTCDate(d.getUTCDate() - (d.getUTCDay()+6)%7);
    else if (period === '7d') d.setUTCDate(d.getUTCDate()-6);
    else {
      const day = d.getUTCDate(); d.setUTCDate(1);
      d.setUTCMonth(d.getUTCMonth() - (period === 'month' ? 1 : 6));
      const last = new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();
      d.setUTCDate(Math.min(day,last));
    }
    return iso(d);
  }
  function filterTasks(data, f) {
    const start = periodStart(f.period,data.meta.anchorDate);
    return data.tasks.filter(t => t.studentId===f.student && t.courseId===f.course && t.date>=start && t.date<=data.meta.anchorDate && (f.source==='all' || (f.source==='homework' ? t.source!=='exam' : t.source==='exam')));
  }
  function trendLabel(observations) {
    if (observations.length<3) return {label:'数据不足',tone:'neutral',symbol:'—'};
    const v = observations.slice(-3).map(x=>x.rate);
    if (Math.max(...v)-Math.min(...v)<=10) return {label:'平稳',tone:'neutral',symbol:'→'};
    if (v[0]<v[1] && v[1]<v[2]) return {label:'上升',tone:'up',symbol:'↗'};
    if (v[0]>v[1] && v[1]>v[2]) return {label:'下降',tone:'down',symbol:'↘'};
    return {label:'波动',tone:'neutral',symbol:'↝'};
  }
  // Demo-only interpretation, NOT a final product rule. See README's rule boundaries.
  function mastery(correct,total,observations) {
    const recent = observations.slice(-2);
    if (rate(correct,total)>=80 || (recent.length===2 && recent.every(x=>x.correct===x.total))) return 'mastered';
    if (observations.length>2) return 'repeat';
    return 'watching';
  }
  function groupKnowledge(data,tasks,level) {
    const byId = new Map(data.knowledge.map(k=>[k.id,k]));
    const groups = new Map();
    for (const task of tasks) for (const answer of task.answers) {
      const k = byId.get(answer.knowledgeId);
      const depth = level==='marked' ? answer.annotationLevel : Number(level);
      const path = k.path.slice(0,depth), key = `${k.courseId}:${path.join('/')}`;
      if (!groups.has(key)) groups.set(key,{id:key,name:path[path.length-1],path,depth,level,answerIds:[],total:0,correct:0,taskMap:new Map()});
      const g = groups.get(key); g.total++; g.correct+=Number(answer.correct); g.answerIds.push(answer.id);
      if (!g.taskMap.has(task.id)) g.taskMap.set(task.id,{id:task.id,date:task.date,source:task.source,total:0,correct:0});
      const o = g.taskMap.get(task.id); o.total++; o.correct+=Number(answer.correct);
    }
    return [...groups.values()].map(g=>{
      const observations = [...g.taskMap.values()].sort((a,b)=>a.date.localeCompare(b.date)||a.id.localeCompare(b.id)).map(o=>({...o,rate:rate(o.correct,o.total)}));
      const {taskMap,...plain}=g;
      return {...plain,wrong:g.total-g.correct,rate:rate(g.correct,g.total),observations,trend:trendLabel(observations),mastery:mastery(g.correct,g.total,observations)};
    }).sort((a,b)=>a.id.localeCompare(b.id,'zh-CN'));
  }
  function dailyTrend(tasks, answerIds) {
    const allow = answerIds ? new Set(answerIds) : null;
    const days=new Map();
    for (const t of tasks) {
      const answers=t.answers.filter(a=>!allow || allow.has(a.id));
      if (!answers.length) continue;
      if (!days.has(t.date)) days.set(t.date,{date:t.date,total:0,correct:0,sources:new Set(),tasks:0});
      const d=days.get(t.date); d.tasks++; d.sources.add(t.source); d.total+=answers.length; d.correct+=answers.filter(a=>a.correct).length;
    }
    return [...days.values()].sort((a,b)=>a.date.localeCompare(b.date)).map(d=>({...d,sources:[...d.sources],rate:rate(d.correct,d.total)}));
  }
  function analyze(data,f) {
    const tasks=filterTasks(data,f), base=groupKnowledge(data,tasks,'3');
    const total=tasks.reduce((n,t)=>n+t.answers.length,0), correct=tasks.reduce((n,t)=>n+t.answers.filter(a=>a.correct).length,0);
    return {tasks,summary:{tasks:tasks.length,total,correct,wrong:total-correct,rate:rate(correct,total),knowledge:base.length,
      mastered:base.filter(x=>x.mastery==='mastered').sort((a,b)=>b.rate-a.rate), repeat:base.filter(x=>x.mastery==='repeat').sort((a,b)=>a.rate-b.rate)},
      rows:f.level==='3'?base:groupKnowledge(data,tasks,f.level),trend:dailyTrend(tasks)};
  }
  function wrongAnswers(tasks,row) {
    const allow=new Set(row.answerIds);
    return tasks.flatMap(t=>t.answers.filter(a=>!a.correct && allow.has(a.id)).map(a=>({...a,taskId:t.id,taskName:t.name,date:t.date,source:t.source}))).sort((a,b)=>b.date.localeCompare(a.date)||a.id.localeCompare(b.id));
  }
  return {sourceNames,periodStart,filterTasks,groupKnowledge,dailyTrend,trendLabel,mastery,analyze,wrongAnswers};
});

;
/* Shared identity and local demo persistence for the student workspace. */
(function () {
  'use strict';
  const D=window.BanxueDemoData;
  const kinds = [{value:'homework',label:'作业',full:'作业批改'},{value:'exam',label:'试卷',full:'试卷分析'},{value:'chinese',label:'语文作文',full:'语文作文'},{value:'english',label:'英语作文',full:'英语作文'},{value:'wrong',label:'错题整理',full:'错题整理'}];
  async function load(search = location.search) {
    const params=new URLSearchParams(search),id=D.resolveId(params.get('studentId')||params.get('student')||'s1');
    const student=D.student(id);if(!student)throw new Error('找不到这位学员，请返回学员列表重新选择');
    const data=await D.learning(id);return {student,data,params};
  }
  function grades(grade) {
    if (/初|初中/.test(grade)) return ['初一','初二','初三'];
    if (/高|高中/.test(grade)) return ['高一','高二','高三'];
    return ['一年级','二年级','三年级','四年级','五年级','六年级'];
  }
  function validateProfile(value, original) {
    if (!value.name.trim() || value.name.trim().length > 20) return '姓名请填写 1–20 个字';
    if (value.parentPhone && !/^1\d{10}$/.test(value.parentPhone)) return '请填写正确的 11 位家长手机号，或留空';
    if (!grades(original.grade).includes(value.grade)) return '请选择当前学段的年级';
    if (value.note.length > 200) return '备注不能超过 200 字';
    return '';
  }
  function saveProfile(student, value) {
    const error = validateProfile(value, student); if (error) throw new Error(error);
    D.saveProfile(student.id,{...value,grade:D.gradeNumber(value.grade)});
  }
  function go(route, id, extra = {}, replace = false) {
    const suffix = '?' + new URLSearchParams({studentId:id,...extra});
    if (window.PCApp) window.PCApp.navigate('student/' + route,{suffix,replace});
    else location.href = '../student-' + (route === 'new-task' ? 'task' : route) + '/index.html' + suffix;
  }
  async function returnToDetail(id, extra={}) { if(window.PCApp)await window.PCApp.back();go('detail',id,extra,true); }
  function db() { return new Promise((resolve,reject) => { const request = indexedDB.open('banxue-pc-student-workspace',2); request.onupgradeneeded=()=>{const store=request.result.objectStoreNames.contains('tasks')?request.transaction.objectStore('tasks'):request.result.createObjectStore('tasks',{keyPath:'id'});if(!store.indexNames.contains('studentId'))store.createIndex('studentId','studentId');}; request.onsuccess=()=>resolve(request.result); request.onerror=()=>reject(request.error); }); }
  async function taskStore(mode, action) {
    const database = await db();
    return new Promise((resolve,reject) => { const tx=database.transaction('tasks',mode), request=action(tx.objectStore('tasks')); tx.oncomplete=()=>{database.close();resolve(request.result);}; tx.onerror=()=>{database.close();reject(tx.error);}; tx.onabort=()=>{database.close();reject(tx.error || new Error('保存失败'));}; });
  }
  async function settleWrongTask(task) {
    // Local HTML adapter only. A real implementation reads its server task state.
    task={...task,studentId:D.resolveId(task.studentId)};
    if (task.kind === 'wrong' && !task.phase) {
      const attachments=(task.attachments||[]).map((file,index)=>({...file,id:file.id||task.id+'-image-'+index}));
      return {...task,phase:'done',attachments,selectedIds:attachments.map(file=>file.id),wrong:task.wrong??attachments.length};
    }
    if (task.kind !== 'wrong' || !['ai_preprocess','ai_postprocess'].includes(task.phase) || !Number.isFinite(task.phaseReadyAt) || Date.now() < task.phaseReadyAt) return task;
    const next={...task,phase:task.phase==='ai_preprocess'?'marking':'done'};
    delete next.phaseReadyAt;
    await saveTask(next);return next;
  }
  async function localTasks(id) { const groups=await Promise.all(D.aliases(id).map(alias=>taskStore('readonly',store=>store.index('studentId').getAll(alias))));const tasks=await Promise.all([...new Map(groups.flat().map(t=>[t.id,{...t,studentId:D.resolveId(t.studentId)}])).values()].map(settleWrongTask));try{D.publishTasks(tasks,'pc-workspace');}catch{}return tasks; }
  async function allWrongTasks() { return Promise.all((await taskStore('readonly',store=>store.getAll())).filter(task=>task.kind==='wrong').map(settleWrongTask)); }
  async function getTask(id) { const task=await taskStore('readonly',store=>store.get(id));return task?settleWrongTask(task):null; }
  function wrongTaskStatus(task) {
    return {
      ai_preprocess:{label:'AI处理中',stage:'识别与切题',tone:'primary',action:'查看进度'},
      marking:{label:'标记错题',stage:'等待你继续标记',tone:'warning',action:'继续标记'},
      ai_postprocess:{label:'AI处理中',stage:'解析与知识点整理',tone:'primary',action:'查看进度'},
      done:{label:'已完成',stage:'错题已整理',tone:'neutral',action:'查看详情'}
    }[task.phase||task.rawStatus]||{label:'已完成',stage:'错题已整理',tone:'neutral',action:'查看详情'};
  }
  async function saveTask(task) { task.studentId=D.resolveId(task.studentId);const result=await taskStore('readwrite',store=>store.put(task));try{D.publishTasks([task],'pc-workspace');}catch{}return result; }
  function wrongAnswers(data, course = 'math') {
    const knowledge = new Map(data.knowledge.map(k=>[k.id,k]));
    return data.tasks.filter(t=>t.courseId===course).flatMap(t=>t.answers.filter(a=>!a.correct).map(a=>D.notebookAnswer(data.students[0].id,a)).filter(a=>!a.notebookRemoved).map(a=>({...a,taskId:t.id,taskName:t.name,date:t.date,source:t.source,knowledge:knowledge.get(a.knowledgeIds?.[0])}))).sort((a,b)=>b.date.localeCompare(a.date));
  }
  function localWrong(data, tasks) {
    const answers=[],urls=[];
    for(const task of tasks.filter(t=>t.kind==='wrong'&&(!t.phase||t.phase==='done')&&Array.isArray(t.attachments)))for(const [index,file] of (task.organizedQuestions||task.attachments).entries()){
      if(task.selectedIds&&!task.selectedIds.includes(file.id))continue;
      const url=URL.createObjectURL(file.blob),ref=task.id+'-'+index;urls.push(url);
      data.questionImages[ref]={path:url,alt:file.name};
      answers.push({id:ref,courseId:task.courseId,knowledgeId:'local',knowledge:{name:'未标注知识点'},taskId:task.id,taskName:task.title,source:'organize',date:task.createdAt.slice(0,10),score:null,maxScore:null,imageRefs:[ref]});
    }
    return {answers,urls};
  }
  window.StudentContext = {localWrong,returnToDetail,load,grades,validateProfile,saveProfile,go,kinds,localTasks,saveTask,wrongAnswers,allWrongTasks,getTask,wrongTaskStatus};
})();

;
(function () {
  'use strict';
  const node = (tag, cls, text) => {const el=document.createElement(tag);if(cls)el.className=cls;if(text!==undefined)el.textContent=text;return el;};
  const button = (label, action, cls='btn btn-ghost') => {const el=node('button',cls,label);el.type='button';el.addEventListener('click',action);return el;};
  function question(data, answer, index, compact=false) {
    const card=node('article','sw-question'+(compact?' is-preview':''));
    const head=node('div','sw-question-head');
    head.append(node('span','sw-question-number',String(index+1).padStart(2,'0')),node('span','',window.LearningModel.sourceNames[answer.source]),node('time','',answer.date));
    const images=node('div','sw-question-images');
    for(const ref of answer.imageRefs){const source=data.questionImages[ref];if(!source)continue;const img=node('img');img.src=source.path;img.alt=source.alt;if(source.width&&source.height){img.width=source.width;img.height=source.height;}img.loading='lazy';img.decoding='async';images.append(img);}
    const foot=node('div','sw-question-foot');foot.append(node('span','',answer.knowledge?.name||''),node('span','',answer.score==null?'未批改':`得分 ${answer.score} / ${answer.maxScore}`));
    card.append(head,images,foot);return card;
  }
  function field(form, label, name, value='', options={}) {
    const {root,control}=window.BanxueForm.field({label,name,id:'field-'+name,value,...options});
    if(options.full)root.classList.add('sw-full');
    form.append(root);return control;
  }
  const empty = (message,compact=true) => window.BanxueForm.empty(message,compact);

  function fail(target,error) {target.replaceChildren(node('p','bx-notice',error.message||String(error)));}
  window.StudentUI = {node,button,question,field,empty,fail};
})();

;
/* PC history projection only: the shared task stores remain authoritative. */
(function (root, factory) {
  'use strict';
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.StudentTaskHistory = api;
})(typeof window === 'object' ? window : globalThis, function (root) {
  'use strict';
  const KINDS = new Set(['homework', 'exam', 'chinese', 'english', 'wrong']);
  const WRITING = new Set(['chinese', 'english']);
  const PROCESSING = new Set(['processing', 'queued', 'generating']);
  const SUBJECTS = new Set(['数学', '语文', '英语', '物理', '化学', '生物', '历史', '地理', '政治', '道德与法治', '科学']);
  const ERRORS = {
    203: {label:'非作文图片', canRetry:false},
    205: {label:'识别失败', canRetry:true},
    208: {label:'渲染失败', canRetry:true},
    509: {label:'内容超出AI批改范围', canRetry:false}
  };
  const text = value => value == null ? '' : String(value).trim();
  const kindOf = task => task.kind || task.module || (task.source === 'organize' ? 'wrong' : task.source);
  function number(value) {
    if (typeof value === 'number') return Number.isFinite(value) ? value : null;
    const match = text(value).match(/^(-?\d+(?:\.\d+)?)\s*(?:分(?:制)?|道|题)?$/);
    return match ? Number(match[1]) : null;
  }
  function firstNumber(...values) {
    for (const value of values) { const parsed = number(value); if (parsed != null) return parsed; }
    return null;
  }
  function pair(value) {
    const match = text(value).match(/^(\d+(?:\.\d+)?)\s*\/\s*(\d+(?:\.\d+)?)\s*(?:分|道|题)?$/);
    return match ? match.slice(1).map(Number) : null;
  }
  function phaseOf(task) {
    return text(task.phase || (typeof task.status === 'string' ? task.status : '') || task.rawStatus || task.state);
  }
  function gradeLabel(value, data, demo) {
    return typeof value === 'number' ? text((data.grades || demo?.catalog?.grades || [])[value - 1]) : text(value);
  }
  function subjectLabel(task, grade, data) {
    const course = data.courses?.find(item => item.id === task.courseId);
    const value = text(course?.name || task.subject || ({math:'数学', chinese:'语文', english:'英语'})[task.courseId] || (SUBJECTS.has(task.courseId) ? task.courseId : ''));
    if (!value) return '--';
    const shortGrade = grade.replace(/^(小学|初中|高中)/, '');
    // A course may already contain the complete grade (e.g. 小学五年级数学).
    if (shortGrade && value.includes(shortGrade)) return value;
    const subject = value.replace(/^(?:小学|初中|高中)?(?:[一二三四五六七八九十]+年级|[初高][一二三]|\d+年级)/, '').replace(/^(小学|初中|高中)/, '');
    return grade ? grade + subject : value;
  }
  function seedInfo(task, demo, studentId, resolveId) {
    if (task.origin !== 'fixture-operation' || typeof demo?.operationSeed !== 'function') return task;
    const match = text(task.id).match(/^demo-(exam|homework|chinese|english)-(\d{2})$/);
    if (!match || match[1] !== kindOf(task)) return task;
    const index = Number(match[2]) - 1;
    if (index < 0 || index >= (demo.catalog?.scenarios?.names?.length || 0)) return task;
    const seed = demo.operationSeed(match[1], index);
    if (seed.id !== task.id || resolveId(seed.studentId) !== studentId) return task;
    return {...seed, ...task, phase:phaseOf(task) || phaseOf(seed)};
  }
  function sourceRank(task) {
    if (task.origin === 'fixture-operation') return 1;
    if (!task.isOperation && (Array.isArray(task.attachments) || task.origin === 'pc-workspace')) return 3;
    return 2;
  }
  function merge(previous, next) {
    if (!previous) return next;
    const currentPhase = phaseOf(next);
    const result = {...previous, ...next, settings:{...previous.settings, ...next.settings}};
    result.phase = currentPhase || phaseOf(previous);
    // A snapshot can advance the seed state without carrying a current percentage.
    if (currentPhase && currentPhase !== phaseOf(previous) && !Object.hasOwn(next, 'progress')) delete result.progress;
    return result;
  }
  function errorCode(task, demo) {
    const explicit = Number(task.errorCode);
    if (ERRORS[explicit]) return explicit;
    const match = text(task.id).match(/^demo-(chinese|english)-(\d{2})$/);
    return match ? Number(demo?.catalog?.scenarios?.compositionErrors?.[match[1]]?.[Number(match[2]) - 1]) || null : null;
  }
  function statusFor(task, phase, demo) {
    if (PROCESSING.has(phase)) {
      const labels = {processing:'处理中', queued:'报告排队中', generating:'报告生成中'};
      const progress = number(task.progress);
      return {label:labels[phase], tone:'primary', ...(progress == null ? {indeterminate:true} : {progress:Math.max(0, Math.min(100, progress))})};
    }
    if (phase === 'composition-error') {
      const code = errorCode(task, demo), definition = ERRORS[code];
      return {label:definition?.label || '批改异常', tone:'warning', errorCode:code, canRetry:definition?.canRetry || false};
    }
    const states = {
      ready:['待下载','primary'], downloaded:['已完成','neutral'], review:['待批改审核','warning'],
      push:['待推题审核','primary'], organized:['已整理','neutral'], completed:['已完成','neutral'],
      done:['已完成','neutral'], fixture:['已完成','neutral'], pending:['待处理','warning'],
      ai_preprocess:['AI处理中','primary'], marking:['标记错题','warning'], ai_postprocess:['AI处理中','primary'],
      'processing-failed':['处理失败','warning'], 'report-failed':['报告生成失败','warning'], expired:['报告文件已过期','warning']
    };
    const [label, tone] = states[phase] || [phase || '待处理', 'warning'];
    return {label, tone};
  }
  function scoreFor(task, phase) {
    if (phase === 'composition-error' || phase === 'processing') return '--分';
    const answers = task.answers;
    let values = pair(task.score);
    if (!values && Array.isArray(answers) && answers.length && answers.every(answer => number(answer.score) != null && number(answer.maxScore) != null)) {
      values = [answers.reduce((sum, answer) => sum + number(answer.score), 0), answers.reduce((sum, answer) => sum + number(answer.maxScore), 0)];
    }
    if (!values) {
      const score = firstNumber(task.score, task.settings?.score);
      const total = firstNumber(task.totalScore, task.maxScore, task.settings?.total);
      if (score != null && total != null) values = [score, total];
    }
    if (!values) return '--分';
    return WRITING.has(task.kind) ? values.join(' / ') : values.join('/') + '分';
  }
  function wrongFor(task) {
    const values = pair(task.wrong);
    if (values) return values.join('/') + '道';
    const answers = task.answers;
    const wrong = firstNumber(task.wrong, Array.isArray(answers) ? answers.filter(answer => answer.correct === false).length : null);
    const total = firstNumber(task.answerCount, task.questionCount, task.totalQuestions, Array.isArray(answers) ? answers.length : null);
    // Uploaded pages/materials have no guaranteed relationship to question count.
    if (wrong == null) return '--';
    return total == null ? wrong + '道' : wrong + '/' + total + '道';
  }
  function project({data, student, local = [], demoData = root.BanxueDemoData}) {
    const resolveId = value => demoData?.resolveId ? demoData.resolveId(value) : value;
    const studentId = resolveId(student.id), candidates = [];
    const belongs = task => resolveId(task.studentId || task.student?.id) === studentId;
    for (const task of data.tasks || []) {
      if (!belongs(task) || !KINDS.has(kindOf(task))) continue;
      candidates.push({rank:0, task:{...task, kind:kindOf(task), title:task.title || task.name || '', createdAt:task.createdAt || task.date, phase:kindOf(task) === 'wrong' ? 'organized' : 'completed', historySource:'learning'}});
    }
    for (const task of local) {
      if (!belongs(task) || !KINDS.has(kindOf(task))) continue;
      candidates.push({rank:sourceRank(task), task:seedInfo({...task, kind:kindOf(task)}, demoData, studentId, resolveId)});
    }
    candidates.sort((left, right) => left.rank - right.rank);
    const tasks = new Map();
    for (const {task} of candidates) if (task.id) tasks.set(task.id, merge(tasks.get(task.id), task));
    return [...tasks.values()].map(task => {
      const kind = kindOf(task), rawStatus = phaseOf(task) || (kind === 'wrong' ? 'organized' : 'pending');
      const grade = gradeLabel(task.settings?.grade ?? task.grade ?? student.gradeLabel ?? student.grade, data, demoData);
      const status = statusFor(task, rawStatus, demoData);
      if(kind==='wrong'&&rawStatus==='organized')status.label='已完成';
      if(kind==='wrong')status.stage=({ai_preprocess:'识别与切题',marking:'等待你继续标记',ai_postprocess:'解析与知识点整理',done:'错题已整理'})[rawStatus]||'错题已整理';
      const downloadable = kind !== 'wrong' && ['ready','downloaded'].includes(rawStatus);
      const actions = PROCESSING.has(rawStatus) ? [] : downloadable ? [{id:'download',label:rawStatus==='downloaded'?'再次下载':'下载报告'}] : [{id:'view', label:task.historySource === 'learning' ? '查看结果' : task.attachments?.length ? '查看材料' : '查看详情'}];
      if(kind==='wrong'&&task.attachments?.length&&task.phase)actions.splice(0,actions.length,{id:'view',label:rawStatus==='marking'?'继续标记':['ai_preprocess','ai_postprocess'].includes(rawStatus)?'查看进度':'查看详情'});
      return {...task, id:task.id, kind, title:text(task.title || task.name), name:student.name, avatar:student.avatar,
        grade:grade || '--', subject:subjectLabel(task, grade, data), topic:WRITING.has(kind) ? text(task.settings?.topic || task.title) || '--' : '--',
        score:scoreFor({...task, kind}, rawStatus), wrong:wrongFor(task), createdAt:task.createdAt ?? task.date ?? '',
        answers:Array.isArray(task.answers) ? task.answers : [], settings:{...task.settings}, rawStatus, status, actions};
    }).sort((left, right) => {
      const a = Date.parse(left.createdAt), b = Date.parse(right.createdAt);
      return Number.isFinite(a) && Number.isFinite(b) ? b - a : String(right.createdAt).localeCompare(String(left.createdAt));
    });
  }
  return {project};
});

;
/* Local PDF export of the saved crops. Images are rendered only on download;
   navigation and queue creation never decode the whole task. */
(function (global) {
  "use strict";
  const bytes = value => new TextEncoder().encode(value);
  function jpegBytes(canvas) {
    const raw = atob(canvas.toDataURL("image/jpeg", .9).split(",")[1]);
    return Uint8Array.from(raw, c => c.charCodeAt(0));
  }
  function imagePdf(images) {
    const parts = [], offsets = [0]; let length = 0;
    const append = value => { const part = typeof value === "string" ? bytes(value) : value; parts.push(part); length += part.length; };
    const object = (id, body) => { offsets[id] = length; append(`${id} 0 obj\n`); append(body); append("\nendobj\n"); };
    append("%PDF-1.4\n");
    object(1, "<< /Type /Catalog /Pages 2 0 R >>");
    object(2, `<< /Type /Pages /Count ${images.length} /Kids [${images.map((_, i) => `${3 + i * 3} 0 R`).join(" ")}] >>`);
    images.forEach((img, i) => {
      const id = 3 + i * 3;
      object(id, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595.28 841.89] /Resources << /XObject << /Im ${id + 1} 0 R >> >> /Contents ${id + 2} 0 R >>`);
      offsets[id + 1] = length; append(`${id + 1} 0 obj\n<< /Type /XObject /Subtype /Image /Width 1240 /Height 1754 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.length} >>\nstream\n`);
      append(img); append("\nendstream\nendobj\n");
      const commands = "q\n595.28 0 0 841.89 0 0 cm\n/Im Do\nQ\n";
      object(id + 2, `<< /Length ${bytes(commands).length} >>\nstream\n${commands}endstream`);
    });
    const start = length, count = 3 + images.length * 3;
    append(`xref\n0 ${count}\n0000000000 65535 f \n`);
    for (let i = 1; i < count; i++) append(`${String(offsets[i]).padStart(10, "0")} 00000 n \n`);
    append(`trailer\n<< /Size ${count} /Root 1 0 R >>\nstartxref\n${start}\n%%EOF`);
    return new Blob(parts, { type: "application/pdf" });
  }

  async function build(record, similarKeys = []) {
    const questions = record.questions.filter(question => question.wrong);
    if (!questions.length) throw new Error("没有可下载的错题");
    const loaded = new Map(), output = [], canvas = document.createElement("canvas");
    canvas.width = 1240; canvas.height = 1754;
    const ctx = canvas.getContext("2d"); let y = 0;
    const begin = () => {
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#1c1f2e"; ctx.font = 'bold 34px "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif';
      ctx.fillText(`${record.student.name} · ${record.subject}错题整理`, 64, 70, 1112);
      ctx.fillStyle = "#71778f"; ctx.font = '22px "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif';
      ctx.fillText(new Date(record.createdAt).toLocaleString("zh-CN"), 64, 110);
      y = 156;
    };
    const finish = () => {
      ctx.fillStyle = "#71778f"; ctx.font = '20px "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif';
      ctx.fillText(`${output.length + 1}`, 610, 1710);
      output.push(jpegBytes(canvas));
    };
    const text = value => {
      ctx.font = '28px "PingFang SC", "Microsoft YaHei", "Hiragino Sans GB", sans-serif'; ctx.fillStyle = "#1c1f2e";
      let line = "";
      for (const char of value) {
        if (ctx.measureText(line + char).width > 1112) { ctx.fillText(line, 64, y); y += 46; line = ""; }
        line += char;
      }
      if (line) { ctx.fillText(line, 64, y); y += 46; }
    };
    begin();
    for (const question of questions) {
      const pieces = [];
      for (const piece of question.pieces) {
        const page = record.pages[piece.page];
        if (!loaded.has(piece.page)) { const image = new Image(); image.src = page.src; await image.decode(); loaded.set(piece.page, image); }
        const [x, top, width, height] = piece.rect;
        pieces.push({ image: loaded.get(piece.page), x: x * page.width, top: top * page.height, width: width * page.width, height: height * page.height });
      }
      const maxWidth = Math.max(...pieces.map(piece => piece.width));
      const rawHeight = pieces.reduce((sum, piece) => sum + piece.height, 0);
      const scale = Math.min(1112 / maxWidth, (1450 - pieces.length * 16) / rawHeight);
      const height = rawHeight * scale + pieces.length * 16;
      if (y + height > 1640 && y > 156) { finish(); begin(); }
      for (const piece of pieces) {
        ctx.drawImage(piece.image, piece.x, piece.top, piece.width, piece.height, 64, y, piece.width * scale, piece.height * scale);
        y += piece.height * scale + 16;
      }
      y += 36;
      await new Promise(resolve => requestAnimationFrame(resolve));
    }
    const selected = new Set(similarKeys);
    for (const question of questions) {
      const items = await global.BanxueWrongQuestionContent.selectedForQuestion(record, question, selected);
      for (const item of items) {
        if (item.exportImage) {
          const image = new Image(); image.src = item.exportImage; await image.decode();
          const scale = Math.min(1112 / image.width, 1400 / image.height);
          const height = image.height * scale;
          if (y + height + 60 > 1640 && y > 156) { finish(); begin(); }
          text(`举一反三 · ${item.level}`);
          ctx.drawImage(image, 64, y, image.width * scale, height); y += height + 36;
          continue;
        }
        if (y + 280 > 1640) { finish(); begin(); }
        text(`举一反三 · ${item.level}`); text(item.stem); y += 130;
      }
    }
    finish(); canvas.width = canvas.height = 0;
    return imagePdf(output);
  }
  global.BanxueWrongQuestionExport = { build, imagePdf, jpegBytes };
})(window);

;
/* Explicit local HTML Demo artifact store. It never calls a production API. */
(function(global){
  'use strict';
  function createDemoStore(){
    function open(){return new Promise((resolve,reject)=>{const request=global.indexedDB.open('banxue-pc-download-demo',1);request.onupgradeneeded=()=>request.result.createObjectStore('files',{keyPath:'id'});request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(new Error('下载记录暂时无法保存'));});}
    async function transaction(mode,action){
      const db=await open();
      return new Promise((resolve,reject)=>{const tx=db.transaction('files',mode),request=action(tx.objectStore('files'));tx.oncomplete=()=>{db.close();resolve(request.result);};tx.onerror=tx.onabort=()=>{db.close();reject(new Error('下载记录暂时无法保存'));};});
    }
    const get=id=>transaction('readonly',store=>store.get(id));
    async function put(record){
      const old=await get(record.id),value={...old,...record};
      if(old?.createdAt)value.createdAt=old.createdAt;
      await transaction('readwrite',store=>store.put(value));global.dispatchEvent(new Event('banxue:download-change'));return value;
    }
    async function record({id='file:'+global.crypto.randomUUID(),kind,name,blob,studentName,sourceTaskId}){
      if(!blob?.size)throw new Error('文件内容为空，未保存下载记录');
      const now=new Date().toISOString();
      return put({id,kind,name:name.replace(/\.pdf$/i,''),blob,studentName,sourceTaskId,createdAt:now,downloadedAt:now});
    }
    return {get,put,record,list:()=>transaction('readonly',store=>store.getAll()),async markDownloaded(id){const file=await get(id);if(file)await put({...file,downloadedAt:new Date().toISOString()});}};
  }
  global.BanxueDownloadFiles={createDemoStore};
})(typeof window==='undefined'?globalThis:window);

;
/* Shared, explicit HTML Demo report delivery: produce PDF, persist it, then download. */
(function(global){
  'use strict';
  const labels={exam:'试卷分析报告',homework:'作业批改报告',chinese:'作文批改报告',english:'作文批改报告',wrong:'错题下载',learning:'学情报告'};
  const localDate=value=>new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Shanghai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(value));
  async function summaryPDF(task){
    await global.document.fonts?.ready;
    const canvas=global.document.createElement('canvas');canvas.width=1240;canvas.height=1754;
    const ctx=canvas.getContext('2d'),style=global.getComputedStyle(global.document.documentElement);
    const color=token=>style.getPropertyValue(token).trim();
    ctx.fillStyle=color('--surface');ctx.fillRect(0,0,1240,1754);
    const lines=[labels[task.kind],task.name,'学员：'+task.studentName,'学科：'+task.courseName,'任务时间：'+new Date(task.createdAt).toLocaleString('zh-CN',{timeZone:'Asia/Shanghai',hour12:false}),
      ...(task.source.title?['任务：'+task.source.title]:[]),...(task.source.score!=null?['得分：'+task.source.score]:[]),...(task.source.wrong!=null?['错题：'+task.source.wrong]:[]),'此文件为当前演示任务的结果摘要。'];
    let y=100;
    for(const [index,line] of lines.entries()){
      ctx.fillStyle=color(index===0?'--primary':'--t1');ctx.font=(index===0?'36':'26')+'px system-ui, sans-serif';
      let part='';for(const char of line){if(ctx.measureText(part+char).width>1100){ctx.fillText(part,70,y);y+=48;part='';}part+=char;}ctx.fillText(part,70,y);y+=index===0?88:64;
    }
    const encoder=global.BanxueWrongQuestionExport,blob=encoder.imagePdf([encoder.jpegBytes(canvas)]);canvas.width=canvas.height=0;return blob;
  }
  function createDemoService({files=global.BanxueDownloadFiles.createDemoStore(),data=global.BanxueDemoData,render=summaryPDF}={}){
    const running=new Map();
    function describe(source){
      if(!source.id)throw new Error('缺少来源任务标识，未生成文件');
      const kind=source.kind;if(!labels[kind])throw new Error('不支持此文件类型');
      const createdAt=new Date(source.createdAt||Date.now()).toISOString(),studentName=source.studentName||data?.student(source.studentId)?.name||source.name||'';
      const courseName=source.courseName||data?.catalog.courses.find(course=>course.id===source.courseId)?.name||source.subject||source.courseId||'';
      const title=source.settings?.topic||source.title||'';
      const name=[labels[kind].replace('报告',''),courseName,studentName,kind==='chinese'||kind==='english'?title:'',localDate(createdAt)].filter(Boolean).join('-');
      return {id:source.downloadId||'operation:'+source.id,sourceId:source.id,kind,name,studentName,courseName,createdAt,source:{...source,title}};
    }
    async function materialize(source){
      const task=describe(source),existing=await files.get(task.id);if(existing?.blob?.size)return existing;
      if(running.has(task.id))return running.get(task.id);
      const pending=(async()=>{const blob=await render(task);if(!blob?.size)throw new Error('未生成文件，无法登记下载记录');return files.put({...task,source:undefined,sourceCreatedAt:task.createdAt,createdAt:new Date().toISOString(),blob});})();
      running.set(task.id,pending);try{return await pending;}finally{running.delete(task.id);}
    }
    async function download(source){
      const file=await materialize(source),url=global.URL.createObjectURL(file.blob),link=global.document.createElement('a');
      link.href=url;link.download=file.name+'.pdf';global.document.body.append(link);link.click();link.remove();
      global.setTimeout(()=>global.URL.revokeObjectURL(url),1000);await files.markDownloaded(file.id);return file;
    }
    return {describe,materialize,download};
  }
  global.BanxueReportDelivery={labels,createDemoService};
})(typeof window==='undefined'?globalThis:window);

return {D:window.BanxueDemoData,C:window.StudentContext,UI:window.BanxueForm,Select:window.BanxueSelect,Pager:window.BanxuePagination,Table:window.BanxueDataTable,History:window.StudentTaskHistory,Delivery:window.BanxueReportDelivery.createDemoService(),Files:window.BanxueDownloadFiles.createDemoStore(),PDF:window.BanxueWrongQuestionExport};
}
