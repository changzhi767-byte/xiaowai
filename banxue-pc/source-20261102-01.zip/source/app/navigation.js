// Page navigation belongs to the app. The browser keeps one replaceable entry.
export function createNavigation(writeURL) {
  const entries = [];
  let cursor = -1;
  return {
    commit(key, suffix = '', pageState = null, replace = false) {
      const entry = { key, suffix, pageState };
      if (replace && cursor >= 0) entries[cursor] = entry;
      else { entries.splice(cursor + 1); entries.push(entry); cursor++; }
      writeURL(entry);
      return entry;
    },
    move(offset) {
      const next = cursor + offset;
      if (next < 0 || next >= entries.length) return null;
      cursor = next;
      writeURL(entries[cursor]);
      return entries[cursor];
    },
    get current() { return entries[cursor] || null; },
    get length() { return entries.length; },
    get canBack() { return cursor > 0; },
    get canForward() { return cursor + 1 < entries.length; },
  };
}
