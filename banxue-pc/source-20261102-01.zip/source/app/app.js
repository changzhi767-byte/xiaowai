import { createPageRuntime } from './page-runtime.js';
import { createNavigation } from './navigation.js';

const manifest = await fetch('./manifest.json', { cache: 'no-store' }).then(response => {
  if (!response.ok) throw new Error('无法读取页面清单');
  return response.json();
});
const routes = new Map(manifest.routes.map(route => [route.key, route]));
const menus = new Map(manifest.routes.filter(route => route.level === 'root').map(route => [route.menu, route.key]));
const navigation = createNavigation(entry => history.replaceState({ pcApp: true, ...entry }, '', '#/' + entry.key + entry.suffix));
const cache = new Map();
const timings = [];
let active = null;
let requestId = 0;
let noticeTimer = 0;
let ready = false;

function notice(message) {
  const node = document.getElementById('appNotice');
  node.textContent = message; node.hidden = false;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => { node.hidden = true; }, 2200);
}

function parseHash() {
  const match = location.hash.match(/^#\/([^?#]+)((?:\?[^#]*)?(?:#.*)?)$/);
  const key = match && (manifest.aliases?.[match[1]] || match[1]);
  return routes.has(key) ? { key, suffix: match[2] } : { key: 'learning', suffix: '' };
}

function commit(key, suffix = '', pageState = null, replace = false) {
  navigation.commit(key, suffix, pageState, replace);
}

async function back() {
  try {
    if (await active?.handleBack()) return;
    if (await active?.beforeLeave({direction:'back'}) === false) return;
  } catch (_) { notice('当前修改未保存，请重试后再返回'); return; }
  const entry = navigation.move(-1);
  if (entry) return navigate(entry.key, { suffix: entry.suffix, fromHistory: true, guarded:true });
  const parent = routes.get(active?.page.key)?.parent;
  if (parent) {
    const params = new URLSearchParams(active.suffix.split('#')[0]);
    const suffix = parent === 'student/detail' && params.get('studentId') ? '?studentId=' + encodeURIComponent(params.get('studentId')) : '';
    return navigate(parent, { suffix, replace: true, guarded:true });
  }
}

async function forward() {
  try { if (await active?.beforeLeave({direction:'forward'}) === false) return; }
  catch (_) { notice('当前修改未保存，请重试后再继续'); return; }
  const entry = navigation.move(1);
  if (entry) return navigate(entry.key, { suffix: entry.suffix, fromHistory: true, guarded:true });
}

function follow(url, replace = false) {
  const route = manifest.routes.find(item => url.pathname.endsWith('/' + item.source + '/index.html'));
  if (route) navigate(route.key, { suffix: url.search + url.hash, replace });
}

async function navigate(key, { suffix, replace = false, fromHistory = false, guarded = false } = {}) {
  key = manifest.aliases?.[key] || key;
  if (!routes.has(key)) return;
  const started = performance.now();
  const request = ++requestId;
  document.getElementById('appShell').setAttribute('aria-busy', 'true');
  try {
    let runtime = cache.get(key);
    let mount = null;
    if (!runtime) {
      const route = routes.get(key);
      const module = await import(route.module + '?v=' + route.sha256.slice(0, 12));
      if (request !== requestId) return;
      runtime = createPageRuntime(module.page, { commit, back, forward, follow });
      mount = module.mount;
    }
    if (request !== requestId) return;
    const nextSuffix = suffix ?? runtime.suffix;
    const pageState = fromHistory ? navigation.current?.pageState : runtime.state;
    const locationChanged = runtime.suffix !== nextSuffix;
    if (!guarded && active && (active !== runtime || locationChanged)) {
      if (await active.beforeLeave({key,suffix:nextSuffix}) === false || request !== requestId) return;
    }
    if (!fromHistory) commit(key, nextSuffix, pageState, replace);
    runtime.setLocation(nextSuffix, pageState);
    if (active !== runtime) {
      active?.deactivate();
      document.getElementById('appLoading')?.remove();
      runtime.activate();
      active = runtime;
      if (mount) {
        mount.call(runtime.env.window, runtime.env);
        cache.set(key, runtime);
      }
    }
    if (fromHistory || (!mount && (locationChanged || ['student', 'wrongbook', 'wrongbook/detail', 'wrong-organize'].includes(key) || key.startsWith('student/') || runtime.page.source === 'student-task'))) runtime.notifyHistory();
    document.title = routes.get(key).title + ' · 秒懂 AI 伴学';
    document.documentElement.dataset.route = key;
    document.documentElement.dataset.browserHistoryLength = String(history.length);
    ready = true;
    window.dispatchEvent(new Event('resize'));
    timings.push({ key, cached: !mount, durationMs: Math.round((performance.now() - started) * 100) / 100 });
    if (timings.length > 100) timings.shift();
  } catch (error) {
    console.error('PC App navigation failed:', error);
    notice('页面暂时无法打开，请刷新重试');
  } finally {
    if (request === requestId) document.getElementById('appShell').removeAttribute('aria-busy');
  }
}

// Capture at the app boundary so legacy per-page navigation never reloads the document.
document.addEventListener('click', event => {
  const menu = event.target.closest('.nav-item');
  const backButton = event.target.closest('#navBackBtn, [data-app-action="back"]');
  const action = event.target.closest('.ex-action[data-act="mark"], #exTableWrap [data-table-action="mark"]');
  const submit = event.target.closest('[data-app-action="submit-composition"]');
  const link = event.target.closest('[data-app-route]');
  const newExam = event.target.closest('.nav-actions .ex-btn-primary');
  if (menu) {
    event.preventDefault(); event.stopImmediatePropagation();
    const key = menus.get(menu.dataset.key);
    if (key) { if (active?.page.key !== key || active.suffix) navigate(key, { suffix: '' }); }
    else notice('该功能暂不可用');
  } else if (backButton && event.isTrusted) {
    event.preventDefault(); event.stopImmediatePropagation();
    if (['learning', 'student/learning'].includes(active?.page.key) && active.suffix.includes('#knowledge=')) active.env.history.back();
    else back();
  } else if (action) {
    event.preventDefault(); event.stopImmediatePropagation();
    navigate('exam/review');
  } else if (link || (newExam && active?.page.key === 'exam')) {
    event.preventDefault(); event.stopImmediatePropagation();
    navigate(link?.dataset.appRoute || 'exam/select-student', { suffix: '' });
  } else if (submit) {
    event.preventDefault(); event.stopImmediatePropagation();
    active?.env.window.handleSubmit?.();
  }
}, true);

function openAddress() {
  const route = parseHash();
  if (route.key !== active?.page.key || route.suffix !== active?.suffix) navigate(route.key, { suffix: route.suffix, replace: true });
}
window.addEventListener('popstate', openAddress);
window.addEventListener('hashchange', openAddress);

window.PCApp = Object.freeze({
  navigate, back, forward,
  get ready() { return ready; },
  get currentRoute() { return active?.page.key || null; },
  diagnostics: () => ({ version: manifest.version, navigation: { length: navigation.length, canBack: navigation.canBack, canForward: navigation.canForward }, routes: [...cache].map(([key, page]) => ({ key, ...page.diagnostics() })), timings: [...timings] }),
});
const initial = parseHash();
await navigate(initial.key, { suffix: initial.suffix, replace: true });
