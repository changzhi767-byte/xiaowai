/* Lifecycle adapter for the existing classic-script pages.
 * This is source compatibility, not a security sandbox. Modules are trusted
 * local build outputs. Detached pages retain their DOM and closure state.
 */
export function createPageRuntime(page, router) {
  const nativeWindow = window;
  const nativeDocument = document;
  const shell = document.getElementById('appShell');
  const main = document.querySelector('.main-panel');
  const nav = document.querySelector('.nav-actions');
  const template = document.createElement('template');
  template.innerHTML = page.html;
  const content = template.content.firstElementChild;
  const actions = document.createElement('div');
  actions.innerHTML = page.actions;
  const portals = document.createElement('div');
  portals.className = 'pc-route-portals';
  portals.innerHTML = page.overlays;
  const stylesheet = document.createElement('style');
  stylesheet.dataset.routeStyle = page.key;
  stylesheet.textContent = page.css;
  const versionNode = document.createElement('script');
  versionNode.type = 'application/json';
  versionNode.textContent = page.versionHistory;
  const listeners = [];
  const timers = new Map();
  const observers = [];
  const globals = Object.create(null);
  const borrowed = new WeakMap();
  const bodyClasses = new Set();
  const bodyStyles = Object.create(null);
  let active = false;
  let timerId = 0;
  let scrollPositions = [];
  let savedFocus = null;
  let savedShell = null;
  const sourcePath = page.source ? '../demos/' + page.source + '/index.html' : './index.html';
  let virtualURL = new URL(sourcePath, location.href);
  let pageState = null;

  function trackListener(target, type, callback, options) {
    if (!callback || options?.signal?.aborted) return;
    const capture = typeof options === 'boolean' ? options : !!options?.capture;
    if (listeners.some(item => item.target === target && item.type === type && item.callback === callback && item.capture === capture)) return;
    const item = { target, type, callback, options, capture, removed: false };
    item.handler = event => {
      if (!active || item.removed) return;
      if (options?.once) item.removed = true;
      if (typeof callback === 'function') callback.call(target, event);
      else callback.handleEvent(event);
    };
    listeners.push(item);
    if (options?.signal) {
      item.onAbort = () => {
        item.removed = true;
        target.removeEventListener(type, item.handler, capture);
        const index = listeners.indexOf(item);
        if (index !== -1) listeners.splice(index, 1);
      };
      options.signal.addEventListener('abort', item.onAbort, {once:true});
    }
    if (active) target.addEventListener(type, item.handler, options);
  }

  function untrackListener(target, type, callback, options) {
    const capture = typeof options === 'boolean' ? options : !!options?.capture;
    const item = listeners.find(entry => !entry.removed && entry.target === target && entry.type === type && entry.callback === callback && entry.capture === capture);
    if (item) {
      item.removed = true;
      target.removeEventListener(type, item.handler, capture);
      item.options?.signal?.removeEventListener('abort', item.onAbort);
      listeners.splice(listeners.indexOf(item), 1);
    }
  }

  function manageElement(element) {
    if (!element || borrowed.has(element)) return borrowed.get(element) || element;
    const proxy = new Proxy(element, {
      get(target, key) {
        if (key === 'addEventListener') return (type, callback, options) => trackListener(target, type, callback, options);
        if (key === 'removeEventListener') return (type, callback, options) => untrackListener(target, type, callback, options);
        const value = Reflect.get(target, key, target);
        return typeof value === 'function' ? value.bind(target) : value;
      },
      set(target, key, value) { return Reflect.set(target, key, value, target); },
    });
    borrowed.set(element, proxy);
    return proxy;
  }

  function queryAll(selector) {
    const matches = [];
    for (const root of [content, active ? nav : actions, portals]) {
      if (root.matches(selector)) matches.push(root);
      matches.push(...root.querySelectorAll(selector));
    }
    if (!matches.length) {
      // Only the active shell is shared; other page trees are never searched.
      const shared = [shell, ...shell.querySelectorAll('.sidebar, .sidebar *, .nav-bar, .nav-left, #navTitle, #navBackBtn, #navExpandBtn, #readoutState, #readoutWidth')];
      matches.push(...shared.filter(node => node.matches(selector)).map(manageElement));
    }
    return [...new Set(matches)];
  }

  const bodyProxy = new Proxy(nativeDocument.body, {
    get(target, key) {
      if (key === 'appendChild') return node => portals.appendChild(node);
      if (key === 'append') return (...nodes) => portals.append(...nodes);
      if (key === 'classList') return {
        add: (...names) => names.forEach(name => { bodyClasses.add(name); if (active) target.classList.add(name); }),
        remove: (...names) => names.forEach(name => { bodyClasses.delete(name); if (active) target.classList.remove(name); }),
        contains: name => bodyClasses.has(name),
      };
      if (key === 'style') return new Proxy(target.style, {
        get(style, name) { return bodyStyles[name] ?? Reflect.get(style, name, style); },
        set(style, name, value) { bodyStyles[name] = value; if (active) style[name] = value; return true; },
      });
      const value = Reflect.get(target, key, target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });

  const documentProxy = new Proxy(nativeDocument, {
    get(target, key) {
      if (key === 'body') return bodyProxy;
      if (key === 'querySelector') return selector => queryAll(selector)[0] || null;
      if (key === 'querySelectorAll') return queryAll;
      if (key === 'getElementById') return id => id === 'versionHistory' ? versionNode : queryAll('#' + CSS.escape(id))[0] || null;
      if (key === 'addEventListener') return (type, callback, options) => trackListener(target, type, callback, options);
      if (key === 'removeEventListener') return (type, callback, options) => untrackListener(target, type, callback, options);
      const value = Reflect.get(target, key, target);
      return typeof value === 'function' ? value.bind(target) : value;
    },
  });

  function schedule(timer) {
    if (!active) return;
    timer.started = performance.now();
    const fire = timestamp => {
      if (!active || !timers.has(timer.id)) return;
      if (timer.kind !== 'interval') timers.delete(timer.id);
      if (timer.kind === 'interval') { timer.remaining = timer.delay; schedule(timer); }
      timer.callback(...(timer.kind === 'frame' ? [timestamp] : timer.args));
    };
    timer.handle = timer.kind === 'frame'
      ? nativeWindow.requestAnimationFrame(fire)
      : nativeWindow.setTimeout(fire, timer.remaining);
  }

  function addTimer(kind, callback, delay = 0, ...args) {
    if (typeof callback !== 'function') throw new TypeError('Page timers require a function');
    const timer = { id: ++timerId, kind, callback, delay: Math.max(0, Number(delay) || 0), remaining: Math.max(0, Number(delay) || 0), args };
    timers.set(timer.id, timer);
    schedule(timer);
    return timer.id;
  }

  function clearTimer(id) {
    const timer = timers.get(id);
    if (!timer) return;
    if (timer.kind === 'frame') nativeWindow.cancelAnimationFrame(timer.handle);
    else nativeWindow.clearTimeout(timer.handle);
    timers.delete(id);
  }

  function observerClass(Constructor) {
    return class ManagedObserver {
      constructor(callback) {
        this.targets = new Map();
        this.native = new Constructor((entries) => { if (active) callback(entries, this); });
        observers.push(this);
      }
      observe(target, options) { if (!observers.includes(this)) observers.push(this); this.targets.set(target, options); if (active) this.native.observe(target, options); }
      unobserve(target) { this.targets.delete(target); this.native.unobserve?.(target); }
      disconnect() { this.targets.clear(); this.native.disconnect(); const index=observers.indexOf(this); if(index!==-1)observers.splice(index,1); }
      takeRecords() { return this.native.takeRecords?.() || []; }
    };
  }

  function updateHistory(state, url, replace) {
    const next = new URL(url || virtualURL.href, virtualURL);
    virtualURL = next;
    pageState = state;
    if (active) router.commit(page.key, next.search + next.hash, state, replace);
  }

  const historyProxy = {
    get state() { return pageState; },
    get length() { return nativeWindow.PCApp.diagnostics().navigation.length; },
    pushState: (state, unused, url) => updateHistory(state, url, false),
    replaceState: (state, unused, url) => updateHistory(state, url, true),
    back: () => { if (active) router.back(); },
    forward: () => { if (active) router.forward(); },
  };
  const locationProxy = new Proxy({}, {
    get(target, key) {
      if (key === 'assign' || key === 'replace') return url => router.follow(new URL(url, virtualURL), key === 'replace');
      if (key === 'reload') return () => nativeWindow.location.reload();
      if (key === 'toString') return () => virtualURL.href;
      return virtualURL[key];
    },
    set(target, key, value) {
      const next = new URL(virtualURL.href);
      next[key] = value;
      if (active) router.follow(next);
      else virtualURL = next;
      return true;
    },
  });
  const env = {
    document: documentProxy, history: historyProxy, location: locationProxy,
    setTimeout: (...args) => addTimer('timeout', ...args), clearTimeout: clearTimer,
    setInterval: (...args) => addTimer('interval', ...args), clearInterval: clearTimer,
    requestAnimationFrame: callback => addTimer('frame', callback), cancelAnimationFrame: clearTimer,
    ResizeObserver: observerClass(nativeWindow.ResizeObserver),
    MutationObserver: observerClass(nativeWindow.MutationObserver),
  };
  const windowProxy = new Proxy({}, {
    get(target, key) {
      if (key === 'window' || key === 'self' || key === 'globalThis') return windowProxy;
      if (key === 'addEventListener') return (type, callback, options) => trackListener(nativeWindow, type, callback, options);
      if (key === 'removeEventListener') return (type, callback, options) => untrackListener(nativeWindow, type, callback, options);
      if (key in env) return env[key];
      if (key in globals) return globals[key];
      const value = nativeWindow[key];
      return typeof value === 'function' && !value.prototype ? value.bind(nativeWindow) : value;
    },
    set(target, key, value) { globals[key] = value; return true; },
  });
  env.window = windowProxy;

  return {
    page, env,
    get suffix() { return virtualURL.search + virtualURL.hash; },
    get state() { return pageState; },
    beforeLeave(next) { return globals.PCPageLifecycle?.beforeLeave?.(next) ?? true; },
    handleBack() { return globals.PCPageLifecycle?.back?.() ?? false; },
    setLocation(suffix, state) {
      virtualURL = new URL(sourcePath + suffix, nativeWindow.location.href);
      pageState = state || null;
    },
    activate() {
      active = true;
      document.head.append(stylesheet);
      nav.replaceChildren(...actions.childNodes);
      main.append(content);
      document.body.append(portals);
      for (const dialog of portals.querySelectorAll('dialog[open]')) {
        dialog.removeAttribute('open');
        dialog.showModal();
      }
      document.body.classList.add(...bodyClasses);
      Object.assign(document.body.style, bodyStyles);
      nativeWindow.BanxueShell.setRoute(savedShell || page);
      for (const item of listeners) if (!item.removed) item.target.addEventListener(item.type, item.handler, item.options);
      for (const timer of timers.values()) schedule(timer);
      for (const observer of observers) for (const [target, options] of observer.targets) observer.native.observe(target, options);
      for (const [node, top, left] of scrollPositions) { node.scrollTop = top; node.scrollLeft = left; }
      if (savedFocus?.isConnected) savedFocus.focus({ preventScroll: true });
      globals.PCPageLifecycle?.activate?.();
    },
    deactivate() {
      globals.PCPageLifecycle?.deactivate?.();
      active = false;
      savedFocus = content.contains(document.activeElement) ? document.activeElement : null;
      // Preserve the business title; layout always comes from the page defaults.
      savedShell = { ...page, title: document.getElementById('navTitle').textContent };
      scrollPositions = [content, ...content.querySelectorAll('*')].filter(node => node.scrollTop || node.scrollLeft).map(node => [node, node.scrollTop, node.scrollLeft]);
      for (const item of listeners) item.target.removeEventListener(item.type, item.handler, item.capture);
      for (const timer of timers.values()) {
        if (timer.kind === 'frame') nativeWindow.cancelAnimationFrame(timer.handle);
        else nativeWindow.clearTimeout(timer.handle);
        timer.remaining = Math.max(0, timer.remaining - (performance.now() - timer.started));
      }
      for (const observer of observers) observer.native.disconnect();
      actions.append(...nav.childNodes);
      content.remove(); portals.remove(); stylesheet.remove();
      document.body.classList.remove(...bodyClasses);
      for (const key of Object.keys(bodyStyles)) document.body.style[key] = '';
    },
    notifyHistory() {
      for (const item of listeners) if (item.type === 'popstate' && !item.removed) item.handler(new PopStateEvent('popstate', { state: pageState }));
    },
    diagnostics() {
      return { active, listeners: listeners.filter(item => !item.removed).length, timers: timers.size, observers: observers.length, components: Object.keys(globals).filter(key => key.startsWith('Banxue')) };
    },
  };
}
