import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root = path.dirname(fileURLToPath(import.meta.url));
const origin = 'https://fandatest-d2grr5qtk0dc81500-1312908255.tcloudbaseapp.com';
const prefix = '/banxue-pc/';
const manifest = JSON.parse(await fs.readFile(root+'/source/app/manifest.json','utf8'));
const pending = ['app/index.html','app/app.js','app/manifest.json','app/page-runtime.js','app/navigation.js', 'ui-kit/components/banxue-ui.css', ...manifest.routes.map(r=>'app/'+r.module.replace('./',''))];
try {
  const module=await fs.readFile(root+'/source/app/modules/student-list.js','utf8');
  const catalog=JSON.parse(module.match(/window.BanxueDemoCatalog=(.*);/)[1]);
  const base='demos/student-detail/assets/student-data/';
  pending.push(...[...new Set(catalog.students.map(s=>s.avatar))].map(v=>base+'avatars/'+v));
  pending.push(...[...new Set(Object.values(catalog.learningFixtures))].map(v=>base+v+'.json'));
  pending.push(...Object.values(catalog.questionImages).map(v=>base+v.path));
} catch {}
const seen = new Set(); const results = [];
function add(value, base) {
  if (!value || /[{}$`\s]/.test(value) || value.startsWith('data:') || value.startsWith('#')) return;
  let url; try { url = new URL(value, origin+prefix+base); } catch {return;}
  if(url.origin!==origin || !url.pathname.startsWith(prefix))return;
  const rel=decodeURI(url.pathname.slice(prefix.length));
  if(!/\.(?:js|css|json|svg|png|jpe?g|webp|gif|woff2?|ttf|otf|html|pdf|xlsx)$/i.test(rel))return;
  if(!seen.has(rel))pending.push(rel);
}
function scan(t,rel){
  // Generated page DOM/CSS assets resolve against app/index.html; ESM imports resolve against the module.
  let page;
  try { page=JSON.parse(t.match(/export const page = (.*);/)?.[1]); } catch{}
  const sources=page ? [[page.html+'\n'+page.actions+'\n'+page.overlays+'\n'+page.css,'app/index.html'], [t,rel]] : [[t,rel]];
  for(const [text,base] of sources){
    const clean=text.replace(/\\\//g,'/').replace(/\\"/g,'"');
    for(const m of clean.matchAll(/(?:src|href)\s*=\s*["']([^"']+)["']|url\(\s*["']?([^\s)'";]+)|(?:from|import)\s*['"]([^'"]+)['"]|["'`]((?:\.\.?\/|\/banxue-pc\/)[^"'`\s<>\\]+\.(?:js|css|json|svg|png|jpe?g|webp|gif|woff2?|ttf|otf|html|pdf|xlsx)(?:\?[^"'`\s<>\\]*)?)["'`]/g)) {
      const v=m[1]||m[2]||m[3]||m[4];
      add(v, v.startsWith('../demos/')||v.startsWith('../ui-kit/')?'app/index.html':base);
    }
  }
}
async function get(rel){
  const target=root+'/source/'+rel;
  try {
    let data;
    try{data=await fs.readFile(target);}catch{
      const response=await fetch(origin+prefix+rel,{signal:AbortSignal.timeout(30000)});
      if(!response.ok)throw Error('HTTP '+response.status);
      data=Buffer.from(await response.arrayBuffer());
      if(data.toString('utf8',0,200).includes('<title>风险提醒')) throw Error('CloudBase warning response');
      await fs.mkdir(path.dirname(target),{recursive:true});await fs.writeFile(target,data);
    }
    results.push({path:rel,bytes:data.length});
    if(/\.(js|css|json|html)$/.test(rel))scan(data.toString(),rel);
  }catch(e){results.push({path:rel,error:e.message});}
}
while(pending.length){
  const batch=[];
  while(pending.length&&batch.length<8){const r=pending.shift();if(!seen.has(r)){seen.add(r);batch.push(r);}}
  await Promise.all(batch.map(get));
  if(results.length%40<8)console.log('Fetched',results.length,'queued',pending.length);
  if(seen.size>2200)throw Error('Unexpected asset graph size');
}
await fs.writeFile(root+'/verification/mirror.json',JSON.stringify(results,null,2));
console.log(JSON.stringify({files:results.length,bytes:results.reduce((s,r)=>s+(r.bytes||0),0),errors:results.filter(r=>r.error)},null,2));
