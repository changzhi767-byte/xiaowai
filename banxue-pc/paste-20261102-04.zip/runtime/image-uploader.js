/* Adapter to the approved 20261030-1410 upload contract. The existing uploader
 * still owns files, sorting, preview, crop, validation and change callbacks. */
export function upgradeUploader(env){
  const {window,document}=env;
  const component=window.BanxueImageUploader;
  if(!component||component.approvedVersion)return;
  component.approvedVersion='20261102-04';
  const P=component.Uploader.prototype,create=component.create;
  const instances=new Set();
  component.create=options=>{const u=create({...options,maxFiles:8,helpText:'请上传图片，一次不超过8张'});instances.add(u);return u;};
  component.resetPaste=()=>{for(const u of instances)u.disarmPaste(true);};
  const destroy=component.Uploader.prototype.destroy;
  component.Uploader.prototype.destroy=function(){instances.delete(this);return destroy.call(this);};
  const shell=P.renderShell,render=P.render,add=P.addFiles,initial=P.addInitial,disarm=P.disarmPaste,arm=P.armPaste,keys=P.handleGlobalKeydown,getItems=P.getItems;
  function paint(u){
    u.root.classList.add('bx-upload-approved');
    u.root.classList.toggle('is-full',u.items.length>=8);
    u.actions.hidden=false;
    const paste=u.actions.querySelector('[data-paste]');
    if(!u.pasteArmed)paste.textContent='拖拽或单击后粘贴图片';
    u.actions.querySelector('[data-add]').textContent='选择图片';
    u.root.querySelector('.bx-upload-help').textContent='请上传图片，一次不超过8张';
  }
  function limit(u){u.setStatus('最多上传8张图片，请减少本次选择或先删除图片',true);}
  P.renderShell=function(){shell.call(this);paint(this);};
  P.render=function(){render.call(this);paint(this);};
  P.addFiles=function(files,source){
    const images=Array.from(files).filter(f=>/^image\//.test(f.type||''));
    if(this.items.length+images.length>8){limit(this);return;}
    return add.call(this,Array.from(files),source);
  };
  P.addInitial=function(images){if(images?.length>8){limit(this);return;}return initial.call(this,images);};
  P.getItems=function(){if(this.items.length>8)throw new Error('一次最多上传8张图片');return getItems.call(this);};
  P.armPaste=function(){
    if(this.items.length>=8){limit(this);return;}
    arm.call(this);
    const shortcut=/Mac|iPhone|iPad/i.test(navigator.platform||'')?'⌘+V':'Ctrl+V';
    this.actions.querySelector('[data-paste]').textContent='按 '+shortcut+' 粘贴图片';
  };
  P.disarmPaste=function(clearStatus){disarm.call(this,clearStatus);paint(this);};
  P.handleActionClick=function(event){
    if(this.items.length>=8){limit(this);return;}
    if(event.target.closest('[data-add]')){this.disarmPaste(true);this.input.click();return;}
    if(event.target.closest('[data-paste]')){
      if(this.pasteArmed){this.disarmPaste(true);event.target.closest('[data-paste]').blur();}
      else this.armPaste();
    }
  };
  P.handleGlobalKeydown=function(event){
    if(event.key==='Escape'&&this.pasteArmed&&!this.modal.classList.contains('is-open')){
      event.preventDefault();this.disarmPaste(true);
      if(this.root.contains(document.activeElement))document.activeElement.blur();
      return;
    }
    return keys.call(this,event);
  };
}
