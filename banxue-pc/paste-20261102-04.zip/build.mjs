import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const version='20261102-04';
const dest=root+'/dist/banxue-pc';
await fs.mkdir(dest,{recursive:true});
await fs.cp(root+'/source',dest,{recursive:true});
await fs.mkdir(dest+'/app/completion',{recursive:true});
for(const name of ['common.js','completion.js'])await fs.copyFile(root+'/runtime/'+name,dest+'/app/completion/'+name);
await fs.copyFile(root+'/runtime/image-uploader.js',dest+'/app/completion/image-uploader.js');
await fs.copyFile(root+'/runtime/image-uploader.css',dest+'/app/image-uploader.css');
await fs.cp(root+'/runtime/upload-assets',dest+'/app/upload-assets',{recursive:true});
const css=await fs.readFile(root+'/runtime/reference.css','utf8')+'\n'+await fs.readFile(root+'/runtime/completion.css','utf8');
const manifest=JSON.parse(await fs.readFile(dest+'/app/manifest.json','utf8'));
const targets={homework:'作业批改',chinese:'语文作文',english:'英语作文',diagnosis:'学习力诊断',store:'到店'};
for(const [key,title] of Object.entries(targets)){
  const route=manifest.routes.find(r=>r.key===key);
  const isTask=['homework','chinese','english'].includes(key);
  const page={key,menu:key,title,source:null,level:'root',state:'expanded',parent:null,placeholder:false,
    actions:isTask?`<button class="btn btn-primary" type="button" data-app-route="${key}/select-student">${key==='homework'?'新增作业':'新增作文'}</button>`:'',
    html:`<section class="content-area cp-content" aria-label="${title}"><div class="cp-wrap"><div class="cp-toolbar" id="cpToolbar"><select class="cp-field" id="cpStatus" aria-label="状态筛选"></select><input type="search" class="cp-field cp-search" id="cpSearch" placeholder="搜索学员姓名" aria-label="搜索学员姓名"><label id="cpTodayWrap" class="cp-sub"><input type="checkbox" id="cpToday"> 仅看当天</label><button type="button" class="btn btn-ghost cp-view" id="cpCards" aria-label="卡片视图" aria-pressed="true">卡片</button><button type="button" class="btn btn-ghost cp-view" id="cpTable" aria-label="表格视图" aria-pressed="false">表格</button><button type="button" class="btn btn-ghost" id="cpSort">时间 ↓</button><button type="button" class="btn btn-ghost" id="cpClear">重置</button><span id="cpCount" class="cp-count" aria-live="polite"></span></div><div id="cpResults"></div><div id="cpPager" class="cp-pager"></div></div></section>`,
    overlays:'<div class="cp-toast" id="cpToast" role="status" hidden></div><dialog class="cp-dialog" id="cpDialog" aria-labelledby="cpDialogTitle"><header class="cp-dialog-head"><h2 id="cpDialogTitle"></h2><button class="btn btn-ghost" type="button" id="cpClose" aria-label="关闭弹窗">×</button></header><div class="cp-dialog-body" id="cpDialogBody"></div><footer class="cp-dialog-foot" id="cpDialogFoot"></footer></dialog>',
    css,versionHistory:JSON.stringify([{v:version,log:'沿用原 PC Demo 外框与共享数据补齐五个占位模块。'}])};
  const code=`import {mountCompletion} from '../completion/completion.js';\nexport const page=${JSON.stringify(page)};\nexport function mount(env){mountCompletion(env,${JSON.stringify(key)});}\n`;
  const rel='modules/complete-'+key+'.js';await fs.writeFile(dest+'/app/'+rel,code);
  Object.assign(route,{module:'./'+rel,sha256:createHash('sha256').update(code).digest('hex'),bytes:Buffer.byteLength(code),completionVersion:version});
}
// Six task pages share the existing uploader. Only install the reviewed adapter;
// the original snapshot and all other business logic remain authoritative.
for(const route of manifest.routes.filter(r=>r.source==='student-task')){
  const file=dest+'/app/'+route.module;
  let code=await fs.readFile(file,'utf8');
  const marker='  global.BanxueImageUploader={version:VERSION,create:function(options){ options=options||{};return new BanxueImageUploader(options.root,options); },Uploader:BanxueImageUploader};';
  if(!code.includes(marker))throw Error('Uploader factory source changed: '+route.key);
  code="import {upgradeUploader} from '../completion/image-uploader.js?v="+version+"';\n"+code.replace(marker,marker+'\n  upgradeUploader(env);').replace("deactivate:()=>{if(kind==='wrong')","deactivate:()=>{window.BanxueImageUploader.resetPaste();if(kind==='wrong')");
  await fs.writeFile(file,code);
  route.sha256=createHash('sha256').update(code).digest('hex');route.bytes=Buffer.byteLength(code);route.uploaderVersion=version;
}
manifest.version=version;manifest.referenceVersion='20261030-1344';
await fs.writeFile(dest+'/app/manifest.json',JSON.stringify(manifest,null,2));
let index=await fs.readFile(dest+'/app/index.html','utf8');
await fs.cp(root+'/runtime/trial-assets',dest+'/app/trial-assets',{recursive:true});
await fs.copyFile(root+'/runtime/trial-badge.css',dest+'/app/trial-badge.css');
const badge='<span class="nav-trial-slot"><span class="nav-trial-badge"><img class="nav-trial-icon nav-trial-icon--default" src="./trial-assets/sparkle-default.svg" alt="" aria-hidden="true"><img class="nav-trial-icon nav-trial-icon--selected" src="./trial-assets/sparkle-selected.svg" alt="" aria-hidden="true"><span class="nav-trial-text">体验版</span></span></span>';
if(!index.includes('<span class="nav-copy">错题整理</span>'))throw new Error('Wrong-organize menu source changed');
index=index.replace('<span class="nav-copy">错题整理</span>','<span class="nav-copy">错题整理</span>'+badge);
index=index.replace('</head>','<link rel="stylesheet" href="./trial-badge.css?v='+version+'">\n</head>');
index=index.replace('</head>','<link rel="stylesheet" href="./image-uploader.css?v='+version+'">\n</head>');
index=index.replace(/(<meta name="version" content=")[^"]+/, '$1'+version).replace(/(<meta name="changelog" content=")[^"]+/, '$1按截图修正粘贴态：隐藏选择图片，快捷键与退出提示整条居中。');
index=index.replace(/(<script type="application\/json" id="versionHistory">\s*)\[/,'$1'+JSON.stringify([{v:version,log:'按用户截图修正粘贴态：隐藏选择图片，按快捷键粘贴与退出提示在500px整条居中，退出恢复默认入口。'},{v:'20261102-03',log:'统一六个任务页图片上传组件为已定稿500×60版本，保留预览/裁剪/排序和业务PDF入口。'},{v:'20261102-02',log:'按Figma10691:78417/78442增加错题整理体验版标签两态；收窄隐藏，展开恢复。'},{v:'20261102-01',log:'GitHub 独立文件夹补全版：保留23条原页面路由，补齐5个占位模块。'}]).slice(0,-1)+',');
await fs.writeFile(dest+'/app/index.html',index);
await fs.writeFile(dest+'/index.html',`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="version" content="${version}"><title>秒懂 AI 伴学 · PC 完整演示</title><script type="application/json" id="versionHistory">[{"v":"${version}","log":"独立补全版入口"}]</script><script>location.replace('./app/index.html'+location.search+(location.hash||'#/learning'));</script><a href="./app/index.html#/learning">进入 PC 完整演示</a></html>`);
// The reference UI kit includes an unresolved empty icon; reuse the same reference's real SVG.
await fs.mkdir(dest+'/ui-kit/components/assets',{recursive:true});
await fs.copyFile(dest+'/demos/exam-analysis/assets/shared/empty-box.svg',dest+'/ui-kit/components/assets/empty-box.svg');
console.log('Built '+dest+' @ '+version);
