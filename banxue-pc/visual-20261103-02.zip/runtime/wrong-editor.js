// Presentation adapter. Domain gestures, drafts and transactions stay in the reviewed editor.
export function installWrongEditor(env){
  const {window:w,document:d}=env,factory=w.BanxueWrongMarking,create=factory.create;
  factory.create=options=>{
    const root=options.root,controls=options.actions,button=controls.querySelector('[data-wm="gradeSubject"]');
    const dialog=root.querySelector('[data-fields-dialog]'),fields=dialog.querySelector('form');
    const menu=d.createElement('section');menu.className='we-fields-menu';menu.popover='auto';menu.setAttribute('role','group');menu.setAttribute('aria-label','年级 / 学科');root.append(menu);
    const originalMode=options.onModeChange;
    function mode(next){
      originalMode?.(next);root.dataset.mode=next;
      const title=d.getElementById('navTitle');if(title&&button){title.after(button);button.classList.add('we-grade');}
      if(next!=='edit'&&menu.matches(':popover-open'))menu.hidePopover();
    }
    const editor=create({...options,grades:['一年级','二年级','三年级','四年级','五年级','六年级','初一','初二','初三','高一','高二','高三'],subjects:['语文','数学','英语','物理','化学','生物','政治','历史','地理'],onModeChange:mode});
    for(const [key,file] of [['minus','zoom-out.svg'],['plus','zoom-in.svg']]){const target=root.querySelector('[data-wm="'+key+'"]'),img=d.createElement('img');img.src='../demos/student-task/assets/marking/'+file;img.alt='';target.replaceChildren(img);}
    root.querySelector('[data-wm="helpTrigger"]').textContent='i';
    const abort=new AbortController();
    function paintMenu(){
      menu.replaceChildren();
      for(const [key,label] of [['grade','年级'],['subject','学科']]){
        const select=fields.querySelector('[name="'+key+'"]'),column=d.createElement('div');column.setAttribute('role','group');column.setAttribute('aria-label',label);
        for(const option of select.options){const item=d.createElement('button');item.type='button';item.textContent=option.text;item.setAttribute('aria-pressed',String(select.value===option.value));item.onclick=()=>{select.value=option.value;fields.dispatchEvent(new Event('submit',{bubbles:true,cancelable:true}));paintMenu();};column.append(item);}menu.append(column);
      }
    }
    button.onclick=()=>{if(menu.matches(':popover-open')){menu.hidePopover();return;}paintMenu();const rect=button.getBoundingClientRect();menu.style.left=Math.min(rect.left,w.innerWidth-260)+'px';menu.style.top=rect.bottom+8+'px';menu.showPopover();};
    menu.addEventListener('keydown',event=>event.stopPropagation(),{signal:abort.signal});
    menu.addEventListener('toggle',()=>button.setAttribute('aria-expanded',String(menu.matches(':popover-open'))),{signal:abort.signal});
    // No duplicate empty-state owner: decorate the existing editor's placeholder.
    const observer=new MutationObserver(()=>{const empty=root.querySelector('.list .empty-state');if(empty&&!empty.dataset.aligned){empty.dataset.aligned='true';const image=d.createElement('img');image.src='../ui-kit/components/assets/empty-box.svg';image.alt='';const title=d.createElement('p');title.className='we-empty-title';title.textContent='这里是空的哦～';empty.prepend(image,title);}});observer.observe(root,{childList:true,subtree:true});
    const resume=editor.resume.bind(editor);editor.resume=()=>{w.BanxueShell.setRoute({menu:w.StudentTaskMenu||'wrong-organize',title:d.getElementById('navTitle').textContent,level:'workbench',state:'hidden'});resume();};
    const destroy=editor.destroy.bind(editor);editor.destroy=()=>{abort.abort();observer.disconnect();menu.remove();button.remove();destroy();};
    return editor;
  };
}
