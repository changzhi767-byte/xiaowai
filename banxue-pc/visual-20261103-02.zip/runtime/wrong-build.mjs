import {readFileSync} from 'node:fs';
const editorCSS=readFileSync(new URL('./wrong-editor.css',import.meta.url),'utf8');
const drawerCSS=readFileSync(new URL('./wrong-flow.css',import.meta.url),'utf8');
function decoratePage(code,css){return code.replace(/export const page = (.*);/,(_,json)=>{const page=JSON.parse(json);page.css+=String.fromCharCode(10)+css;page.versionHistory=JSON.stringify([{v:'20261103-02',log:'真实环境详情抽屉、标记/编辑工作台视觉及交互对齐。'},...JSON.parse(page.versionHistory||'[]')]);return 'export const page = '+JSON.stringify(page)+';';});}
// Explicit, checked build-time changes against the immutable reference snapshot.
export function transformWrong(code){
  function swap(before,after){if(!code.includes(before))throw Error('Wrong flow source changed: '+before.slice(0,70));code=code.replace(before,after);}
  code="import {installWrongFlow,seedWrongExamples} from '../completion/wrong-flow.js?v=20261103-02';\n"+code;
  swap("(async function () {\n  'use strict';\n  const C=window.StudentContext,D=window.BanxueDemoData,{node}=window.StudentUI;", "installWrongFlow(env);\n(async function () {\n  'use strict';\n  const C=window.StudentContext,D=window.BanxueDemoData,{node}=window.StudentUI;");
  swap("state.status==='all'||task.phase===state.status", "state.status==='all'||(state.status==='processing'?['ai_preprocess','ai_postprocess'].includes(task.phase):task.phase===state.status)");
  swap("function enter(task){", "function enter(task){\n    if(['ai_preprocess','ai_postprocess'].includes(task.phase))return;");
  swap("task.status.action);action.type='button';", "task.status.action);action.type='button';if(['ai_preprocess','ai_postprocess'].includes(task.phase)){action.disabled=true;action.textContent='处理中 '+task.status.progress.toFixed(1)+'%';article.classList.add('wf-progress');article.style.setProperty('--wf-progress',task.status.progress+'%');}");
  swap("task.phase==='ai_preprocess'?task.status.stage:'错题数 '+task.wrong", "'错题数 '+task.wrong");
  swap("if(task.phase==='ai_postprocess')copy.append(node('small','wt-card-stage',task.status.stage));", "// Both AI phases share one processing visual; the domain phases stay distinct.");
  swap("[task.id,task.phase,task.wrong,task.subject,task.settings?.grade]", "[task.id,task.phase,task.wrong,task.subject,task.settings?.grade,['ai_preprocess','ai_postprocess'].includes(task.phase)?Math.floor(Date.now()/700):0]");
  swap("actions:[{id:'view',label:status.action}]", "actions:[{id:'view',label:status.action,disabled:['ai_preprocess','ai_postprocess'].includes(task.phase)}]");
  swap("  await refresh();\n  syncResult();", "  try{await seedWrongExamples(env);}catch(error){$('wtError').textContent='演示样例暂时无法加载，仍可添加错题。';$('wtError').hidden=false;}\n  await refresh();\n  syncResult();");
  swap("heading.append(name,grade);", "heading.append(name,grade);if(task.example)heading.append(node('small','wf-example','示例'));");
  return decoratePage(code,drawerCSS);
}

export function transformWrongTask(input){
  if(!input.includes('global.BanxueWrongMarking = { create };'))return input;
  let code=input;
  const replace=(before,after)=>{if(!code.includes(before))throw Error('Editor integration source changed: '+before.slice(0,80));code=code.replace(before,after);};
  code="import {installWrongEditor} from '../completion/wrong-editor.js?v=20261103-02';\n"+code;
  replace('  global.BanxueWrongMarking = { create };','  global.BanxueWrongMarking = { create };\n  installWrongEditor(env);');
  replace("        level: 'secondary',\n        state: 'narrow'", "        level: 'workbench',\n        state: 'hidden'");
  replace("const reserve = editing\n        ? 0\n        : root.querySelector('.thumbnails').getBoundingClientRect().width;", "const reserve = root.querySelector('.thumbnails').getBoundingClientRect().width;");
  replace('return `<span class="mark-art"><span class="mark-ink"><img src="${assetBase}error-ink.svg" alt="" draggable="false"></span></span>`;', 'return `<span class="mark-art"><img src="${assetBase}real-mark-ink.svg" alt="" draggable="false"></span>`;');
  replace("const tools = root.querySelector('.editor-tools');", `const tools = root.querySelector('.editor-tools');
    const frameCount = document.createElement('span');frameCount.className='we-frame-count';tools.prepend(frameCount);
    function closeFrameMenu(){delete tools.dataset.contextOpen;}
    function openFrameMenu(x,y){if(tool!=='edit'||!editIds.size)return;frameCount.textContent='已选择 '+editIds.size+' 个题框';tools.dataset.contextOpen='true';tools.hidden=false;tools.style.left=Math.min(x,window.innerWidth-188)+'px';tools.style.top=Math.min(y,window.innerHeight-150)+'px';}
    on(stage,'contextmenu',event=>{if(tool!=='edit')return;const box=event.target.closest('.box');if(!box)return;event.preventDefault();const id=Number(box.dataset.id);if(!editIds.has(id)){editIds=new Set([id]);draw();}openFrameMenu(event.clientX,event.clientY);});
    on(document,'pointerdown',event=>{if(!tools.contains(event.target))closeFrameMenu();});
    on(root,'keydown',event=>{if(event.key==='ContextMenu'||(event.shiftKey&&event.key==='F10')){event.preventDefault();const b=root.querySelector('.box.edit-selected');if(b){const r=b.getBoundingClientRect();openFrameMenu(r.right,r.bottom);}}if(event.key==='Escape')closeFrameMenu();});
    tools.addEventListener('click',event=>{if(event.target.closest('button:not(:disabled)'))closeFrameMenu();});`);
  replace("tool = next;\n      editing", "closeFrameMenu();\n      tool = next;\n      editing");
  replace("subject: course?.name.replace(/^(小学|初中|高中)/, '') || '数学'", "subject: (course?.name||task.subject||'数学').replace(/^(小学|初中|高中)/, '')");
  replace("courseId: course?.id || task.courseId,\n            subject: course?.name || task.subject", "courseId: course?.id || ({语文:'chinese',数学:'math',英语:'english',物理:'physics',化学:'chemistry',生物:'biology',政治:'politics',历史:'history',地理:'geography'}[snapshot.editorFields.subject]) || task.courseId,\n            subject: course?.name || snapshot.editorFields.subject");
  replace("subject: course?.id || task.courseId\n            },", "subject: course?.id || ({语文:'chinese',数学:'math',英语:'english',物理:'physics',化学:'chemistry',生物:'biology',政治:'politics',历史:'history',地理:'geography'}[snapshot.editorFields.subject]) || task.courseId\n            },");
  replace("const output = [];\n      for (const id of selected)", "const output = [];\n      const ink = new Image();ink.src=assetBase+'real-mark-ink.svg';await ink.decode();\n      for (const id of selected)");
  replace("          top += Math.ceil(piece.h);", `          const meta=pageMeta[piece.page];painter.save();painter.beginPath();painter.rect(0,top,piece.w,piece.h);painter.clip();painter.globalAlpha=.72;
          for(const mark of marks.filter(m=>m.page===piece.page&&assign(m)?.id===piece.id)){const size=mark.size*meta.w;painter.drawImage(ink,mark.x*meta.w-piece.x-size/2,top+mark.y*meta.h-piece.y-size/2,size,size);}painter.restore();
          top += Math.ceil(piece.h);`);
  return decoratePage(code,editorCSS);
}
