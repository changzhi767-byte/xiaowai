// Test-environment parity, observed 2026-11-03. Never calls the test API.
export function installWrongFlow(env) {
  const {window:w,document:d}=env,C=w.StudentContext,D=w.BanxueDemoData,U=w.StudentUI;
  const n=U.node,$=id=>d.getElementById(id);
  const curated={
    '用字母表示数原题切图':{standardAnswer:'B',analysis:'A：线段总长度为 2 + a + 6 = a + 8。B：2个物品，每个a元，再加1个6元的物品，总价为2a + 6元。C：等腰直角三角形的周长为a + a + 3 = 2a + 3。D：平行四边形的面积为a × 3 = 3a。因此选择B。'},
    '植树问题原题切图':{standardAnswer:'13根',analysis:'相邻两根电线杆相距8米，96米内有96 ÷ 8 = 12个间隔。两端都安装电线杆时，根数比间隔数多1，所以共有12 + 1 = 13根。'}
  };
  const processing=t=>['ai_preprocess','ai_postprocess'].includes(t.phase);
  const previousStatus=C.wrongTaskStatus;
  C.wrongTaskStatus=t=>({...previousStatus(t),...(processing(t)?{label:'处理中',action:'处理中',progress:Math.max(0,Math.min(94.9,Number(t.progress??(t.phaseReadyAt?94.9*(1-(t.phaseReadyAt-Date.now())/30000):0))))}: {})});
  const select=$('wtStatus');
  select.replaceChildren(...[['all','全部状态'],['processing','处理中'],['marking','标记错题'],['done','已完成']].map(([value,text])=>{const o=n('option','',text);o.value=value;return o;}));
  // A report choice is a separate modal; cancelling leaves the detail intact.
  const settings=n('dialog','bx-dialog wf-settings');settings.setAttribute('aria-label','报告设置');
  const head=n('header','wf-dialog-head'),title=n('h2','','报告设置'),close=n('button','btn btn-ghost','×');close.type='button';close.setAttribute('aria-label','关闭报告设置');head.append(title,close);
  const form=n('form'),label=n('p','','答案解析：'),options=n('div','wf-options');
  for(const [value,text] of [['none','不要答案解析'],['tail','答案解析在卷尾']]){const row=n('label'),input=n('input');input.type='radio';input.name='wfAnswer';input.value=value;input.checked=value==='tail';row.append(input,d.createTextNode(text));options.append(row);}
  const footer=n('footer','bx-form-actions'),cancel=n('button','btn bx-soft','取消'),confirm=n('button','btn btn-primary','确定');cancel.type='button';confirm.type='submit';footer.append(cancel,confirm);label.textContent='答案解析 :';const settingsBody=n('div','wf-settings-body'),extra=n('div','wf-settings-extra');settingsBody.append(label,options,extra);form.append(settingsBody,footer);settings.append(head,form);$('wtResult').after(settings);
  let choose=null;
  function dismiss(){if(settings.open)settings.close();choose?.(null);choose=null;}
  close.onclick=cancel.onclick=dismiss;
  settings.addEventListener('cancel',e=>{e.preventDefault();dismiss();});
  settings.addEventListener('click',e=>{if(e.target===settings){const r=settings.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)dismiss();}});
  form.addEventListener('submit',e=>{e.preventDefault();const answer=form.querySelector('input:checked').value==='tail';settings.close();const resolve=choose;choose=null;resolve?.(answer);});
  function reportChoice(){form.querySelector('input[value="tail"]').checked=true;settings.showModal();return new Promise(resolve=>{choose=resolve;});}
  w.BanxueWrongResults={create({onClose,onContinue}){
    const dialog=$('wtResult'),downloads=w.BanxueDownloadFiles.createDemoStore();
    let task=null,context=null,answers=[],urls=[],request=0,busy=false,trigger=null;
    function release(){urls.forEach(url=>URL.revokeObjectURL(url));urls=[];task=null;answers=[];context=null;$('wtResultQuestions').replaceChildren();}
    function hide(){++request;dismiss();if(dialog.open)dialog.close();release();}
    function count(){ $('wtResultCount').textContent='错题数 '+answers.length;$('wtResultDownloadLabel').textContent='一键下载（'+answers.length+'题）'; }
    function closeDetail(){if(busy)return;const previous=task;hide();onClose(previous);trigger?.focus({preventScroll:true});}
    function tags(names){const root=n('div','wf-tags');for(const name of names)root.append(n('span','',name));return root;}
    function question(answer,index){
      const card=n('article','wt-result-question wf-question');card.setAttribute('aria-label','第'+(index+1)+'道错题');
      const images=n('div','wf-images');
      for(const ref of answer.imageRefs){const source=context.data.questionImages[ref],img=n('img');img.src=source.path;img.alt='第'+(index+1)+'道错题';img.loading='lazy';img.addEventListener('error',()=>{img.hidden=true;const retry=n('button','btn bx-soft','图片加载失败，点击重试');retry.type='button';retry.onclick=()=>{retry.remove();img.hidden=false;img.src=source.path;};images.append(retry);});images.append(img);}
      const shot=n('div','wf-shot'),panel=n('section','wf-analysis');panel.hidden=true;panel.id='wfAnalysis'+index;
      panel.append(n('h3','','答案解析'));
      for(const [label,value] of [['答案',answer.standardAnswer||'暂无答案'],['详细解析',answer.analysis||'暂无解析'],['知识点',null]]){if(panel.children.length>1)panel.append(n('hr'));const block=n('section','wf-analysis-block');block.append(n('h4','',label),value===null?tags(answer.knowledgeNames):n('p','',value));panel.append(block);}
      const foot=n('footer','wf-question-foot'),toggle=n('button','wf-toggle'),text=n('span','','解析'),chevron=n('span','wf-chevron');toggle.append(text,chevron);toggle.type='button';toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls',panel.id);toggle.onclick=()=>{panel.hidden=!panel.hidden;toggle.setAttribute('aria-expanded',String(!panel.hidden));card.classList.toggle('is-expanded',!panel.hidden);};
      shot.append(images,panel);foot.append(tags(answer.knowledgeNames),toggle);card.append(shot,foot);return card;
    }
    async function open(id){
      if(task?.id===id&&dialog.open)return;
      const current=++request;release();trigger=d.activeElement;count();$('wtResultName').textContent='错题列表';$('wtResultGrade').textContent='';$('wtResultError').hidden=true;$('wtResultStatus').hidden=false;$('wtResultStatus').textContent='正在读取错题…';$('wtResultDownload').disabled=true;if(!dialog.open)dialog.showModal();
      try{
        const value=await C.getTask(id);if(current!==request)return;if(!value||value.kind!=='wrong')throw Error('找不到此整理任务，请关闭后重新选择。');if(value.phase!=='done'){hide();onContinue(value);return;}
        task=value;const student=D.student(task.studentId);if(!student)throw Error('找不到这位学员');
        const data={questionImages:{}},result=C.localWrong(data,[task]);urls=result.urls;context={student,data};
        const files=(task.organizedQuestions||task.attachments).filter(file=>!task.selectedIds||task.selectedIds.includes(file.id));
        answers=result.answers.map((a,i)=>{const source=files[i]||{},meta={...(task.example?curated[source.name]||{}:{}),...(task.questionMeta?.[source.id]||source)};const names=meta.knowledgeNames||meta.knowledgeIds?.map(id=>D.catalog.knowledge.find(k=>k.id===id)?.name).filter(Boolean)||[];return {...a,standardAnswer:meta.standardAnswer,analysis:meta.analysis,knowledgeNames:names};});
        $('wtResultName').textContent=student.name;$('wtResultGrade').textContent=[task.settings?.grade||student.gradeLabel||student.grade,(task.subject||D.catalog.courses.find(c=>c.id===task.courseId)?.name||'').replace(/^(小学|初中|高中)/,'')].filter(Boolean).join(' · ');count();$('wtResultQuestions').replaceChildren(...answers.map(question));$('wtResultStatus').hidden=!!answers.length;$('wtResultStatus').textContent=answers.length?'':'本次任务暂无整理出的错题';$('wtResultDownload').disabled=!answers.length;
      }catch(error){if(current===request)$('wtResultStatus').textContent=error.message||'错题暂时无法读取，请稍后重试。';}
    }
    $('wtResultClose').addEventListener('click',closeDetail);dialog.addEventListener('cancel',e=>{e.preventDefault();closeDetail();});
    dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDetail();}});
    $('wtResultDownload').addEventListener('click',async()=>{
      if(busy||!answers.length)return;const current=request,includeAnswer=await reportChoice();if(includeAnswer===null||current!==request)return;
      busy=true;$('wtResultDownload').disabled=true;$('wtResultClose').disabled=true;$('wtResultDownloadLabel').textContent='生成中…';$('wtResultError').hidden=true;
      try{const blob=await w.WrongbookExport.build(context,answers,includeAnswer),suffix=includeAnswer?'（含答案解析）':'';await downloads.record({id:'wrong-task:'+task.id+':'+(includeAnswer?'tail':'none'),kind:'wrong',name:context.student.name+'的整理错题'+suffix,studentName:context.student.name,sourceTaskId:task.id,blob});const link=n('a'),url=URL.createObjectURL(blob);link.href=url;link.download=context.student.name+'的整理错题'+suffix+'.pdf';link.click();setTimeout(()=>URL.revokeObjectURL(url),60000);}catch(error){$('wtResultError').hidden=false;$('wtResultError').textContent=error.message||'生成失败，请重试';}finally{busy=false;$('wtResultClose').disabled=false;$('wtResultDownload').disabled=!answers.length;count();}
    });
    return {open,hide,get busy(){return busy||settings.open;}};
  }};
}

// Idempotent fictional samples use the demo's existing roster and public crops.
// Commit the whole batch in one IndexedDB transaction so a failed load can retry.
export async function seedWrongExamples(env){
  const {window:w}=env,C=w.StudentContext,D=w.BanxueDemoData;
  const db=await new Promise((resolve,reject)=>{const q=w.indexedDB.open('banxue-pc-student-workspace',2);q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});
  try{
    const exists=await new Promise((resolve,reject)=>{const q=db.transaction('tasks').objectStore('tasks').get('example-wrong-v1-done');q.onsuccess=()=>resolve(q.result);q.onerror=()=>reject(q.error);});if(exists)return;
    const student=D.roster()[0],data=await D.learning(student.id),source=data.tasks.find(t=>t.source==='organize')||data.tasks[0];
    const refs=[...new Set(source.answers.filter(a=>!a.correct).flatMap(a=>a.imageRefs))].slice(0,2);if(!refs.length)return;
    const attachments=await Promise.all(refs.map(async(ref,i)=>{const image=data.questionImages[ref],response=await fetch(image.path);if(!response.ok)throw Error('示例题图加载失败');return {id:'example-crop-'+i,name:image.alt||'示例题图',group:'main',blob:await response.blob()};}));
    const now=Date.now(),meta=Object.fromEntries(refs.map((ref,i)=>{const a=source.answers.find(a=>a.imageRefs.includes(ref));return [attachments[i].id,{knowledgeIds:a.knowledgeIds||[a.knowledgeId]}];}));
    const values=['done','marking','ai_preprocess','ai_postprocess'].map((phase,i)=>({id:'example-wrong-v1-'+(i===0?'done':phase),studentId:student.id,kind:'wrong',example:true,courseId:source.courseId,subject:data.courses.find(c=>c.id===source.courseId)?.name||'数学',title:'演示样例 · 错题整理',createdAt:new Date(now-i*60000).toISOString(),settings:{grade:student.grade,subject:source.courseId},attachments,selectedIds:phase==='done'||phase==='ai_postprocess'?attachments.map(a=>a.id):[],wrong:phase==='done'||phase==='ai_postprocess'?attachments.length:0,questionMeta:meta,phase,...(phase.startsWith('ai_')?{phaseReadyAt:now+30000}: {})}));
    await new Promise((resolve,reject)=>{const tx=db.transaction('tasks','readwrite');for(const value of values)tx.objectStore('tasks').put(value);tx.oncomplete=resolve;tx.onerror=tx.onabort=()=>reject(tx.error);});
  }finally{db.close();}
}
