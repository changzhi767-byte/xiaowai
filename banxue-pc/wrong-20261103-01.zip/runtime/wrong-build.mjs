// Explicit, checked build-time changes against the immutable reference snapshot.
export function transformWrong(code){
  function swap(before,after){if(!code.includes(before))throw Error('Wrong flow source changed: '+before.slice(0,70));code=code.replace(before,after);}
  code="import {installWrongFlow,seedWrongExamples} from '../completion/wrong-flow.js';\n"+code;
  swap("(async function () {\n  'use strict';\n  const C=window.StudentContext,D=window.BanxueDemoData,{node}=window.StudentUI;", "installWrongFlow(env);\n(async function () {\n  'use strict';\n  const C=window.StudentContext,D=window.BanxueDemoData,{node}=window.StudentUI;");
  swap("state.status==='all'||task.phase===state.status", "state.status==='all'||(state.status==='processing'?['ai_preprocess','ai_postprocess'].includes(task.phase):task.phase===state.status)");
  swap("function enter(task){", "function enter(task){\n    if(['ai_preprocess','ai_postprocess'].includes(task.phase))return;");
  swap("task.status.action);action.type='button';", "task.status.action);action.type='button';if(['ai_preprocess','ai_postprocess'].includes(task.phase)){action.disabled=true;action.textContent='处理中 '+task.status.progress.toFixed(1)+'%';article.classList.add('wf-progress');article.style.setProperty('--wf-progress',task.status.progress+'%');}");
  swap("task.phase==='ai_preprocess'?task.status.stage:'错题数 '+task.wrong", "'错题数 '+task.wrong");
  swap("if(task.phase==='ai_postprocess')copy.append(node('small','wt-card-stage',task.status.stage));", "// Both AI phases share one processing visual; the domain phases stay distinct.");
  swap("[task.id,task.phase,task.wrong,task.subject,task.settings?.grade]", "[task.id,task.phase,task.wrong,task.subject,task.settings?.grade,['ai_preprocess','ai_postprocess'].includes(task.phase)?Math.floor(Date.now()/700):0]");
  swap("actions:[{id:'view',label:status.action}]", "actions:[{id:'view',label:status.action,disabled:['ai_preprocess','ai_postprocess'].includes(task.phase)}]");
  swap("  await refresh();\n  syncResult();", "  try{await seedWrongExamples(env);}catch(error){$('wtError').textContent='演示样例暂时无法加载，仍可添加错题。';$('wtError').hidden=false;}\n  await refresh();\n  syncResult();");
  swap("heading.append(name,grade);", "heading.append(name,grade);if(task.example)heading.append(node('small','wf-example','示例'));");
  return code;
}
