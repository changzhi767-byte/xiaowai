// Page-level scroll/footer projection. Business modules and their IDs remain intact.
const pagerIds=['wtPager','exPagination','slPager','downloadPager','cpPager'];
function repair(){
 const content=document.querySelector('main .content-area');if(!content)return;
 const pager=pagerIds.map(id=>content.querySelector('#'+id)).find(Boolean);if(!pager)return;
 pager.classList.add('lp-primary-pager');
 if(content.dataset.lpReady){if(content.classList.contains('lp-frame')&&pager.parentElement!==content)content.append(pager);return;}
 content.dataset.lpReady='true';
 // These two pages already own a separate scroll region and footer.
 if(content.classList.contains('dc-content')||document.documentElement.dataset.route==='store')return;
 content.classList.add('lp-frame');
 const kind=content.classList.contains('wt-content')?'wrong':content.classList.contains('cp-content')?'complete':content.classList.contains('sl-pc-content')?'students':'exam';content.dataset.lpKind=kind;
 const scroll=document.createElement('div');scroll.className='lp-scroll';scroll.tabIndex=0;scroll.setAttribute('aria-label','列表内容');
 pager.remove();while(content.firstChild)scroll.append(content.firstChild);content.append(scroll,pager);
}
let pending=false;const schedule=()=>{if(pending)return;pending=true;requestAnimationFrame(()=>{pending=false;repair();});};
new MutationObserver(schedule).observe(document.querySelector('main')||document.body,{childList:true,subtree:true});
repair();
