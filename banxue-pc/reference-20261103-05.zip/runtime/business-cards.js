// Business-specific projections read from the test UI. No task/store mutation lives here.
export function createBusinessCards(document){
  const el=(tag,cls,text)=>{const n=document.createElement(tag);n.className=cls;if(text!=null)n.textContent=text;return n;};
  const image=(name,cls='')=>{const n=el('img',cls);n.src='../app/card-assets/'+name+(name==='report-default'?'.png':'.svg');n.alt='';return n;};
  const avatar=student=>{const n=el('img','ex-avatar bc-avatar');n.src=student.avatar;n.alt='';return n;};
  const date=(value,time=false)=>{const parts=new Intl.DateTimeFormat('zh-CN',{timeZone:'Asia/Shanghai',month:'numeric',day:'numeric',hour:'2-digit',minute:'2-digit',hour12:false}).formatToParts(new Date(value)),get=key=>parts.find(p=>p.type===key)?.value||'';return get('month')+'月'+get('day')+'日'+(time?' '+get('hour')+':'+get('minute'):'');};
  const badge=(text,tone)=>{const n=el('span','bc-badge bc-badge--'+tone,text);return n;};
  const dots=parts=>{const n=el('div','ex-meta bc-meta');for(const [i,part] of parts.entries()){if(i)n.append(el('span','bc-dot','·'));n.append(el('span','bc-meta-text',part));}return n;};
  function action(label,icon,callback,{disabled=false,progress=null}={}){
    const n=el('button','ex-action bc-action');n.type='button';n.disabled=disabled;
    if(progress!==null){const fill=el('i','bc-progress');fill.style.width=progress+'%';n.append(fill);}
    else if(icon){const wrap=el('span','bc-action-icons');wrap.append(image(icon+'-default','bc-icon-default'),image(icon+'-hover','bc-icon-hover'));n.append(wrap);}
    n.append(el('span','bc-action-text',label));n.addEventListener('click',callback);return n;
  }
  function more(card,items){
    const button=el('button','ex-more bc-more');button.type='button';button.setAttribute('aria-label','更多任务操作');button.setAttribute('aria-haspopup','menu');button.setAttribute('aria-expanded','false');button.append(image('review-more-icon'));
    const menu=el('div','bc-menu');menu.popover='auto';menu.setAttribute('role','menu');
    for(const [label,run] of items){const item=el('button','bc-menu-item',label);item.type='button';item.setAttribute('role','menuitem');item.onclick=()=>{menu.hidePopover();run();};menu.append(item);}
    button.onclick=()=>{if(menu.matches(':popover-open')){menu.hidePopover();return;}const r=button.getBoundingClientRect();menu.style.left=Math.max(8,Math.min(r.right-140,innerWidth-148))+'px';menu.style.top=r.bottom+4+'px';menu.showPopover();};
    menu.addEventListener('toggle',()=>button.setAttribute('aria-expanded',String(menu.matches(':popover-open'))));card.append(button,menu);
  }
  function task(task,{kind,phaseLabels,progress,onAction,onMaterials,onReason}){
    const writing=kind!=='homework',processing=['processing','queued','generating'].includes(task.phase),error=task.phase==='composition-error',completed=['downloaded','done','completed'].includes(task.phase);
    const card=el('article','bx-list-surface ex-card bc-card '+(writing?'bc-writing-card':'bc-homework-card')+(processing?' is-processing':''));card.tabIndex=0;card.dataset.taskId=task.id;card.tabIndex=0;card.dataset.phase=task.phase;
    const tone=error?'error':task.phase==='review'||task.phase==='push'?'warning':task.phase==='ready'?'primary':'neutral';
    if(!processing)card.append(badge(phaseLabels[task.phase]||'待处理',tone));
    more(card,[[error?'查看原因':'查看材料',error?onReason:onMaterials]]);
    const body=el('div','ex-head bc-body'),student=el('div','ex-info bc-student'),info=el('div','ex-info-main bc-student-info'),name=el('div','ex-name bc-name',task.student.name);
    const score=String(task.review?.score!=null?task.review.score+' / '+(task.totalScore||task.settings?.total||100):task.score??'--').replace(/分$/,'').replace(/\s*\/\s*/,' / ');
    const pages=task.attachments?.length?task.attachments.length+'页':typeof task.pages==='number'?task.pages+'页':task.pages||'1页';
    const meta=dots(writing?[date(task.createdAt),pages,processing||error?'--':score]:[date(task.createdAt,true),pages,(task.student.grade||'')+(task.subject||'').replace(/^(小学|初中|高中)/,'')]);meta.prepend(image(writing?'download-meta-icon':'clock','bc-meta-icon'));
    info.append(name,meta);student.append(avatar(task.student),info);body.append(student);
    if(writing){const title=el('div','bc-title-wrap'),text=el('div','bc-title',task.title||'未命名作文');text.title=task.title||'未命名作文';title.append(text);body.append(title);}
    else{const metrics=el('div','bc-metrics');metrics.append(el('span','bc-metric-label','错题数'),el('span','bc-metric-value',processing?'--':typeof task.wrong==='number'?task.wrong+'道':String(task.wrong??'--')));body.append(metrics);}
    card.append(body);
    const label=error?'查看原因':task.phase==='review'?'去审核批改':task.phase==='push'?'去审核推题':completed?'再次下载报告':task.phase==='ready'?'去下载报告':'查看详情';
    const percent=Math.max(0,Math.min(99.9,Number(progress)||0));
    card.append(action(processing?(phaseLabels[task.phase]||'处理中')+' '+percent.toFixed(1)+'%':label,error?'report':task.phase==='review'||task.phase==='push'?'review':completed?'download-again':'download',onAction,{disabled:processing,progress:processing?percent:null}));
    return card;
  }
  function diagnosis(student,record,onAction){
    const card=el('article','bx-list-surface ex-card bc-card bc-diagnosis-card');card.tabIndex=0;card.dataset.studentId=student.id;card.tabIndex=0;card.dataset.state=record.status;
    const statuses={untested:['未测评','primary','去测评','assessment'],testing:['测评中','warning','继续测评','assessment'],done:['已测评','neutral','查看报告','report']};
    const [label,tone,verb,icon]=statuses[record.status]||statuses.untested;card.append(badge(label,tone));
    const body=el('div','ex-head bc-body'),row=el('div','ex-info bc-student'),info=el('div','ex-info-main bc-student-info'),meta=el('div','ex-meta bc-meta');meta.append(image('grade','bc-meta-icon'),el('span','bc-meta-text',student.grade));info.append(el('div','ex-name bc-name',student.name),meta);row.append(avatar(student),info);body.append(row);card.append(body,action(verb,icon,onAction));return card;
  }
  function attendance(student,record,{onGenerate,onPrint,onLeave,onCheckin}){
    const card=el('article','bx-list-surface ex-card bc-card bc-visit-card');card.tabIndex=0;card.dataset.studentId=student.id;card.tabIndex=0;card.dataset.phase=record.phase;
    const head=el('div','bc-visit-head'),person=el('div','bc-visit-person');person.append(avatar(student),el('div','ex-name bc-name',student.name));head.append(person);
    const foot=el('div','bc-visit-foot'),actions=el('div','bc-visit-actions');
    const add=(label,run,tone,disabled)=>{const n=el('button','bc-visit-button bc-visit-button--'+tone,label);n.type='button';n.disabled=disabled;n.onclick=run;actions.append(n);};
    add('生成日报',onGenerate,'ghost',!['pending','ready','printed'].includes(record.phase));
    add('打印日报',onPrint,'ghost',!['ready','printed'].includes(record.phase));
    if(record.inStore)add('签退',onLeave,'danger',!['no-data','ready','printed'].includes(record.phase));
    else add('签到',onCheckin,'primary',false);
    foot.append(actions);card.append(head,foot);return card;
  }
  function updateProgress(card,value,label){const fill=card.querySelector('.bc-progress'),text=card.querySelector('.bc-action-text');if(fill)fill.style.width=value+'%';if(text)text.textContent=label+' '+value.toFixed(1)+'%';}
  return {task,diagnosis,attendance,updateProgress};
}
