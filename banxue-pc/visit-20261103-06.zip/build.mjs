import {transformWrong,transformWrongTask} from './runtime/wrong-build.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createHash} from 'node:crypto';
const root=path.dirname(fileURLToPath(import.meta.url));
const version='20261103-06';
const preservedTaskVersion='20261103-03';
const dest=root+'/dist/banxue-pc';
await fs.mkdir(dest,{recursive:true});
await fs.cp(root+'/source',dest,{recursive:true});
await fs.mkdir(dest+'/app/completion',{recursive:true});
for(const name of ['common.js','completion.js','wrong-flow.js','wrong-editor.js','business-cards.js','reference-controls.js','visit-page.js'])await fs.copyFile(root+'/runtime/'+name,dest+'/app/completion/'+name);
await fs.cp(root+'/runtime/visit-assets',dest+'/app/visit-assets',{recursive:true});
await fs.cp(root+'/runtime/card-assets',dest+'/app/card-assets',{recursive:true});
await fs.copyFile(root+'/runtime/image-uploader.js',dest+'/app/completion/image-uploader.js');
await fs.copyFile(root+'/runtime/image-uploader.css',dest+'/app/image-uploader.css');
await fs.cp(root+'/runtime/upload-assets',dest+'/app/upload-assets',{recursive:true});
const css=await fs.readFile(root+'/runtime/reference.css','utf8')+'\n'+await fs.readFile(root+'/runtime/completion.css','utf8')+'\n'+await fs.readFile(root+'/runtime/business-cards.css','utf8')+'\n'+await fs.readFile(root+'/runtime/reference-controls.css','utf8');
const manifest=JSON.parse(await fs.readFile(dest+'/app/manifest.json','utf8'));
const targets={homework:'作业批改',chinese:'语文作文',english:'英语作文',diagnosis:'学习力诊断',store:'到店'};
for(const [key,title] of Object.entries(targets)){
  const route=manifest.routes.find(r=>r.key===key);
  const pageVersion=key==='store'?version:'20261103-05';
  const isTask=['homework','chinese','english'].includes(key);
  const page={key,menu:key,title,source:null,level:'root',state:'expanded',parent:null,placeholder:false,
    actions:isTask?`<button class="btn btn-primary" type="button" data-app-route="${key}/select-student">${key==='homework'?'新增作业':'新增作文'}</button>`:'',
    html:`<section class="content-area cp-content" aria-label="${title}"><div class="cp-wrap"><div class="cp-toolbar" id="cpToolbar"><select class="cp-field" id="cpStatus" aria-label="状态筛选"></select><input type="search" class="cp-field cp-search" id="cpSearch" placeholder="搜索学员姓名" aria-label="搜索学员姓名"><label id="cpTodayWrap" class="cp-sub"><input type="checkbox" id="cpToday"> 仅看当天</label><button type="button" class="btn btn-ghost cp-view" id="cpCards" aria-label="卡片视图" aria-pressed="true">卡片</button><button type="button" class="btn btn-ghost cp-view" id="cpTable" aria-label="表格视图" aria-pressed="false">表格</button><button type="button" class="btn btn-ghost" id="cpSort">时间 ↓</button><button type="button" class="btn btn-ghost" id="cpClear">重置</button><span id="cpCount" class="cp-count" aria-live="polite"></span></div><div id="cpResults"></div><div id="cpPager" class="cp-pager"></div></div></section>`,
    overlays:'<div class="cp-toast" id="cpToast" role="status" hidden></div><dialog class="cp-dialog" id="cpDialog" aria-labelledby="cpDialogTitle"><header class="cp-dialog-head"><h2 id="cpDialogTitle"></h2><button class="btn btn-ghost" type="button" id="cpClose" aria-label="关闭弹窗">×</button></header><div class="cp-dialog-body" id="cpDialogBody"></div><footer class="cp-dialog-foot" id="cpDialogFoot"></footer></dialog>',
    css:css+(key==='store'?'\n'+await fs.readFile(root+'/runtime/visit-page.css','utf8'):''),versionHistory:JSON.stringify([{v:pageVersion,log:'沿用原 PC Demo 外框与共享数据补齐五个占位模块。'}])};
  let code=`import {mountCompletion} from '../completion/completion.js?v=${pageVersion}';\nexport const page=${JSON.stringify(page)};\nexport function mount(env){mountCompletion(env,${JSON.stringify(key)});}\n`;
  if(key==='store')code=`import {mountVisit} from '../completion/visit-page.js?v=${version}';\nexport const page=${JSON.stringify(page)};\nexport function mount(env){mountVisit(env); }\n`;
  const rel='modules/complete-'+key+'.js';await fs.writeFile(dest+'/app/'+rel,code);
  Object.assign(route,{module:'./'+rel,sha256:createHash('sha256').update(code).digest('hex'),bytes:Buffer.byteLength(code),completionVersion:pageVersion});
}
// Six task pages share the existing uploader. Only install the reviewed adapter;
// the original snapshot and all other business logic remain authoritative.
for(const route of manifest.routes.filter(r=>['student/new-task','wrong-organize/new'].includes(r.key))){
  const file=dest+'/app/'+route.module;
  let code=transformWrongTask(await fs.readFile(file,'utf8'));
  const marker='  global.BanxueImageUploader={version:VERSION,create:function(options){ options=options||{};return new BanxueImageUploader(options.root,options); },Uploader:BanxueImageUploader};';
  if(!code.includes(marker))throw Error('Uploader factory source changed: '+route.key);
  const init=route.key==='student/new-task'?"if((window.StudentTaskKind||new URLSearchParams(location.search).get('kind'))==='wrong')upgradeUploader(env);":"upgradeUploader(env);";
  code="import {upgradeUploader} from '../completion/image-uploader.js?v="+preservedTaskVersion+"';\n"+code.replace(marker,marker+'\n  '+init).replace("deactivate:()=>{if(kind==='wrong')",route.key==='student/new-task'?"deactivate:()=>{window.BanxueImageUploader.resetPaste?.();if(kind==='wrong')":"deactivate:()=>{window.BanxueImageUploader.resetPaste();if(kind==='wrong')");
  await fs.writeFile(file,code);
  route.sha256=createHash('sha256').update(code).digest('hex');route.bytes=Buffer.byteLength(code);route.uploaderVersion=preservedTaskVersion;
}
const wrongRoute=manifest.routes.find(r=>r.key==='wrong-organize');
const wrongPath=dest+'/app/'+wrongRoute.module;
const wrongCode=transformWrong(await fs.readFile(wrongPath,'utf8'));
await fs.writeFile(wrongPath,wrongCode);Object.assign(wrongRoute,{sha256:createHash('sha256').update(wrongCode).digest('hex'),bytes:Buffer.byteLength(wrongCode),wrongFlowVersion:preservedTaskVersion});
await fs.copyFile(root+'/runtime/wrong-flow.css',dest+'/app/wrong-flow.css');
await fs.copyFile(root+'/runtime/visual-assets/mark-ink.svg',dest+'/demos/student-task/assets/marking/real-mark-ink.svg');
for(const name of ['zoom-out.svg','zoom-in.svg'])await fs.copyFile(root+'/runtime/visual-assets/'+name,dest+'/demos/student-task/assets/marking/'+name);
manifest.version=version;manifest.referenceVersion='20261030-1344';
await fs.writeFile(dest+'/app/manifest.json',JSON.stringify(manifest,null,2));
let index=await fs.readFile(dest+'/app/index.html','utf8');
await fs.cp(root+'/runtime/trial-assets',dest+'/app/trial-assets',{recursive:true});
await fs.copyFile(root+'/runtime/trial-badge.css',dest+'/app/trial-badge.css');
const badge='<span class="nav-trial-slot"><span class="nav-trial-badge"><img class="nav-trial-icon nav-trial-icon--default" src="./trial-assets/sparkle-default.svg" alt="" aria-hidden="true"><img class="nav-trial-icon nav-trial-icon--selected" src="./trial-assets/sparkle-selected.svg" alt="" aria-hidden="true"><span class="nav-trial-text">体验版</span></span></span>';
if(!index.includes('<span class="nav-copy">错题整理</span>'))throw new Error('Wrong-organize menu source changed');
index=index.replace('<span class="nav-copy">错题整理</span>','<span class="nav-copy">错题整理</span>'+badge);
index=index.replace('</head>','<link rel="stylesheet" href="./wrong-flow.css?v='+version+'">\n</head>');
index=index.replace('</head>','<link rel="stylesheet" href="./trial-badge.css?v='+version+'">\n</head>');
index=index.replace('</head>','<link rel="stylesheet" href="./image-uploader.css?v='+version+'">\n</head>');
index=index.replace(/(<meta name="version" content=")[^"]+/, '$1'+version).replace(/(<meta name="changelog" content=")[^"]+/, '$1到店按测试环境恢复签到/签退、单日报动作与签到确认。');
index=index.replace(/(<script type="application\/json" id="versionHistory">\s*)\[/,'$1'+JSON.stringify([{v:version,log:'到店按真实测试环境恢复签到/签退两列表、确认签到及动态日报动作。'},{v:'20261103-05',log:'非错题原版页面及上传器还原；五页复用CloudBase原版组件。'},{v:'20261103-04',log:'恢复五页业务卡片。'},{v:'20261103-03',log:'修复右键菜单SVG优先级。'},{v:'20261103-02',log:'详情抽屉及标记/编辑工作台统一。'},{v:'20261103-01',log:'补真实环境错题整理处理态、解析与报告设置。'},{v:'20261102-04',log:'按用户截图修正粘贴态整条居中。'},{v:'20261102-03',log:'统一六个任务页图片上传组件为已定稿500×60版本，保留预览/裁剪/排序和业务PDF入口。'},{v:'20261102-02',log:'按Figma10691:78417/78442增加错题整理体验版标签两态；收窄隐藏，展开恢复。'},{v:'20261102-01',log:'GitHub 独立文件夹补全版：保留23条原页面路由，补齐5个占位模块。'}]).slice(0,-1)+',');
await fs.writeFile(dest+'/app/index.html',index);
await fs.writeFile(dest+'/index.html',`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="version" content="${version}"><title>秒懂 AI 伴学 · PC 完整演示</title><script type="application/json" id="versionHistory">[{"v":"${version}","log":"独立补全版入口"}]</script><script>location.replace('./app/index.html'+location.search+(location.hash||'#/learning'));</script><a href="./app/index.html#/learning">进入 PC 完整演示</a></html>`);
// The reference UI kit includes an unresolved empty icon; reuse the same reference's real SVG.
await fs.mkdir(dest+'/ui-kit/components/assets',{recursive:true});
await fs.copyFile(dest+'/demos/exam-analysis/assets/shared/empty-box.svg',dest+'/ui-kit/components/assets/empty-box.svg');
console.log('Built '+dest+' @ '+version);
