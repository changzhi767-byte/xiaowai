import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=path.dirname(fileURLToPath(import.meta.url));
const original=JSON.parse(await fs.readFile(root+'/source/app/manifest.json','utf8'));
const actual=JSON.parse(await fs.readFile(root+'/dist/banxue-pc/app/manifest.json','utf8'));
const checks=[];
for(const route of actual.routes){
  const file=root+'/dist/banxue-pc/app/'+route.module;
  const module=await import(pathToFileURL(file));
  assert(module.page.html&&typeof module.mount==='function',route.key+' module invalid');
  assert(!module.page.placeholder,route.key+' is still a placeholder');
  const old=original.routes.find(r=>r.key===route.key);
  if(old.source){const a=await fs.readFile(file,'utf8'),b=await fs.readFile(root+'/source/app/'+old.module,'utf8');
    const restored=old.source==='student-task'?a.replace(/^import \{upgradeUploader\}[^\n]+\n/,'').replace('\n  upgradeUploader(env);','').replace('window.BanxueImageUploader.resetPaste();',''):a;
    assert.equal(restored,b,route.key+' business logic changed outside uploader adapter');
  }
  checks.push({route:route.key,placeholder:false,originalPreserved:!!old.source&&old.source!=='student-task',uploaderOnly:old.source==='student-task',sha256:createHash('sha256').update(await fs.readFile(file)).digest('hex')});
}
assert.equal(checks.length,28);
const common=await fs.readFile(root+'/runtime/common.js','utf8');
const catalog=JSON.parse(common.match(/window.BanxueDemoCatalog=(.*);/)[1]);
for(const avatar of new Set(catalog.students.map(s=>s.avatar)))await fs.access(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/avatars/'+avatar);
for(const fixture of new Set(Object.values(catalog.learningFixtures)))assert(Array.isArray(JSON.parse(await fs.readFile(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/'+fixture+'.json','utf8'))));
for(const image of Object.values(catalog.questionImages))await fs.access(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/'+image.path);
await fs.writeFile(root+'/verification/routes.json',JSON.stringify(checks,null,2));
console.log('PASS: 28 routes load; 17 originals byte-identical; 6 task pages only add uploader adapter; catalog assets present.');
