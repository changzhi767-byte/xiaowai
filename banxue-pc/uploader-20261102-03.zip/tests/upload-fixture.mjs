import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const source=await fs.readFile(root+'/source/app/modules/student-task.js','utf8');
const start=source.indexOf('(function(global){\n  "use strict";\n\n  var VERSION = "20260902-1558";');
const end=source.indexOf('})(window);',source.indexOf('  global.BanxueImageUploader={version:VERSION',start))+11;
if(start<0||end<start)throw Error('Original uploader not found');
const code=source.slice(start,end);
const html=`<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="./ui-kit/components/banxue-ui.css"><link rel="stylesheet" href="./ui-kit/components/banxue-image-uploader.css"><link rel="stylesheet" href="./app/image-uploader.css"><div class="bx-task-form"><div id="upload"></div></div><ol id="results"></ol><script type="module">
import {upgradeUploader} from './app/completion/image-uploader.js';
${code}
upgradeUploader({window,document});
const u=window.BanxueImageUploader.create({root:document.querySelector('#upload'),title:'测试图片'});
const checks=[];function ok(name,condition){checks.push({name,pass:!!condition});if(!condition)throw Error(name);}
const bytes=Uint8Array.from(atob('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+jU1EAAAAASUVORK5CYII='),c=>c.charCodeAt(0));
function data(n){let d=new DataTransfer();for(let i=0;i<n;i++)d.items.add(new File([bytes],Date.now()+'-'+i+'.png',{type:'image/png'}));return d;}
function choose(n){u.input.files=data(n).files;u.input.dispatchEvent(new Event('change',{bubbles:true}));}
function paste(n){u.armPaste();document.dispatchEvent(new ClipboardEvent('paste',{clipboardData:data(n),bubbles:true,cancelable:true}));}
function drop(n){u.root.dispatchEvent(new DragEvent('drop',{dataTransfer:data(n),bubbles:true,cancelable:true}));}
try{
ok('entry is 500x60',u.actions.getBoundingClientRect().width===500&&u.actions.getBoundingClientRect().height===60);
choose(9);ok('file chooser rejects 0+9 as entire batch',u.items.length===0);
paste(9);ok('paste rejects 0+9',u.items.length===0);
drop(9);ok('drop rejects 0+9',u.items.length===0);
choose(7);ok('file chooser accepts 7',u.items.length===7);
paste(2);ok('7+2 rejected without truncation',u.items.length===7);
drop(1);ok('7+1 accepted',u.items.length===8);
choose(1);ok('8+1 rejected',u.items.length===8);
ok('full entry stays visible',!u.actions.hidden&&u.root.classList.contains('is-full'));
u.remove(0);ok('delete restores upload availability',u.items.length===7&&!u.root.classList.contains('is-full'));
choose(1);ok('delete then add reaches 8 again',u.items.length===8);
u.clear();choose(8);ok('single chooser batch accepts 8',u.items.length===8);
u.remove(0);u.disarmPaste(true);
u.actions.querySelector('[data-paste]').click();ok('click enters paste state',u.pasteArmed);
u.actions.querySelector('[data-paste]').click();ok('click again exits and keeps images',!u.pasteArmed&&u.items.length===7);
u.actions.querySelector('[data-paste]').click();u.actions.querySelector('[data-paste]').focus();document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',bubbles:true,cancelable:true}));
ok('Esc exits and clears control focus',!u.pasteArmed&&!u.root.contains(document.activeElement));
u.setStatus('');let before=u.actions.getBoundingClientRect(),listBefore=u.list.getBoundingClientRect();u.root.dispatchEvent(new DragEvent('dragenter',{dataTransfer:data(1),bubbles:true}));
let during=u.actions.getBoundingClientRect(),listDuring=u.list.getBoundingClientRect();ok('drag feedback keeps bar and list geometry',before.height===during.height&&before.y===during.y&&listBefore.y===listDuring.y&&u.root.classList.contains('is-file-over'));
u.root.dispatchEvent(new DragEvent('dragleave',{relatedTarget:document.body,bubbles:true}));ok('drag leave restores default',!u.root.classList.contains('is-file-over'));
u.armPaste();window.BanxueImageUploader.resetPaste();ok('page leave disarms without clearing images',!u.pasteArmed&&u.items.length===7);
ok('thumbnails are 140px with 16px gap',u.list.firstElementChild.getBoundingClientRect().width===140&&getComputedStyle(u.list).gap==='16px');
}catch(error){checks.push({name:error.message,pass:false});}
document.querySelector('#results').innerHTML=checks.map(c=>'<li>'+(c.pass?'PASS ':'FAIL ')+c.name+'</li>').join('');document.body.dataset.result=checks.every(c=>c.pass)?'pass':'fail';
</script>`;
await fs.writeFile(root+'/dist/banxue-pc/upload-check.html',html);
console.log('Fixture ready: /banxue-pc/upload-check.html (not included in deployment archive)');
