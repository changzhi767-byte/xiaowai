import {transformWrong,transformWrongTask} from './runtime/wrong-build.mjs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=path.dirname(fileURLToPath(import.meta.url));
const original=JSON.parse(await fs.readFile(root+'/source/app/manifest.json','utf8'));
const actual=JSON.parse(await fs.readFile(root+'/dist/banxue-pc/app/manifest.json','utf8'));
const checks=[];
for(const route of actual.routes){
  const file=root+'/dist/banxue-pc/app/'+route.module;
  const module=await import(pathToFileURL(file));
  assert(module.page.html&&typeof module.mount==='function',route.key+' module invalid');
  assert(!module.page.placeholder,route.key+' is still a placeholder');
  const old=original.routes.find(r=>r.key===route.key);
  if(old.source){const a=await fs.readFile(file,'utf8'),b=await fs.readFile(root+'/source/app/'+old.module,'utf8');
    const integrated=old.source==='student-task';
    const restored=integrated?a.replace(/^import \{upgradeUploader\}[^\n]+\n/,'').replace("\n  if((window.StudentTaskKind||new URLSearchParams(location.search).get('kind'))==='wrong')upgradeUploader(env);",'').replace('\n  upgradeUploader(env);','').replace('window.BanxueImageUploader.resetPaste?.();','').replace('window.BanxueImageUploader.resetPaste();',''):a;
    assert.equal(restored,route.key==='wrong-organize'?transformWrong(b):integrated?transformWrongTask(b):b,route.key+' unexpected difference from checked integration');
  }
  checks.push({route:route.key,placeholder:false,originalPreserved:!!old.source&&old.source!=='student-task'&&route.key!=='wrong-organize',uploaderOnly:old.source==='student-task'&&!['student/new-task','wrong-organize/new'].includes(route.key),editorIntegrated:['student/new-task','wrong-organize/new'].includes(route.key),sha256:createHash('sha256').update(await fs.readFile(file)).digest('hex')});
}
assert.equal(checks.length,28);
const common=await fs.readFile(root+'/runtime/common.js','utf8');
const catalog=JSON.parse(common.match(/window.BanxueDemoCatalog=(.*);/)[1]);
for(const avatar of new Set(catalog.students.map(s=>s.avatar)))await fs.access(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/avatars/'+avatar);
for(const fixture of new Set(Object.values(catalog.learningFixtures)))assert(Array.isArray(JSON.parse(await fs.readFile(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/'+fixture+'.json','utf8'))));
for(const image of Object.values(catalog.questionImages))await fs.access(root+'/dist/banxue-pc/demos/student-detail/assets/student-data/'+image.path);
await fs.writeFile(root+'/verification/routes.json',JSON.stringify(checks,null,2));
for(const asset of ['real-mark-ink.svg','zoom-out.svg','zoom-in.svg'])await fs.access(root+'/dist/banxue-pc/demos/student-task/assets/marking/'+asset);
console.log('PASS: 28 routes load; 16 original pages byte-identical; 6 task pages match reviewed uploader/editor integration; 5 completion pages use reference components; catalog assets present.');
